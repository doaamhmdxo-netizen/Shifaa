# Shifaa — Front-end repair report (2026-11-22)

## Source package
- Based on `Shifaa-bilingual-all-pages-verified(5).zip` (the newest verified package available in the project library).
- Arabic/English direction handling and the existing visual identity were retained.

## Implemented
- Added missing element guards in password reset, forgot-password, OTP, password-toggle and resend-countdown scripts.
- Made `password-toggle.js` the shared password visibility handler on login and registration; removed the duplicate handlers from `login.js` and `register.js`.
- Made workflow search/forms defensive when optional elements are absent.
- Expanded doctor patient lookup to include local doctor/admin patient lists and booking records, in addition to demo patients.
- Added separate CSV exports for appointments and support messages.
- Kept the registration form DOM intact after success (hidden instead of `replaceChildren`) and excluded passwords from the locally stored registration draft.
- Kept administrator creation server-authoritative; the demo now reports clearly when the backend is unavailable and does not simulate a successful admin account.
- Aligned patient ID fallback order across booking, chat and doctor-chat entry points, including `Email` and `PhoneNumber` variants.
- Made doctor dashboard action links work with Arabic and English labels and prevented the generic `href="#"` handler from intercepting workflow-managed actions/tabs/help.
- Normalized appointment date/time display, handled both Arabic and English “new” support-message statuses, replaced geolocation alerts with inline status feedback, and added Escape handling to the call preview.
- Hardened chat localStorage writes against quota errors and excluded the frequently updated recording timer from mutation-based translation work.
- Improved doctor search filtering: Arabic digits, `data-*` fields, availability checkboxes, rating/price sorting, and stable default ordering.
- Made the public visitor gate bilingual immediately and on language changes; adjusted stacking order.
- Consolidated repeated workflow registration CSS, removed the duplicate dashboard toast styling and duplicate page-home SVG rule, centralized authentication artwork behavior, and refined responsive chat/doctor/pharmacy/public-home layouts.

## Deliberately not changed
- The requested `*_2.html` files and `reset-password_2.js` are not present in the selected source package. No orphan duplicate pages/scripts were generated or deleted.
- `patient-dashboard.html` has two closing `</div>` elements after the footer because they close `.dashboard-body` and its parent `.dashboard`; they are valid, not an extra wrapper. No closing tag was removed.
- No backend endpoints, authentication, database connection, WebRTC signaling, or live availability were fabricated. Admin registration still requires the backend.
- No source diagram files for ERDPlus / Visual Paradigm were included in this front-end ZIP, so the university diagrams were not redrawn or silently altered.

## Diagram/database consistency finding
- `Shifaa System Diagrams.pdf` Use Case page includes “Chat & Video/Voice Call”.
- Its ERD and Relational Schema pages show only Patient, Doctor, Specialty, Appointment, Review and Pharmacy; they do not include Conversation, ConversationMessage, Attachment or CallSession entities/tables.
- `database/conversations-schema.sql` adds `conversations` and `conversation_messages`, but it does not define message attachment storage or a call-session entity. The chat realtime contract separately documents the missing signaling/backend work.
- Before production database integration, update the ERDPlus ERD and relational schema in the university’s required notation to include conversation/message/attachment/call-session structures and their keys/relationships. Keep the existing Use Case scope, and add a chat/call Activity Diagram if the course requires the full workflow. Do not treat browser-local Data URLs or the current local call preview as production messaging/calling.

## Static QA performed
- `node --check` passed for all JavaScript files in `js/`.
- All CSS files parsed with `tinycss2` without syntax errors.
- HTML scan found no duplicate IDs or missing local script/style/image references.
- `patient-dashboard.html` was parsed and its dashboard wrapper nesting verified.
- This is static QA; visual browser testing, mobile device testing, backend/API integration, database migration execution and end-to-end role testing remain required.

## Additional completion pass (2026-11-22)
- Hardened reverse translation dictionaries: only unique English-to-Arabic mappings are reversed. Ambiguous English values are intentionally left unchanged rather than mapped to the wrong Arabic phrase.
- Kept phone numbers, OTPs, IDs, and dates unchanged when switching back to Arabic; currency labels are normalized without global digit conversion.
- Marked the chat recording status as dynamic/i18n-skip so its frequently changing timer is not repeatedly translated by the MutationObserver.
- Added a final null guard for the optional doctor working-hours summary target.
- Added `database/chat-attachments-call-sessions.sql` for attachment metadata and call-session records, including indexes and security requirements.
- Added `docs/ERDPLUS-CHAT-CALL-ADDENDUM.md` specifying the entities, keys, cardinalities, and mapping required to bring the ERDPlus/relational schema into alignment with the existing Chat & Video/Voice Call Use Case.

## Final static QA
- JavaScript: 21 files passed `node --check`.
- CSS: 15 stylesheets parsed with zero syntax errors.
- HTML: 16 pages parsed; no duplicate IDs and no missing local script/style/image references.
- Archive integrity was checked after packaging.

## Explicit limitations (not represented as completed)
- Browser visual/device testing could not be completed in this environment. The pages still need a human visual pass at desktop, tablet, and mobile widths, in both Arabic and English, including role-based journeys.
- Live authentication, invitation validation, database persistence, live doctor availability, cross-device messaging, attachment upload/download, and WebRTC/voice/video calling require backend services, credentials, deployment configuration, and the canonical database key definitions. They cannot be made production-real by front-end-only edits.
- The source package does not contain `*_2.html`, `reset-password_2.js`, or editable ERDPlus/Visual Paradigm project files. No duplicate files were fabricated or removed. The PDF source diagrams remain unchanged; the exact ERD additions are documented in the addendum for recreation in the university tools.
- The new chat migration is a proposed PostgreSQL migration and must be reconciled with the final canonical account and appointment schema before execution in a real database.
