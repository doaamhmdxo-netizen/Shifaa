/*
  Shifaa - Patient medical record schema (SQL Server)
  This schema is designed for the patientMedicalRecord UI data contract.
  PatientId uses NVARCHAR(450) to remain compatible with the default
  ASP.NET Core Identity string key. Add the FK to dbo.AspNetUsers(Id)
  after the Identity tables are created and verify the user has Patient role.
*/

CREATE TABLE dbo.PatientMedicalProfiles (
    Id UNIQUEIDENTIFIER NOT NULL CONSTRAINT PK_PatientMedicalProfiles PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
    PatientId NVARCHAR(450) NOT NULL,
    BloodType NVARCHAR(5) NULL,
    HeightCm DECIMAL(5,2) NULL,
    WeightKg DECIMAL(6,2) NULL,
    BloodPressureSystolic DECIMAL(6,2) NULL,
    BloodPressureDiastolic DECIMAL(6,2) NULL,
    HeartRateBpm SMALLINT NULL,
    BodyTemperatureC DECIMAL(4,1) NULL,
    OxygenSaturationPercent DECIMAL(5,2) NULL,
    BloodGlucoseMgDl DECIMAL(7,2) NULL,
    MeasurementDate DATE NULL,
    MedicalNotes NVARCHAR(MAX) NULL,
    CreatedAt DATETIMEOFFSET(0) NOT NULL CONSTRAINT DF_PatientMedicalProfiles_CreatedAt DEFAULT SYSDATETIMEOFFSET(),
    UpdatedAt DATETIMEOFFSET(0) NOT NULL CONSTRAINT DF_PatientMedicalProfiles_UpdatedAt DEFAULT SYSDATETIMEOFFSET(),
    CONSTRAINT UQ_PatientMedicalProfiles_PatientId UNIQUE (PatientId)
);

CREATE TABLE dbo.PatientAllergies (
    Id UNIQUEIDENTIFIER NOT NULL CONSTRAINT PK_PatientAllergies PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
    PatientId NVARCHAR(450) NOT NULL,
    AllergyName NVARCHAR(200) NOT NULL,
    Reaction NVARCHAR(500) NULL,
    Severity NVARCHAR(50) NULL,
    CreatedAt DATETIMEOFFSET(0) NOT NULL CONSTRAINT DF_PatientAllergies_CreatedAt DEFAULT SYSDATETIMEOFFSET()
);

CREATE TABLE dbo.PatientChronicConditions (
    Id UNIQUEIDENTIFIER NOT NULL CONSTRAINT PK_PatientChronicConditions PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
    PatientId NVARCHAR(450) NOT NULL,
    ConditionName NVARCHAR(200) NOT NULL,
    Notes NVARCHAR(1000) NULL,
    DiagnosedAt DATE NULL,
    CreatedAt DATETIMEOFFSET(0) NOT NULL CONSTRAINT DF_PatientChronicConditions_CreatedAt DEFAULT SYSDATETIMEOFFSET()
);

CREATE TABLE dbo.PatientSurgeries (
    Id UNIQUEIDENTIFIER NOT NULL CONSTRAINT PK_PatientSurgeries PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
    PatientId NVARCHAR(450) NOT NULL,
    SurgeryName NVARCHAR(200) NOT NULL,
    SurgeryDate DATE NULL,
    Notes NVARCHAR(1000) NULL,
    CreatedAt DATETIMEOFFSET(0) NOT NULL CONSTRAINT DF_PatientSurgeries_CreatedAt DEFAULT SYSDATETIMEOFFSET()
);

CREATE TABLE dbo.PatientMedications (
    Id UNIQUEIDENTIFIER NOT NULL CONSTRAINT PK_PatientMedications PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
    PatientId NVARCHAR(450) NOT NULL,
    MedicationName NVARCHAR(200) NOT NULL,
    Dosage NVARCHAR(100) NULL,
    Frequency NVARCHAR(200) NULL,
    Notes NVARCHAR(1000) NULL,
    IsActive BIT NOT NULL CONSTRAINT DF_PatientMedications_IsActive DEFAULT 1,
    StartedAt DATE NULL,
    EndedAt DATE NULL,
    CreatedAt DATETIMEOFFSET(0) NOT NULL CONSTRAINT DF_PatientMedications_CreatedAt DEFAULT SYSDATETIMEOFFSET()
);

CREATE TABLE dbo.PatientEmergencyContacts (
    Id UNIQUEIDENTIFIER NOT NULL CONSTRAINT PK_PatientEmergencyContacts PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
    PatientId NVARCHAR(450) NOT NULL,
    ContactName NVARCHAR(200) NOT NULL,
    Relationship NVARCHAR(100) NULL,
    PhoneNumber NVARCHAR(30) NOT NULL,
    CreatedAt DATETIMEOFFSET(0) NOT NULL CONSTRAINT DF_PatientEmergencyContacts_CreatedAt DEFAULT SYSDATETIMEOFFSET(),
    UpdatedAt DATETIMEOFFSET(0) NOT NULL CONSTRAINT DF_PatientEmergencyContacts_UpdatedAt DEFAULT SYSDATETIMEOFFSET()
);

CREATE INDEX IX_PatientAllergies_PatientId ON dbo.PatientAllergies(PatientId);
CREATE INDEX IX_PatientChronicConditions_PatientId ON dbo.PatientChronicConditions(PatientId);
CREATE INDEX IX_PatientSurgeries_PatientId ON dbo.PatientSurgeries(PatientId);
CREATE INDEX IX_PatientMedications_PatientId_IsActive ON dbo.PatientMedications(PatientId, IsActive);
CREATE INDEX IX_PatientEmergencyContacts_PatientId ON dbo.PatientEmergencyContacts(PatientId);

/*
  After creating ASP.NET Core Identity tables, add foreign keys such as:
  ALTER TABLE dbo.PatientMedicalProfiles ADD CONSTRAINT FK_PatientMedicalProfiles_AspNetUsers
    FOREIGN KEY (PatientId) REFERENCES dbo.AspNetUsers(Id) ON DELETE CASCADE;
  Repeat for child tables after confirming the PatientId column type matches
  the actual Identity key. Enforce Patient role authorization in every API.
*/
