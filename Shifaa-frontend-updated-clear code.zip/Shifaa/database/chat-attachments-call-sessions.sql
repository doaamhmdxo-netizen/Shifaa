-- Shifaa chat attachments and voice/video call sessions (PostgreSQL migration).
-- Apply after conversations-schema.sql. This is a proposed logical schema;
-- replace TEXT identity columns with the canonical user key type and add FKs
-- to the real account/appointment tables during backend integration.

CREATE TABLE IF NOT EXISTS message_attachments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  message_id UUID NOT NULL REFERENCES conversation_messages(id) ON DELETE CASCADE,
  storage_key TEXT NOT NULL UNIQUE,
  original_file_name TEXT NOT NULL,
  media_type TEXT NOT NULL,
  byte_size BIGINT NOT NULL CHECK (byte_size > 0 AND byte_size <= 1572864),
  checksum_sha256 CHAR(64),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Attachment-only messages are valid. At least one of body or attachment
-- must exist; enforce this with a deferred trigger in the service layer or
-- a transaction-level validation after attachment insertion.
ALTER TABLE conversation_messages ALTER COLUMN body DROP NOT NULL;

CREATE TABLE IF NOT EXISTS call_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  initiated_by TEXT NOT NULL,
  call_type TEXT NOT NULL CHECK (call_type IN ('audio', 'video')),
  status TEXT NOT NULL CHECK (status IN ('initiated', 'ringing', 'accepted', 'rejected', 'missed', 'ended', 'failed')),
  provider_room_id TEXT UNIQUE,
  started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  answered_at TIMESTAMPTZ,
  ended_at TIMESTAMPTZ,
  duration_seconds INTEGER CHECK (duration_seconds IS NULL OR duration_seconds >= 0),
  failure_code TEXT,
  CHECK (ended_at IS NULL OR ended_at >= started_at),
  CHECK (answered_at IS NULL OR answered_at >= started_at)
);

CREATE INDEX IF NOT EXISTS idx_message_attachments_message
  ON message_attachments (message_id);
CREATE INDEX IF NOT EXISTS idx_call_sessions_conversation_started
  ON call_sessions (conversation_id, started_at DESC);
CREATE INDEX IF NOT EXISTS idx_call_sessions_status_started
  ON call_sessions (status, started_at DESC);

-- Security requirements:
-- 1) Store attachment bytes in private object storage; storage_key is not a public URL.
-- 2) Authorize every upload/download against conversation membership.
-- 3) Scan files, validate MIME by content, enforce size limits, and issue short-lived URLs.
-- 4) Never store browser Data URLs or raw media blobs in PostgreSQL/localStorage.
-- 5) Call signaling must use authenticated short-lived tokens; never trust a room ID
--    or participant identity supplied by the browser.
-- 6) Enforce that initiated_by belongs to the conversation (API/service + DB policy).
-- 7) Enforce non-empty message content or at least one attachment within the same
--    transaction; the client alone is not a security boundary.
