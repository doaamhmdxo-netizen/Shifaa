# Shifaa – Patient medical record data contract

The patient medical-record screen uses the following frontend object (`schemaVersion: 2`):

- `patientId`: authenticated patient identifier (must come from the server in production).
- `bloodType`, `heightCm`, `weightKg`: profile-level values.
- `vitals`: latest optional measurements (`bloodPressureSystolic`, `bloodPressureDiastolic`, `heartRateBpm`, `bodyTemperatureC`, `oxygenSaturationPercent`, `bloodGlucoseMgDl`, `measurementDate`). These map to the matching columns in `PatientMedicalProfiles`. BMI is calculated in the interface from height and weight and is not stored as a separate measurement.
- `allergies[]`: currently entered as one item per line; API should normalize each item into `PatientAllergies`.
- `chronicConditions[]`: normalize into `PatientChronicConditions`.
- `surgeries[]`: normalize into `PatientSurgeries`.
- `medications[]`: normalize into `PatientMedications`.
- `emergencyContact`: one contact in the current UI; map to `PatientEmergencyContacts`.
- `notes`, `createdAt`, `updatedAt`: profile notes and audit timestamps.

## API contract recommendation

- `GET /api/patients/me/medical-record`
- `PUT /api/patients/me/medical-record`
- `GET /api/patients/me/settings`
- `PUT /api/patients/me/settings`

The server must derive the patient ID from the authenticated identity, not trust a `patientId` sent by the browser. Enforce patient ownership and doctor access policies on every read/write. Validate units, lengths, allowed blood types, and date values server-side. Store uploaded reports in private object storage and save metadata/permissions in the database; do not store medical files in localStorage.

The current build saves a demo copy in browser `localStorage` only. It is a UI/data-contract prototype, not a connected or production medical record system. Do not enter real patient health data until secure authentication, authorization, HTTPS, database persistence, audit logging, backups, and private file storage are in place.
