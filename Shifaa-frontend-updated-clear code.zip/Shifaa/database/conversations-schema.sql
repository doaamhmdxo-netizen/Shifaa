-- Shifaa private patient-doctor conversations (PostgreSQL proposal).
-- Assumes authenticated users and appointments are stored by the backend.
-- Replace the text IDs below with the project's canonical user/appointment key types when integrating.

CREATE TABLE IF NOT EXISTS conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id TEXT NOT NULL,
  doctor_id TEXT NOT NULL,
  appointment_id TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT conversations_patient_doctor_appointment_unique
    UNIQUE (patient_id, doctor_id, appointment_id)
);

CREATE TABLE IF NOT EXISTS conversation_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  sender_id TEXT NOT NULL,
  sender_role TEXT NOT NULL CHECK (sender_role IN ('patient', 'doctor')),
  body TEXT NOT NULL CHECK (char_length(body) BETWEEN 1 AND 3000),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  read_at TIMESTAMPTZ NULL
);

CREATE INDEX IF NOT EXISTS idx_conversations_patient_updated
  ON conversations (patient_id, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_conversations_doctor_updated
  ON conversations (doctor_id, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_conversation_messages_conversation_created
  ON conversation_messages (conversation_id, created_at ASC);

-- Required backend invariants (enforce in API/service and DB policies):
-- 1) A patient may create a conversation only for an appointment/selection
--    that belongs to that patient and references the target doctor.
-- 2) The patient endpoint filters strictly by authenticated patient_id.
-- 3) The doctor endpoint filters strictly by authenticated doctor_id.
-- 4) A sender_id and sender_role must match the authenticated session.
-- 5) Never accept patient_id/doctor_id from the browser as authority.
-- 6) Validate membership before returning messages or updating read_at.
