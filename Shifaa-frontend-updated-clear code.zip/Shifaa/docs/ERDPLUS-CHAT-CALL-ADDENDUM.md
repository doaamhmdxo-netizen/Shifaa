# Shifaa — ERDPlus / Relational Schema addendum for Chat & Calls

This addendum closes the gap between the existing Use Case actor action **Chat & Video/Voice Call** and the original structural diagrams. It does not replace the university's original diagrams or change their notation. Recreate these entities and relationships in ERDPlus, then export the relational schema in the same academic style.

## Entities to add

1. **CONVERSATION** (`ConversationID` PK, `PatientID` FK, `DoctorID` FK, `AppointmentID` FK, `CreatedAt`, `UpdatedAt`). One conversation is associated with the patient, doctor, and eligible appointment. Candidate uniqueness: (`PatientID`, `DoctorID`, `AppointmentID`).
2. **CONVERSATION_MESSAGE** (`MessageID` PK, `ConversationID` FK, `SenderID`, `SenderRole`, `Body`, `CreatedAt`, `ReadAt`). A conversation has many messages; each message belongs to exactly one conversation.
3. **MESSAGE_ATTACHMENT** (`AttachmentID` PK, `MessageID` FK, `StorageKey`, `OriginalFileName`, `MediaType`, `ByteSize`, `ChecksumSHA256`, `CreatedAt`). A message can have zero or many attachments; each attachment belongs to one message.
4. **CALL_SESSION** (`CallSessionID` PK, `ConversationID` FK, `InitiatedBy`, `CallType`, `Status`, `ProviderRoomID`, `StartedAt`, `AnsweredAt`, `EndedAt`, `DurationSeconds`). A conversation can have zero or many call sessions; each call session belongs to one conversation.

## Relationships and cardinality

- PATIENT (1) —— (N) CONVERSATION.
- DOCTOR (1) —— (N) CONVERSATION.
- APPOINTMENT (1) —— (0..1 or N) CONVERSATION. Use 0..1 if the business rule is exactly one conversation per appointment; this project proposal uses a unique patient/doctor/appointment tuple.
- CONVERSATION (1) —— (N) CONVERSATION_MESSAGE.
- CONVERSATION_MESSAGE (1) —— (0..N) MESSAGE_ATTACHMENT.
- CONVERSATION (1) —— (0..N) CALL_SESSION.

## Mapping to the Use Case

The patient and doctor actors use the same conversation/message records. Voice/video calls are not separate actors or standalone entities; **CALL_SESSION** records each call attempt within a conversation. The current browser call preview is not a real call. Production calling requires authenticated signaling, a media provider/WebRTC, and STUN/TURN infrastructure.

## Integration notes

- Keep the existing Patient, Doctor, Specialty, Appointment, Review, and Pharmacy entities unchanged unless the approved university ERD already contains additional entities.
- Resolve the actual primary-key types and names for Patient, Doctor, and Appointment before adding foreign keys. The current SQL prototype uses `TEXT` placeholders because the canonical account schema is not yet connected.
- Store attachment bytes in private object storage, not as Data URLs in database rows or localStorage.
- Enforce conversation membership, appointment ownership, sender identity, attachment authorization, and call participant authorization on the server.
- The front-end package does not include editable ERDPlus or Visual Paradigm source projects. This document is the exact addition specification; the PDF diagram itself was not silently redrawn.
