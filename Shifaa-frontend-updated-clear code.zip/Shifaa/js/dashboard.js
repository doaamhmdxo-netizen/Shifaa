// ==========================================================
// dashboard.js: سلوك مشترك لكل صفحات الـ Dashboard
// (رسم الأيقونات + فتح وقفل الـ Sidebar على الموبايل)
// ==========================================================

document.addEventListener("DOMContentLoaded", function () {
  // بتحوّل كل <i data-lucide="..."> لأيقونة SVG (المكتبة بتتحمّل قبل الملف ده)
  if (window.lucide) {
    window.lucide.createIcons();
  }

  const sidebar = document.getElementById("sidebar");
  const menuToggle = document.querySelector(".menu-toggle");

  if (!sidebar || !menuToggle) {
    return;
  }

  function setOpen(isOpen) {
    sidebar.classList.toggle("is-open", isOpen);
    // aria-expanded: بيعرّف قارئ الشاشة إن القايمة مفتوحة ولا مقفولة
    menuToggle.setAttribute("aria-expanded", String(isOpen));
  }

  menuToggle.addEventListener("click", function (event) {
    event.stopPropagation(); // عشان ضغطة الفتح ما تتحسبش ضغطة "برا" فتقفل القايمة
    setOpen(!sidebar.classList.contains("is-open"));
  });

  // الضغط في أي مكان برا الـ Sidebar يقفله
  document.addEventListener("click", function (event) {
    if (!sidebar.contains(event.target)) {
      setOpen(false);
    }
  });

  // زر Esc يقفله
  document.addEventListener("keydown", function (event) {
    if (event.key === "Escape") {
      setOpen(false);
    }
  });
});