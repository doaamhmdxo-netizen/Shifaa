// ==========================================================
// otp.js: خانات رمز التحقق (٦ خانات) في صفحتي تفعيل البريد والتحقق بخطوتين
// ==========================================================

document.addEventListener("DOMContentLoaded", function () {
  const form = document.querySelector(".auth-form");
  const inputs = Array.from(document.querySelectorAll(".otp-input"));
  const codeField = document.getElementById("Code"); // حقل مخفي بيتبعت للسيرفر: الرمز كامل

  if (!form || !codeField || !inputs.length) return;

  // بيجمّع الأرقام من الخانات في حقل Code
  function updateCode() {
    codeField.value = inputs.map(function (input) { return input.value; }).join("");
  }

  inputs.forEach(function (input, index) {
    // كتابة رقم: نسيب أرقام بس، ونروح للخانة اللي بعدها
    input.addEventListener("input", function () {
      input.setCustomValidity("");
      input.value = input.value.replace(/\D/g, "").slice(0, 1);
      updateCode();
      if (input.value && index < inputs.length - 1) {
        inputs[index + 1].focus();
      }
    });

    // Backspace في خانة فاضية: نرجع للخانة اللي قبلها
    input.addEventListener("keydown", function (event) {
      if (event.key === "Backspace" && !input.value && index > 0) {
        inputs[index - 1].focus();
      }
    });

    // لصق الرمز كله مرة واحدة: بنوزّعه على الخانات
    input.addEventListener("paste", function (event) {
      event.preventDefault();
      const pasted = (event.clipboardData.getData("text") || "").replace(/\D/g, "");
      const digits = pasted.slice(0, inputs.length).split("");

      digits.forEach(function (digit, i) { inputs[i].value = digit; });
      updateCode();
      inputs[Math.min(digits.length, inputs.length - 1)].focus();
    });
  });

  // ---------- مؤقت للمرحلة أ فقط ----------
  // لو الرمز ناقص: بنوقف الإرسال ونقول للمستخدم. لو كامل: نروح للصفحة اللي في data-next-page
  // في المرحلة ب السيرفر هو اللي بيتحقق من الرمز ويحوّل الصفحة، فنمسح الجزء ده
  form.addEventListener("submit", function (event) {
    event.preventDefault();

    if (codeField.value.length < inputs.length) {
      const firstEmpty = inputs[codeField.value.length];
      firstEmpty.setCustomValidity(form.dataset.incompleteMessage);
      firstEmpty.reportValidity();
      return;
    }

    window.location.href = form.dataset.nextPage;
  });
});