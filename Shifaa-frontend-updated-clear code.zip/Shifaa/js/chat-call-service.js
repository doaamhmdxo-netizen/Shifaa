/* Local device preview + explicit realtime integration gate for Shifaa audio/video calls. */
(() => {
  'use strict';
  const isEnglish = () => (localStorage.getItem('shifaa-language') || localStorage.getItem('shifaa-auth-language')) === 'en';
  const t = (ar, en) => isEnglish() ? en : ar;
  let localStream = null;
  document.addEventListener('keydown', event => { if (event.key === 'Escape' && document.getElementById('shifaa-call-preview')) closeDialog(); });

  function closeDialog() {
    localStream?.getTracks().forEach(track => track.stop());
    localStream = null;
    document.getElementById('shifaa-call-preview')?.remove();
  }

  async function start(mode, details = {}) {
    // The project has no signaling endpoint yet. Do not claim that a remote call is connected.
    const layer = document.createElement('div');
    layer.id = 'shifaa-call-preview';
    layer.className = 'shifaa-call-preview';
    const isVideo = mode === 'video';
    const title = isVideo ? t('مكالمة فيديو','Video call') : t('مكالمة صوتية','Voice call');
    layer.innerHTML = `<div class="shifaa-call-preview__backdrop"></div><section class="shifaa-call-preview__panel" role="dialog" aria-modal="true" aria-labelledby="shifaa-call-title">
      <button type="button" class="shifaa-call-preview__close" aria-label="${t('إغلاق','Close')}">×</button>
      <div class="shifaa-call-preview__icon"><i data-lucide="${isVideo ? 'video' : 'phone'}"></i></div>
      <p class="shifaa-call-preview__eyebrow">${t('التواصل الآمن مع الطبيب','Secure doctor communication')}</p>
      <h2 id="shifaa-call-title">${title}</h2>
      <p class="shifaa-call-preview__peer">${t('المتصل به:','Calling:')} ${String(details.counterpart || t('المستخدم الآخر','Other user')).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}</p>
      <div class="shifaa-call-preview__media">${isVideo ? '<video autoplay muted playsinline></video>' : '<span class="shifaa-call-preview__audio-mark"><i data-lucide="mic"></i></span>'}</div>
      <div class="shifaa-call-preview__status" role="status">${t('هذه معاينة محلية للجهاز فقط. المكالمة الحية مع الطبيب تحتاج إلى ربط خادم الاتصال الآمن.','This is a local device preview only. A live call with the doctor requires a connected secure calling server.')}</div>
      <div class="shifaa-call-preview__actions"><button type="button" class="shifaa-call-preview__test">${t('اختبار','Test')} ${isVideo ? t('الكاميرا','camera') : t('الميكروفون','microphone')}</button><button type="button" class="shifaa-call-preview__end">${t('إنهاء','End')}</button></div>
    </section>`;
    document.body.append(layer);
    if (window.lucide) window.lucide.createIcons();
    layer.querySelector('.shifaa-call-preview__close').addEventListener('click', closeDialog);
    layer.querySelector('.shifaa-call-preview__backdrop').addEventListener('click', closeDialog);
    layer.querySelector('.shifaa-call-preview__end').addEventListener('click', closeDialog);
    layer.querySelector('.shifaa-call-preview__test').addEventListener('click', async () => {
      const status = layer.querySelector('.shifaa-call-preview__status');
      try {
        localStream = await navigator.mediaDevices.getUserMedia({ audio:true, video:isVideo });
        if (isVideo) {
          const video = layer.querySelector('video');
          if (video) video.srcObject = localStream;
        }
        status.textContent = t('تم تفعيل الجهاز بنجاح. تذكير: لم يتم الاتصال بالطبيب لأن خادم المكالمات غير مربوط بعد.','Your device is ready. Reminder: the doctor is not connected because the calling server has not been configured yet.');
      } catch (error) {
        status.textContent = t('لم نتمكن من الوصول للجهاز. راجع صلاحيات الميكروفون أو الكاميرا، واستخدم HTTPS أو localhost.','Could not access the device. Check microphone/camera permissions and use HTTPS or localhost.');
      }
    });
    layer.querySelector('.shifaa-call-preview__close').focus();
    return false;
  }

  window.ShifaaCalls = { start, end:closeDialog };
})();
