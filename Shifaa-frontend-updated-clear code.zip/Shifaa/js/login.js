// تسجيل الدخول في هذه الحزمة واجهة تجريبية؛ لا يوجد API للمصادقة بعد.
document.addEventListener("DOMContentLoaded", function () {
  const loginForm = document.querySelector(".auth-form");

  if (loginForm) {
    loginForm.addEventListener("submit", function (event) {
      event.preventDefault();
      let notice = document.getElementById("login-demo-notice");
      if (!notice) {
        notice = document.createElement("p");
        notice.id = "login-demo-notice";
        notice.className = "wf-registration-note";
        notice.setAttribute("role", "status");
        notice.setAttribute("aria-live", "polite");
        loginForm.prepend(notice);
      }
      notice.textContent = "تسجيل الدخول الفعلي غير متاح في هذه النسخة؛ لم يتم ربط نظام المصادقة بالخادم بعد. لم يتم تسجيل دخولك.";
    });
  }
});
