// ==========================================================
// forgot-password.js: سلوك صفحة استعادة كلمة المرور
// ==========================================================

document.addEventListener("DOMContentLoaded", function () {
  const forgotForm = document.querySelector(".auth-form");

  if (!forgotForm) return;

  // ---------- مؤقت للمرحلة أ فقط ----------
  // بنمنع الإرسال الحقيقي (الـ Live Server مش بيستقبل POST)
  // وبنودّي المستخدم للصفحة اللي بعدها في الرحلة: "تحقق من صندوق الوارد"
  // الفحص بتاع required و type="email" بيشتغل قبل الحدث ده
  // هنمسح الكود ده في المرحلة ب لأن السيرفر هو اللي هيرد ويحوّل الصفحة
  forgotForm.addEventListener("submit", function (event) {
    event.preventDefault();
    window.location.href = "reset-link-sent.html";
  });
});