// ==========================================================
// password-toggle.js: إظهار/إخفاء كل حقول الباسورد في الصفحة
// بيشتغل على أي .password-field، فنفس الملف يخدم أي صفحة فيها حقل أو أكتر
// ==========================================================

document.addEventListener("DOMContentLoaded", function () {
  document.querySelectorAll(".password-field").forEach(function (field) {
    const input = field.querySelector(".form-input");
    const toggleButton = field.querySelector(".toggle-password");
    if (!input || !toggleButton) return;

    toggleButton.addEventListener("click", function () {
      const isHidden = input.type === "password";
      input.type = isHidden ? "text" : "password";

      // النصوص جاية من data-attributes في الـ HTML
      toggleButton.textContent = isHidden
        ? toggleButton.dataset.hideText
        : toggleButton.dataset.showText;
    });
  });
});