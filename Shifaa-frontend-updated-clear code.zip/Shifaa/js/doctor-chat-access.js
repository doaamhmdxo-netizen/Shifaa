/* Booking-gated doctor chat entry points for the patient-facing doctor cards. */
(() => {
  'use strict';
  const $ = (selector, root = document) => root.querySelector(selector);
  const read = (key, fallback) => {
    try { return JSON.parse(localStorage.getItem(key) || 'null') ?? fallback; }
    catch { return fallback; }
  };
  const write = (key, value) => localStorage.setItem(key, JSON.stringify(value));
  const user = () => read('shifaa_currentUser', null) || read('currentUser', {}) || {};
  const patientId = () => String(user().id || user().email || user().Email || user().phone || user().PhoneNumber || 'demo-patient');
  const names = {
    '1': 'د. محمد حسن',
    '2': 'د. منى إبراهيم',
    '3': 'د. عمر عادل'
  };
  const isEnglish = () => (localStorage.getItem('shifaa-language') || localStorage.getItem('shifaa-auth-language')) === 'en';
  const t = (ar, en) => isEnglish() ? en : ar;

  function notice(message, actionLabel, actionHref) {
    let layer = $('#doctor-chat-gate');
    if (!layer) {
      layer = document.createElement('div');
      layer.id = 'doctor-chat-gate';
      layer.className = 'doctor-chat-gate';
      layer.innerHTML = `<div class="doctor-chat-gate__backdrop" data-gate-close></div>
        <section class="doctor-chat-gate__dialog" role="dialog" aria-modal="true" aria-labelledby="doctor-chat-gate-title">
          <button class="doctor-chat-gate__close" type="button" data-gate-close aria-label="${t('إغلاق','Close')}">×</button>
          <span class="doctor-chat-gate__icon"><i data-lucide="calendar-clock"></i></span>
          <h2 id="doctor-chat-gate-title">${t('المحادثة متاحة بعد الحجز','Chat is available after booking')}</h2>
          <p class="doctor-chat-gate__message"></p>
          <a class="doctor-chat-gate__action btn btn-primary" href="#"></a>
        </section>`;
      document.body.append(layer);
      layer.addEventListener('click', e => {
        if (e.target.closest('[data-gate-close]')) layer.classList.remove('is-open');
      });
      document.addEventListener('keydown', e => { if (e.key === 'Escape') layer.classList.remove('is-open'); });
    }
    $('.doctor-chat-gate__message', layer).textContent = message;
    const action = $('.doctor-chat-gate__action', layer);
    action.textContent = actionLabel;
    action.href = actionHref;
    layer.classList.add('is-open');
    if (window.lucide) window.lucide.createIcons();
  }

  function bookingFor(doctorId) {
    return read('shifaa_demo_bookings', []).find(b => {
      const owner = String(b.patientId || 'demo-patient');
      const target = String(b.DoctorId || b.doctorId || '1');
      const status = String(b.status || '').toLowerCase();
      return owner === patientId() && target === String(doctorId) && !['cancelled', 'canceled', 'ملغى'].includes(status);
    });
  }

  function openChat(doctorId, doctorName, booking) {
    const list = read('shifaa_conversations', []);
    let conversation = list.find(c => String(c.linkedAppointmentId) === String(booking.id)
      && String(c.patientId) === patientId());
    if (!conversation) {
      conversation = {
        id: `CHAT-${Date.now()}`,
        patientId: patientId(),
        doctorId: String(doctorId),
        linkedAppointmentId: booking.id,
        patientName: booking.PatientName || user().name || user().FullName || 'المريض',
        doctorName: doctorName || names[String(doctorId)] || booking.DoctorName || 'الطبيب',
        messages: [],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      list.push(conversation);
      write('shifaa_conversations', list);
    }
    write('shifaa_open_chat_id', conversation.id);
    if (window.ShifaaChat?.openConversation) {
      window.ShifaaChat.openConversation(conversation.id);
    } else {
      location.href = 'patient-dashboard.html#chats';
    }
  }

  function bind() {
    document.addEventListener('click', event => {
      const button = event.target.closest('[data-doctor-chat],[data-chat-doctor-id]');
      if (!button) return;
      event.preventDefault();
      const id = String(button.dataset.doctorId || button.dataset.chatDoctorId || '1');
      const name = button.dataset.doctorName || names[id] || button.closest('.doctor-card')?.querySelector('.doctor-card-name')?.textContent.trim() || 'الطبيب';
      const booking = bookingFor(id);
      if (!booking) {
        notice(
          t(`لازم تحجز موعد مع ${name} الأول علشان تقدر تبدأ المحادثة وتتابع مع الطبيب من خلال شفاء.`, `You need to book an appointment with ${name} before you can start a chat and follow up with your doctor through Shifaa.`),
          t('احجز موعد مع الطبيب','Book an appointment'),
          `book-appointment.html?doctor=${encodeURIComponent(id)}`
        );
        return;
      }
      openChat(id, name, booking);
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bind, { once: true });
  else bind();
})();
