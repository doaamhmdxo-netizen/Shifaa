(() => {
  const toggle = document.querySelector('.mobile-nav-toggle');
  const nav = document.querySelector('#public-nav');
  if (toggle && nav) {
    const updateMenuLabel = open => {
      const english = (localStorage.getItem('shifaa-language') || localStorage.getItem('shifaa-auth-language')) === 'en';
      toggle.setAttribute('aria-label', english ? (open ? 'Close menu' : 'Open menu') : (open ? 'إغلاق القائمة' : 'فتح القائمة'));
    };
    updateMenuLabel(nav.classList.contains('is-open'));
    window.addEventListener('shifaa:languagechange', () => updateMenuLabel(nav.classList.contains('is-open')));
    toggle.addEventListener('click', () => {
      const open = nav.classList.toggle('is-open');
      toggle.setAttribute('aria-expanded', String(open));
      updateMenuLabel(open);
    });
    nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
      nav.classList.remove('is-open');
      toggle.setAttribute('aria-expanded', 'false');
      updateMenuLabel(false);
    }));
  }
  const revealItems = document.querySelectorAll('[data-reveal]');
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    revealItems.forEach(item => observer.observe(item));
  } else {
    revealItems.forEach(item => item.classList.add('is-visible'));
  }
})();

// Protect service destinations from anonymous visitors: require sign-up or sign-in first.
(() => {
  const hasActiveUser = () => {
    try {
      const user = JSON.parse(localStorage.getItem('shifaa_currentUser') || 'null');
      return !!(user && typeof user === 'object' && (user.id || user.email || user.phone) && user.role);
    } catch { return false; }
  };

  const style = document.createElement('style');
  style.textContent = `
    .shifaa-auth-gate{position:fixed;inset:0;z-index:12000;display:grid;place-items:center;padding:20px;background:rgba(8,35,39,.58);backdrop-filter:blur(5px)}
    .shifaa-auth-gate[hidden]{display:none}
    .shifaa-auth-gate-card{position:relative;width:min(100%,440px);padding:34px 28px 28px;border-radius:24px;background:#fff;box-shadow:0 24px 80px rgba(0,0,0,.22);text-align:center;color:#173f42}
    .shifaa-auth-gate-close{position:absolute;top:12px;left:14px;border:0;background:#edf5f4;color:#315e60;width:36px;height:36px;border-radius:50%;font-size:22px;cursor:pointer}
    .shifaa-auth-gate-icon{display:grid;place-items:center;width:58px;height:58px;margin:0 auto 16px;border-radius:18px;background:#e4f4f1;color:#087780;font-size:30px;font-weight:800}
    .shifaa-auth-gate-card h2{margin:0 0 10px;font-size:25px;font-weight:900}
    .shifaa-auth-gate-card p{margin:0 0 23px;color:#648083;line-height:1.9}
    .shifaa-auth-gate-actions{display:grid;grid-template-columns:1fr 1fr;gap:12px}
    .shifaa-auth-gate-actions a{display:flex;justify-content:center;align-items:center;min-height:50px;padding:10px 14px;border-radius:13px;text-decoration:none;font-weight:800}
    .shifaa-auth-gate-register{background:#087780;color:#fff}.shifaa-auth-gate-login{border:1px solid #c9dddd;color:#087780;background:#fff}
    @media(max-width:420px){.shifaa-auth-gate-card{padding:30px 18px 22px}.shifaa-auth-gate-actions{grid-template-columns:1fr}}
  `;
  document.head.appendChild(style);

  const gate = document.createElement('div');
  gate.className = 'shifaa-auth-gate';
  gate.hidden = true;
  gate.setAttribute('role', 'dialog');
  gate.setAttribute('aria-modal', 'true');
  gate.setAttribute('aria-labelledby', 'shifaa-auth-gate-title');
  gate.innerHTML = `
    <section class="shifaa-auth-gate-card">
      <button class="shifaa-auth-gate-close" type="button" aria-label="إغلاق">×</button>
      <div class="shifaa-auth-gate-icon" aria-hidden="true">+</div>
      <h2 id="shifaa-auth-gate-title">أهلًا بيك في شِفاء</h2>
      <p>علشان تستخدم خدمات المنصة وتتابع الأطباء والصيدليات وملفك الصحي، أنشئ حسابًا جديدًا أو سجّل الدخول إلى حسابك.</p>
      <div class="shifaa-auth-gate-actions">
        <a class="shifaa-auth-gate-register" href="register.html">إنشاء حساب</a>
        <a class="shifaa-auth-gate-login" href="login.html">تسجيل الدخول</a>
      </div>
    </section>`;
  document.body.appendChild(gate);

  const updateGateLanguage = () => {
    const en = (localStorage.getItem('shifaa-language') || localStorage.getItem('shifaa-auth-language')) === 'en';
    gate.dir = en ? 'ltr' : 'rtl';
    gate.querySelector('.shifaa-auth-gate-close').setAttribute('aria-label', en ? 'Close' : 'إغلاق');
    gate.querySelector('#shifaa-auth-gate-title').textContent = en ? 'Welcome to Shifaa' : 'أهلًا بيك في شِفاء';
    gate.querySelector('.shifaa-auth-gate-card p').textContent = en ? 'To use the platform services, follow doctors and pharmacies, and manage your health file, create an account or sign in.' : 'علشان تستخدم خدمات المنصة وتتابع الأطباء والصيدليات وملفك الصحي، أنشئ حسابًا جديدًا أو سجّل الدخول إلى حسابك.';
    gate.querySelector('.shifaa-auth-gate-register').textContent = en ? 'Create account' : 'إنشاء حساب';
    gate.querySelector('.shifaa-auth-gate-login').textContent = en ? 'Log in' : 'تسجيل الدخول';
  };
  updateGateLanguage();
  window.addEventListener('shifaa:languagechange', updateGateLanguage);

  const close = () => { gate.hidden = true; document.body.style.overflow = ''; };
  gate.querySelector('.shifaa-auth-gate-close').addEventListener('click', close);
  gate.addEventListener('click', event => { if (event.target === gate) close(); });
  document.addEventListener('keydown', event => { if (event.key === 'Escape' && !gate.hidden) close(); });

  document.querySelectorAll('a[href]').forEach(link => {
    const href = link.getAttribute('href') || '';
    if (!href || href.startsWith('#') || /^(https?:|mailto:|tel:|javascript:)/i.test(href)) return;
    if (/^(index\.html|login\.html|register\.html)(\?.*)?$/i.test(href)) return;
    link.addEventListener('click', event => {
      if (hasActiveUser()) return;
      event.preventDefault();
      gate.hidden = false;
      document.body.style.overflow = 'hidden';
      gate.querySelector('.shifaa-auth-gate-close').focus();
    });
  });
})();
