// ==========================================================
// doctor-dashboard.js: اختيار يوم من أيام الأسبوع
// ==========================================================

document.addEventListener("DOMContentLoaded", function () {
  const dayTabs = document.querySelectorAll(".day-tab");

  dayTabs.forEach(function (tab) {
    tab.addEventListener("click", function () {
      // اليوم الواحد بس يبقى active
      dayTabs.forEach(function (other) {
        const isSelected = other === tab;
        other.classList.toggle("is-active", isSelected);
        // aria-pressed: قارئ الشاشة يعرف اليوم المختار
        other.setAttribute("aria-pressed", String(isSelected));
      });

      // في المرحلة ب هنا بنطلب مواعيد اليوم ده من السيرفر
    });
  });
});