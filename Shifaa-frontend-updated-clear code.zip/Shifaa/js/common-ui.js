/* Shifaa shared UI feedback: do not pretend unfinished destinations are working. */
document.addEventListener("DOMContentLoaded", () => {
  let toast;
  function notify(message) {
    if (!toast) {
      toast = document.createElement("div");
      toast.className = "shifaa-toast";
      toast.setAttribute("role", "status");
      toast.setAttribute("aria-live", "polite");
      document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.classList.add("is-visible");
    clearTimeout(window.__shifaaToastTimer);
    window.__shifaaToastTimer = setTimeout(() => toast.classList.remove("is-visible"), 2800);
  }
  document.querySelectorAll('a[href="#"]').forEach(link => {
    const label = (link.textContent || '').trim();
    const doctorWorkflowAction = link.closest('.page-content') && ['إضافة موعد','تعديل أوقات العمل','ابدأ الكشف','كل المواعيد','عرض الملف','add appointment','edit working hours','start exam','all appointments','view file'].some(text => label.toLowerCase().includes(text.toLowerCase()));
    if (link.matches('[data-wf-tab],[data-admin-go],[data-action]') || doctorWorkflowAction) return;
    if (/المساعدة|help/i.test((link.textContent || '').trim())) return;
    link.addEventListener("click", event => {
      event.preventDefault();
      const label = (link.textContent || "").trim();
      const english = (localStorage.getItem('shifaa-language') || localStorage.getItem('shifaa-auth-language')) === 'en';
      notify(label ? (english ? `“${label}” is not available in this demo version.` : `«${label}» غير متاحة في النسخة التجريبية الحالية.`) : (english ? 'This feature is not available in this demo version.' : 'هذه الخاصية غير متاحة في النسخة التجريبية الحالية.'));
    });
  });
});
