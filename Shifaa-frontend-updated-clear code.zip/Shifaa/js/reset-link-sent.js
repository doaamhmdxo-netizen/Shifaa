// ==========================================================
// reset-link-sent.js: عدّاد إعادة إرسال رابط الاستعادة
// ==========================================================

document.addEventListener("DOMContentLoaded", function () {
  const resendButton = document.getElementById("resend-button");

  if (!resendButton) return;

  // المدة بالثواني قبل ما نسمح بإعادة الإرسال
  const RESEND_SECONDS = 59;

  let remaining = RESEND_SECONDS; // الثواني المتبقية
  let timerId = null;             // رقم المؤقت، بنحتاجه عشان نوقفه

  const isEnglish = () => document.documentElement.lang === 'en';
  function formatTime(seconds) {
    const formatter = new Intl.NumberFormat(isEnglish() ? 'en-US' : 'ar-EG', {
      minimumIntegerDigits: 2,
      useGrouping: false
    });
    const minutes = Math.floor(seconds / 60);
    const rest = seconds % 60;
    return formatter.format(minutes) + ':' + formatter.format(rest);
  }

  // بيكتب النص + الوقت المتبقي على الزرار
  function showRemaining() {
    resendButton.textContent = (isEnglish() ? 'Resend in' : 'إعادة الإرسال خلال') + ' ' + formatTime(remaining);
  }

  function startCountdown() {
    remaining = RESEND_SECONDS;
    resendButton.disabled = true;   // مقفول لحد ما العدّاد يخلص
    showRemaining();

    clearInterval(timerId);         // لو كان في عدّاد شغال، نوقفه الأول

    // setInterval: بينفّذ الكود ده كل 1000 ملي ثانية (ثانية)
    timerId = setInterval(function () {
      remaining -= 1;

      if (remaining <= 0) {
        clearInterval(timerId);     // وقفنا العدّاد
        resendButton.disabled = false;
        resendButton.textContent = isEnglish() ? 'Resend link' : 'إعادة إرسال الرابط';
        return;
      }

      showRemaining();
    }, 1000);
  }

  // ---------- مؤقت للمرحلة أ فقط ----------
  // الضغط على "إعادة إرسال الرابط" بيبدأ العدّاد من جديد (بدل ما يبعت فعلًا)
  // في المرحلة ب السيرفر هو اللي هيبعت الإيميل
  resendButton.addEventListener("click", startCountdown);

  startCountdown();
  window.addEventListener('shifaa:languagechange', () => {
    if (remaining > 0) showRemaining();
    else resendButton.textContent = isEnglish() ? 'Resend link' : 'إعادة إرسال الرابط';
  });
});