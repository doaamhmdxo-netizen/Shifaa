/* Shifaa registration wizard: progressive, role-aware registration flow. */
(function () {
  'use strict';

  function initRegistrationWizard() {
    const form = document.querySelector('.auth-form');
    const roleSelect = document.getElementById('AccountRole');
    if (!form || !roleSelect || !location.pathname.endsWith('register.html')) return;
    if (form.dataset.stepWizardReady === 'true') return;
    form.dataset.stepWizardReady = 'true';

    const progress = document.createElement('section');
    progress.className = 'register-wizard-progress';
    progress.setAttribute('aria-live', 'polite');
    progress.innerHTML = '<div class="register-wizard-progress-top"><strong class="register-wizard-step-title">اختيار نوع الحساب</strong><span class="register-wizard-step-count"></span></div><div class="register-wizard-track" role="progressbar" aria-label="تقدم التسجيل" aria-valuemin="1" aria-valuemax="1" aria-valuenow="1"><span></span></div>';

    const controls = document.createElement('div');
    controls.className = 'register-wizard-controls';
    controls.innerHTML = '<button type="button" class="btn register-wizard-back" disabled>رجوع</button><button type="button" class="btn btn-primary register-wizard-next">التالي</button>';

    const formNote = form.querySelector('.wf-registration-note');
    if (formNote) formNote.classList.add('register-wizard-note');
    form.insertBefore(progress, form.firstChild);
    form.append(controls);

    let steps = [];
    let activeIndex = 0;
    let rebuilding = false;

    const titleFor = (node, index) => {
      if (node.matches('.account-role-group')) return 'اختيار نوع الحساب';
      if (node.matches('.wf-admin-invitation')) return 'تأكيد دعوة الإدارة';
      const label = node.querySelector('.form-label');
      if (label) return label.textContent.replace('*', '').trim();
      if (node.matches('.form-checkbox')) return 'الموافقة على الشروط';
      if (node.matches('.register-wizard-finish')) return 'مراجعة وإنشاء الحساب';
      return `الخطوة ${index + 1}`;
    };

    function collectSteps() {
      const roleGroup = form.querySelector('.account-role-group');
      const commonIds = ['FullName', 'Email', 'PhoneNumber', 'Password'];
      const collected = [];
      if (roleGroup) collected.push(roleGroup);
      commonIds.forEach(id => {
        const field = document.getElementById(id);
        const group = field?.closest('.form-group');
        if (group && !collected.includes(group)) collected.push(group);
      });

      const doctorSection = form.querySelector('.wf-doctor-registration-fields');
      if (doctorSection) {
        doctorSection.querySelectorAll(':scope .wf-doctor-registration-grid > .form-group').forEach(group => collected.push(group));
      }
      const adminSection = form.querySelector('.wf-admin-invitation');
      if (adminSection) collected.push(adminSection);

      const terms = form.querySelector('.form-checkbox');
      if (terms) collected.push(terms);
      return collected;
    }

    function fieldFor(step) {
      if (step.matches('.form-group')) return step.querySelector('input:not([type="checkbox"]),select,textarea');
      if (step.matches('.form-checkbox')) return step.querySelector('input[type="checkbox"]');
      if (step.matches('.wf-admin-invitation')) return step.querySelector('input,select,textarea');
      return null;
    }

    function showStep(index, focusField) {
      if (!steps.length) return;
      activeIndex = Math.max(0, Math.min(index, steps.length - 1));
      const active = steps[activeIndex];
      steps.forEach((step, i) => {
        step.classList.toggle('register-wizard-active', i === activeIndex);
        step.hidden = i !== activeIndex;
        step.setAttribute('aria-hidden', String(i !== activeIndex));
      });
      const doctorSection = form.querySelector('.wf-doctor-registration-fields');
      if (doctorSection) doctorSection.hidden = !doctorSection.contains(active);
      const title = progress.querySelector('.register-wizard-step-title');
      const count = progress.querySelector('.register-wizard-step-count');
      const bar = progress.querySelector('.register-wizard-track');
      const fill = bar.querySelector('span');
      title.textContent = titleFor(active, activeIndex);
      count.textContent = `الخطوة ${activeIndex + 1} من ${steps.length}`;
      bar.setAttribute('aria-valuemax', String(steps.length));
      bar.setAttribute('aria-valuenow', String(activeIndex + 1));
      fill.style.width = `${((activeIndex + 1) / steps.length) * 100}%`;
      controls.querySelector('.register-wizard-back').disabled = activeIndex === 0;
      controls.querySelector('.register-wizard-next').hidden = activeIndex === steps.length - 1;
      const submit = form.querySelector('button[type="submit"]');
      if (submit) submit.hidden = activeIndex !== steps.length - 1;
      const finishLinks = form.querySelector('.auth-switch');
      if (finishLinks) finishLinks.hidden = activeIndex !== steps.length - 1;
      if (formNote) formNote.hidden = activeIndex !== 0;
      if (focusField) {
        const field = fieldFor(active);
        if (field) window.setTimeout(() => field.focus({ preventScroll: true }), 80);
      }
    }

    function rebuild() {
      if (rebuilding) return;
      rebuilding = true;
      steps = collectSteps();
      // Hide non-step explanatory content while the user moves through the form.
      form.querySelectorAll('.info-box').forEach(node => { node.hidden = true; });
      showStep(0, false);
      rebuilding = false;
    }

    function validateCurrentStep() {
      const step = steps[activeIndex];
      if (!step) return true;
      const fields = [...step.querySelectorAll('input,select,textarea')].filter(el => !el.disabled && el.type !== 'hidden');
      for (const field of fields) {
        if (field.required && !field.checkValidity()) {
          field.reportValidity();
          field.focus({ preventScroll: true });
          return false;
        }
        if (field.value && !field.checkValidity()) {
          field.reportValidity();
          field.focus({ preventScroll: true });
          return false;
        }
      }
      return true;
    }

    function nextStep() {
      if (!validateCurrentStep()) return;
      if (activeIndex < steps.length - 1) showStep(activeIndex + 1, true);
    }

    controls.querySelector('.register-wizard-next').addEventListener('click', nextStep);
    controls.querySelector('.register-wizard-back').addEventListener('click', () => showStep(activeIndex - 1, true));

    // Move forward when a field is completed and the user leaves it, not while they are still typing.
    form.addEventListener('change', event => {
      if (rebuilding || activeIndex >= steps.length - 1) return;
      const active = steps[activeIndex];
      if (!active || !active.contains(event.target) || event.target === roleSelect) return;
      if (event.target.matches('input,select,textarea') && event.target.checkValidity()) {
        window.setTimeout(() => {
          if (activeIndex < steps.length - 1 && steps[activeIndex] === active && document.activeElement !== controls.querySelector('.register-wizard-next')) {
            nextStep();
          }
        }, 0);
      }
    });

    // Enter advances the current field; the final step keeps the native submit behavior.
    form.addEventListener('keydown', event => {
      if (event.key !== 'Enter' || event.target.tagName === 'TEXTAREA' || activeIndex >= steps.length - 1) return;
      if (event.target.matches('input') && !event.target.closest('.wf-admin-invitation')) {
        event.preventDefault();
        nextStep();
      }
    });

    roleSelect.addEventListener('change', () => {
      // workflows.js updates role-specific fields first; rebuild after its synchronous handler.
      window.setTimeout(() => { rebuild(); }, 0);
    });

    // Start after workflows.js has injected the selected role's additional fields.
    rebuild();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initRegistrationWizard, { once: true });
  else initRegistrationWizard();
})();
