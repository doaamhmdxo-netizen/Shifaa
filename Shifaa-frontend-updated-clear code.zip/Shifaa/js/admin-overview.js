// Admin overview: responsive analytics chart + support inbox snapshot.
document.addEventListener("DOMContentLoaded", function () {
  const styles = getComputedStyle(document.documentElement);
  const cairoColor = styles.getPropertyValue("--color-primary").trim() || "#087780";
  const gizaColor = styles.getPropertyValue("--color-chart-giza").trim() || "#69a9a2";
  const mutedColor = styles.getPropertyValue("--color-text-muted").trim() || "#718482";
  const borderColor = styles.getPropertyValue("--color-border").trim() || "#e3ece9";
  const canvas = document.getElementById("appointments-chart");
  const isEnglish = () => document.documentElement.lang === "en";
  const monthLabels = three => isEnglish() ? (three ? ["Sep", "Oct", "Nov"] : ["Jun", "Jul", "Aug", "Sep", "Oct", "Nov"]) : (three ? ["سبتمبر", "أكتوبر", "نوفمبر"] : ["يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر"]);

  // The chart is optional: the admin screen and support inbox must still work offline.
  if (canvas && window.Chart) {
    Chart.defaults.font.family = styles.getPropertyValue("--font-family") || "Tajawal, sans-serif";
    Chart.defaults.color = mutedColor;
    const chart = new Chart(canvas, {
      type: "bar",
      data: {
        labels: monthLabels(false),
        datasets: [
          { label: "القاهرة", data: [250, 330, 380, 440, 490, 570], backgroundColor: cairoColor, borderRadius: 5 },
          { label: "الجيزة", data: [170, 220, 280, 325, 400, 460], backgroundColor: gizaColor, borderRadius: 5 }
        ]
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          x: { grid: { display: false } },
          y: { min: 0, max: 600, ticks: { stepSize: 200 }, grid: { color: borderColor } }
        }
      }
    });
    window.__shifaaAppointmentsChart = chart;
    const period = document.getElementById("ChartPeriod");
    if (period) period.addEventListener("change", function () {
      const threeMonths = period.value === "3";
      chart.data.labels = monthLabels(threeMonths);
      chart.data.datasets[0].data = threeMonths ? [440, 490, 570] : [250, 330, 380, 440, 490, 570];
      chart.data.datasets[1].data = threeMonths ? [325, 400, 460] : [170, 220, 280, 325, 400, 460];
      chart.update();
    });
  }

  function renderSupportSnapshot() {
    const en = isEnglish();
    let messages = [];
    try { messages = JSON.parse(localStorage.getItem("shifaa_supportMessages") || "[]"); } catch (_) { messages = []; }
    const count = document.getElementById("admin-new-message-count");
    const preview = document.getElementById("admin-inbox-preview");
    const fresh = messages.filter(item => ["جديدة", "New"].includes(String(item.status || "").trim())).length;
    if (count) count.textContent = en ? `${fresh} new messages · Open inbox` : `${fresh} رسالة جديدة · فتح الصندوق`;
    if (preview) {
      preview.replaceChildren();
      if (!messages.length) {
        const empty = document.createElement("span");
        empty.textContent = en ? "No messages received yet" : "لا توجد رسائل واردة حتى الآن";
        preview.append(empty);
      } else {
        messages.slice(0, 3).forEach(item => {
          const chip = document.createElement("span");
          const role = en ? (item.role === "doctor" ? "Doctor" : "Patient") : (item.roleLabel || (item.role === "doctor" ? "طبيب" : "مريض"));
          const status = en ? ({"جديدة":"New","قيد المراجعة":"Under review","تم الرد":"Replied","مغلقة":"Closed"}[item.status] || item.status || "New") : (item.status || "جديدة");
          chip.textContent = `${item.from || item.senderName || (en ? "User" : "مستخدم")} · ${role} · ${status}`;
          preview.append(chip);
        });
      }
    }
  }
  renderSupportSnapshot();
  window.addEventListener("shifaa:languagechange", () => {
    if (window.__shifaaAppointmentsChart) {
      const chart = window.__shifaaAppointmentsChart;
      const three = document.getElementById("ChartPeriod")?.value === "3";
      chart.data.labels = monthLabels(three); chart.update();
    }
    renderSupportSnapshot();
  });
  window.addEventListener("storage", event => {
    if (event.key === "shifaa_supportMessages") renderSupportSnapshot();
  });
});
