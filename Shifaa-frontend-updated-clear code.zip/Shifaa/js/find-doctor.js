document.addEventListener('DOMContentLoaded', () => {
  const form = document.querySelector('.find-form');
  const list = document.querySelector('.result-list');
  if (!form || !list) return;
  const cards = [...list.querySelectorAll('.doctor-card')];
  const term = form.querySelector('#SearchTerm');
  const spec = form.querySelector('#Specialty');
  const gov = form.querySelector('#Governorate');
  const max = document.querySelector('#MaxPrice');
  const sort = document.querySelector('#SortBy');
  const norm = value => (value || '').toLocaleLowerCase().replace(/[أإآ]/g, 'ا').trim();
  const english = () => (localStorage.getItem('shifaa-language') || localStorage.getItem('shifaa-auth-language')) === 'en';
  const contains = (text, ar, en) => text.includes(ar) || text.includes(en);
  const dataValue = (card, key, fallback='') => card.dataset[key] ?? card.getAttribute(`data-${key.replace(/[A-Z]/g, m => '-'+m.toLowerCase())}`) ?? fallback;
  const parseDate = value => { const d = value ? new Date(value) : null; return d && !Number.isNaN(d.getTime()) ? d : null; };
  const latinDigits = value => String(value || '').replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));
  const dayStart = date => new Date(date.getFullYear(), date.getMonth(), date.getDate());

  function apply() {
    const q = norm(term?.value);
    const area = gov?.value || 'CairoGiza';
    const specialty = spec?.value || 'All';
    const maxPrice = Number(max?.value || 800);
    const filterGovernorate = form.querySelector('[name="GovernorateFilter"]:checked')?.value || 'All';
    let shown = cards.filter(card => {
      const text = norm(card.innerText);
      const price = Number(latinDigits(dataValue(card,'price',(card.querySelector('.doctor-card-price')?.innerText || ''))).replace(/[^0-9]/g, ''));
      const city = norm(dataValue(card,'city',dataValue(card,'governorate','')));
      const hasCairo = city ? /القاهرة|cairo/.test(city) : contains(text, 'القاهرة', 'cairo');
      const hasGiza = city ? /الجيزة|giza/.test(city) : contains(text, 'الجيزة', 'giza');
      const areaOk = (area === 'CairoGiza' || (area === 'Cairo' ? hasCairo : hasGiza))
        && (filterGovernorate === 'All' || (filterGovernorate === 'Cairo' ? hasCairo : hasGiza));
      const cardSpecialty = norm(dataValue(card,'specialty',text));
      const specOk = specialty === 'Cardiology' ? /قلب|اوعية|cardio/.test(cardSpecialty)
        : specialty === 'InternalMedicine' ? /باطنة|internal medicine/.test(cardSpecialty)
        : specialty === 'Pediatrics' ? /اطفال|pediatric/.test(cardSpecialty)
        : specialty === 'Dentistry' ? /اسنان|dentist/.test(cardSpecialty) : true;
      const ratingText = latinDigits(dataValue(card,'rating',card.querySelector('.rating')?.innerText || ''));
      const ratingMatch = ratingText.match(/[0-9]+(?:\.[0-9]+)?/);
      const rating = ratingMatch ? Number(ratingMatch[0]) : 0;
      const minimumRating = Number(form.querySelector('[name="MinRating"]:checked')?.value || 0);
      const selectedAvailability = ['AvailableToday','AvailableTomorrow','AvailableThisWeek'].filter(name => form.querySelector(`[name="${name}"]:checked`));
      const badgeText = norm(card.querySelector('.badge-success')?.innerText || '');
      const availableDays = norm(dataValue(card,'availableDays',badgeText));
      const nextDate = parseDate(dataValue(card,'nextAvailable',''));
      const today = dayStart(new Date()), tomorrow = new Date(today); tomorrow.setDate(tomorrow.getDate()+1);
      const weekEnd = new Date(today); weekEnd.setDate(weekEnd.getDate()+7);
      const availabilityMatches = {
        AvailableToday: /today|اليوم/.test(availableDays) || (nextDate && dayStart(nextDate).getTime()===today.getTime()),
        AvailableTomorrow: /tomorrow|غدًا|غدا/.test(availableDays) || (nextDate && dayStart(nextDate).getTime()===tomorrow.getTime()),
        AvailableThisWeek: /week|الأسبوع/.test(availableDays) || (nextDate && nextDate>=today && nextDate<weekEnd) || /today|اليوم|tomorrow|غدًا|غدا/.test(availableDays)
      };
      const timingOk = !selectedAvailability.length || selectedAvailability.some(name => availabilityMatches[name]);
      return (!q || text.includes(q)) && areaOk && specOk && price <= maxPrice && (!minimumRating || rating >= minimumRating) && timingOk;
    });
    const mode = sort?.value;
    const originalOrder = new Map(cards.map((card,index)=>[card,index]));
    const priceOf = item => Number(latinDigits(dataValue(item,'price',item.querySelector('.doctor-card-price')?.innerText || '')).replace(/[^0-9]/g,'')) || Number.MAX_SAFE_INTEGER;
    const ratingOf = item => Number(latinDigits(dataValue(item,'rating',item.querySelector('.rating')?.innerText || '')).match(/[0-9]+(?:\.[0-9]+)?/)?.[0] || 0);
    if (mode === 'PriceLow' || mode === 'PriceHigh') shown.sort((a,b)=>(priceOf(a)-priceOf(b))*(mode==='PriceLow'?1:-1));
    else if (mode === 'Rating') shown.sort((a,b)=>ratingOf(b)-ratingOf(a));
    else shown.sort((a,b)=>originalOrder.get(a)-originalOrder.get(b));
    cards.forEach(card => { card.hidden = !shown.includes(card); });
    shown.forEach(card => list.appendChild(card));
    const heading = document.querySelector('.results-header .panel-title');
    if (heading) heading.textContent = english() ? `${shown.length} matching results` : `${shown.length} نتائج مطابقة`;
    let empty = document.getElementById('doctor-empty');
    if (!shown.length) {
      if (!empty) {
        empty = document.createElement('p'); empty.id = 'doctor-empty'; empty.className = 'card'; empty.style.padding = '20px';
        empty.textContent = english() ? 'No matching results. Try changing your search or filters.' : 'لا توجد نتائج مطابقة. جرّب تعديل البحث أو الفلاتر.'; list.appendChild(empty);
      } else {
        empty.textContent = english() ? 'No matching results. Try changing your search or filters.' : 'لا توجد نتائج مطابقة. جرّب تعديل البحث أو الفلاتر.';
      }
    } else empty?.remove();
  }
  form.addEventListener('submit', event => { event.preventDefault(); apply(); });
  form.addEventListener('input', apply);
  form.addEventListener('change', apply);
  form.addEventListener('reset', () => setTimeout(apply, 0));
  sort?.addEventListener('change', apply);
  window.addEventListener('shifaa:languagechange', apply);
  apply();
});
