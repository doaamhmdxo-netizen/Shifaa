/* Shifaa messaging experience. Local browser storage is used until the authenticated backend/realtime service is connected. */
(() => {
  'use strict';
  const $ = (selector, root = document) => root.querySelector(selector);
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]));
  const read = (key, fallback) => { try { return JSON.parse(localStorage.getItem(key) || 'null') ?? fallback; } catch { return fallback; } };
  const write = (key, value) => { try { localStorage.setItem(key, JSON.stringify(value)); return true; } catch (error) { notify(t('مساحة التخزين ممتلئة. احذف بعض المرفقات أو المحادثات القديمة.','Browser storage is full. Remove older attachments or conversations.')); return false; } };
  const currentUser = () => read('shifaa_currentUser', null) || read('currentUser', {}) || {};
  const patientId = () => String(currentUser().id || currentUser().email || currentUser().Email || currentUser().phone || currentUser().PhoneNumber || 'demo-patient');
  const doctorId = () => String(read('shifaa_doctorSettings', null)?.doctorId || read('doctorSettings', null)?.doctorId || currentUser().doctorId || '1');
  const role = () => document.body.dataset.role === 'doctor' ? 'doctor' : 'patient';
  const isEnglish = () => (localStorage.getItem('shifaa-language') || localStorage.getItem('shifaa-auth-language')) === 'en';
  const t = (ar, en) => isEnglish() ? en : ar;
  const conversations = () => read('shifaa_conversations', []);
  const bookings = () => read('shifaa_demo_bookings', []);
  const formatTime = value => {
    if (!value) return '';
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? '' : date.toLocaleString(isEnglish() ? 'en-US' : 'ar-EG', { day:'numeric', month:'short', hour:'2-digit', minute:'2-digit' });
  };
  const lastMessage = c => (c.messages || []).slice(-1)[0];
  let activeRecorder = null;
  let activeStream = null;
  let recordingTimer = null;
  let recordingStartedAt = 0;

  function notify(message) {
    let node = $('#chat-feedback');
    if (!node) {
      node = document.createElement('div'); node.id = 'chat-feedback'; node.className = 'chat-feedback';
      node.setAttribute('role', 'status'); node.setAttribute('aria-live', 'polite'); document.body.append(node);
    }
    node.textContent = message; node.classList.add('is-visible');
    clearTimeout(window.__shifaaChatFeedbackTimer);
    window.__shifaaChatFeedbackTimer = setTimeout(() => node.classList.remove('is-visible'), 4000);
  }

  function bookingForConversation(booking) {
    return {
      id: `CHAT-${Date.now()}`,
      patientId: String(booking.patientId || patientId()),
      doctorId: String(booking.DoctorId || booking.doctorId || '1'),
      linkedAppointmentId: booking.id,
      patientName: booking.PatientName || currentUser().name || currentUser().FullName || 'المريض',
      doctorName: booking.DoctorName || 'الطبيب المختار',
      messages: [], createdAt: new Date().toISOString(), updatedAt: new Date().toISOString()
    };
  }

  function attachmentMarkup(message) {
    if (message.audioDataUrl) return `<div class="chat-audio-attachment"><span class="chat-attachment-icon"><i data-lucide="audio-lines"></i></span><div><strong>${esc(t('رسالة صوتية','Voice message'))}</strong><audio controls preload="metadata" src="${esc(message.audioDataUrl)}"></audio></div></div>`;
    const file = message.file;
    if (!file?.dataUrl) return '';
    if (file.kind === 'image') return `<a class="chat-image-attachment" href="${esc(file.dataUrl)}" target="_blank" rel="noopener"><img src="${esc(file.dataUrl)}" alt="${esc(file.name || t('صورة مرفقة','Attached image'))}"></a>`;
    return `<a class="chat-file-attachment" href="${esc(file.dataUrl)}" download="${esc(file.name || 'attachment')}"><i data-lucide="file-text"></i><span>${esc(file.name || t('ملف مرفق','Attached file'))}</span><small>${esc(file.sizeLabel || '')}</small></a>`;
  }

  function renderMessages(conversation, tabRole) {
    return (conversation.messages || []).map(message => {
      const mine = message.senderRole === tabRole;
      return `<div class="chat-bubble-row ${mine ? 'mine' : 'theirs'}">
        <article class="chat-bubble">
          ${message.body ? `<p>${esc(message.body)}</p>` : ''}
          ${attachmentMarkup(message)}
          <time>${esc(formatTime(message.createdAt))}</time>
        </article>
      </div>`;
    }).join('');
  }

  function render(tabRole, selectedId) {
    const main = $('.page-content');
    if (!main) return;
    const isDoctor = tabRole === 'doctor';
    const all = conversations();
    const visible = all.filter(c => isDoctor ? String(c.doctorId) === doctorId() : String(c.patientId) === patientId());
    const requestedId = selectedId || read('shifaa_open_chat_id', null);
    const selected = visible.find(c => String(c.id) === String(requestedId))
      || visible.slice().sort((a, b) => new Date(b.updatedAt || 0) - new Date(a.updatedAt || 0))[0] || null;
    const title = isDoctor ? 'محادثات المرضى' : 'محادثاتي مع الأطباء';
    const intro = isDoctor ? 'تابع رسائل المرضى المرتبطين بعيادتك ورد عليهم من داخل شِفاء.' : 'كل محادثاتك مع الأطباء الذين اخترتهم أو حجزت لديهم في مكان واحد.';
    const contacts = visible.slice().sort((a, b) => new Date(b.updatedAt || 0) - new Date(a.updatedAt || 0));
    const contactHtml = contacts.map(c => {
      const person = isDoctor ? c.patientName : c.doctorName;
      const last = lastMessage(c);
      const unread = (c.messages || []).filter(m => m.senderRole !== tabRole && !(m.readBy || []).includes(tabRole)).length;
      const preview = last?.body || (last?.audioDataUrl ? t('رسالة صوتية','Voice message') : last?.file ? t('ملف مرفق','Attachment') : t('ابدأ المحادثة','Start a conversation'));
      return `<button class="chat-contact ${selected?.id === c.id ? 'is-active' : ''}" type="button" data-chat-open="${esc(c.id)}">
        <span class="chat-contact-avatar">${esc((person || '؟').slice(0, 1))}</span>
        <span class="chat-contact-main"><strong>${esc(person || (isDoctor ? 'مريض' : 'طبيب'))}</strong><small>${esc(preview)}</small></span>
        <span class="chat-contact-side"><time>${esc(formatTime(last?.createdAt || c.updatedAt))}</time>${unread ? `<i>${unread}</i>` : ''}</span>
      </button>`;
    }).join('');

    let bookingHtml = '';
    const eligible = !isDoctor ? bookings().filter(b => String(b.patientId || 'demo-patient') === patientId()) : [];
    const unused = eligible.filter(b => !visible.some(c => String(c.linkedAppointmentId) === String(b.id)));
    if (unused.length) {
      bookingHtml = `<div class="chat-booking-list"><div class="chat-subheading">ابدأ محادثة مع طبيب حجزت لديه</div>${unused.map(b => `
        <div class="chat-booking-row"><div><strong>${esc(b.DoctorName || 'الطبيب المختار')}</strong><small>${esc(b.AppointmentDate || '')} ${esc(b.AppointmentTime || '')}</small></div>
        <button class="chat-start-btn" type="button" data-chat-start="${esc(b.id)}">بدء المحادثة</button></div>`).join('')}</div>`;
    }

    const messageHtml = selected ? renderMessages(selected, tabRole) : '';
    const chatPanel = selected ? `
      <header class="chat-conversation-head">
        <span class="chat-contact-avatar large">${esc(((isDoctor ? selected.patientName : selected.doctorName) || '؟').slice(0, 1))}</span>
        <div class="chat-conversation-person"><strong>${esc(isDoctor ? selected.patientName : selected.doctorName)}</strong><small>${t(isDoctor ? 'محادثة مع مريض' : 'محادثة مع طبيب تم اختياره أو الحجز لديه', isDoctor ? 'Patient conversation' : 'Conversation with your selected or booked doctor')}</small></div>
        <div class="chat-call-actions">
          <button class="chat-icon-action" type="button" data-chat-call="audio" title="${t('مكالمة صوتية','Voice call')}" aria-label="${t('مكالمة صوتية','Voice call')}"><i data-lucide="phone"></i></button>
          <button class="chat-icon-action video" type="button" data-chat-call="video" title="${t('مكالمة فيديو','Video call')}" aria-label="${t('مكالمة فيديو','Video call')}"><i data-lucide="video"></i></button>
        </div>
        <span class="chat-secure-label">${t('محادثة خاصة','Private chat')}</span>
      </header>
      <div class="chat-messages" id="chat-messages" aria-live="polite">${messageHtml || `<div class="chat-empty-state">${t('ابدأ المحادثة برسالة ترحيب.','Send a hello to start the conversation.')}</div>`}</div>
      <div class="chat-composer-tools">
        <button type="button" class="chat-tool-button" id="chat-record-button"><i data-lucide="mic"></i><span>${t('تسجيل صوتي','Record voice')}</span></button>
        <button type="button" class="chat-tool-button" id="chat-attach-button"><i data-lucide="paperclip"></i><span>${t('إرفاق ملف','Attach file')}</span></button>
        <input type="file" id="chat-attachment-input" accept="image/*,audio/*,video/*,.pdf" hidden>
        <span id="chat-record-status" class="chat-record-status" aria-live="polite" data-i18n-skip data-i18n-dynamic></span>
      </div>
      <form class="chat-composer" id="chat-composer">
        <label class="visually-hidden" for="chat-message-input">${t('اكتب رسالتك','Type your message')}</label>
        <textarea id="chat-message-input" name="message" rows="1" maxlength="3000" placeholder="${t('اكتب رسالتك هنا...','Type your message here...')}"></textarea>
        <button type="submit" aria-label="${t('إرسال الرسالة','Send message')}"><span>${t('إرسال','Send')}</span><i data-lucide="send"></i></button>
      </form>` : `
      <div class="chat-empty-state chat-welcome"><span class="chat-welcome-icon"><i data-lucide="messages-square"></i></span>
        <h2>${t(isDoctor ? 'رسائلك مع المرضى هتظهر هنا' : 'ابدأ محادثة مع طبيبك', isDoctor ? 'Your patient messages will appear here' : 'Start a conversation with your doctor')}</h2>
        <p>${t(isDoctor ? 'عندما يبدأ مريض مرتبط بعيادتك محادثة، ستظهر هنا لتتمكن من الرد عليه.' : 'اختار محادثة من القائمة، أو ابدأ محادثة جديدة مع طبيب حجزت لديه.', isDoctor ? 'When a patient with an appointment starts a chat, it will appear here.' : 'Choose a conversation, or start a new chat with a doctor you have booked.')}</p>
        ${!isDoctor ? `<a class="chat-find-doctor" href="find-doctor.html">${t('ابحث عن طبيب','Find a doctor')}</a>` : ''}
      </div>`;

    main.innerHTML = `
      <div class="page-header"><div><h1 class="page-title">${title}</h1><p class="page-subtitle">${intro}</p></div></div>
      <div class="chat-demo-notice"><strong>${t('تنبيه النسخة التجريبية:','Demo notice:')}</strong> ${t('الرسائل والتسجيلات الصوتية في هذه النسخة تُحفظ داخل المتصفح الحالي فقط. المحادثات بين أجهزة وحسابات مختلفة، والمكالمات الحية، تحتاج إلى تشغيل Backend وخدمة اتصال فوري آمنة.','Messages and voice recordings in this version are saved only in this browser. Cross-device messaging and live calls require a secure backend and realtime signaling service.')}</div>
      <section class="chat-workspace" aria-label="${t('مساحة المحادثات','Chat workspace')}">
        <aside class="chat-sidebar-panel"><div class="chat-panel-heading"><div><strong>${t('المحادثات','Conversations')}</strong><small>${contacts.length} ${t('محادثة','conversations')}</small></div><span class="chat-count-icon">${contacts.length}</span></div>
          <div class="chat-contacts">${contactHtml || `<div class="chat-empty-contacts">${t('لا توجد محادثات بعد.','No conversations yet.')}</div>`}</div>${bookingHtml}
          ${!isDoctor && !eligible.length ? `<div class="chat-booking-hint">${t('ابدأ باختيار طبيب وحجز موعد، وبعدها هيظهر لك خيار بدء المحادثة هنا.','Choose a doctor and book an appointment first. You can then start a conversation here.')}</div>` : ''}
        </aside>
        <section class="chat-conversation-panel">${chatPanel}</section>
      </section>`;

    $('.chat-contacts', main)?.addEventListener('click', e => {
      const button = e.target.closest('[data-chat-open]');
      if (button) { write('shifaa_open_chat_id', button.dataset.chatOpen); render(tabRole, button.dataset.chatOpen); }
    });
    $('.chat-booking-list', main)?.addEventListener('click', e => {
      const button = e.target.closest('[data-chat-start]');
      if (!button) return;
      const booking = bookings().find(b => String(b.id) === button.dataset.chatStart);
      if (!booking) return;
      const list = conversations();
      let conversation = list.find(c => String(c.linkedAppointmentId) === String(booking.id));
      if (!conversation) { conversation = bookingForConversation(booking); list.push(conversation); write('shifaa_conversations', list); }
      write('shifaa_open_chat_id', conversation.id);
      render(tabRole, conversation.id);
    });

    const composer = $('#chat-composer', main);
    composer?.addEventListener('submit', e => {
      e.preventDefault();
      const input = $('#chat-message-input', composer);
      const body = input.value.trim();
      if (!body || !selected) return;
      addMessage(selected.id, tabRole, { body });
      render(tabRole, selected.id);
      $('#chat-message-input', main)?.focus();
    });

    $('#chat-record-button', main)?.addEventListener('click', toggleRecording);
    $('#chat-attach-button', main)?.addEventListener('click', () => $('#chat-attachment-input', main)?.click());
    $('#chat-attachment-input', main)?.addEventListener('change', e => handleFile(e.target.files?.[0], tabRole, selected?.id));
    main.querySelectorAll('[data-chat-call]').forEach(button => button.addEventListener('click', () => {
      const mode = button.dataset.chatCall;
      const counterpart = isDoctor ? selected?.patientName : selected?.doctorName;
      if (window.ShifaaCalls?.start) window.ShifaaCalls.start(mode, { conversationId: selected?.id, counterpart });
      else notify(t('خدمة المكالمات تحتاج إلى إعداد خادم الاتصال الآمن قبل إجراء مكالمة فعلية.','Live calls require the secure realtime server to be configured first.'));
    }));

    if (selected) {
      const list = conversations();
      const current = list.find(c => c.id === selected.id);
      if (current) {
        let changed = false;
        (current.messages || []).forEach(m => {
          if (m.senderRole !== tabRole) { m.readBy = m.readBy || []; if (!m.readBy.includes(tabRole)) { m.readBy.push(tabRole); changed = true; } }
        });
        if (changed) write('shifaa_conversations', list);
      }
      write('shifaa_open_chat_id', selected.id);
    }
    document.querySelectorAll('.sidebar-nav .nav-item').forEach(a => {
      const active = a.dataset.wfTab === 'chats';
      a.classList.toggle('active', active);
      if (active) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
    });
    if (window.lucide) window.lucide.createIcons();
    scrollMessagesToBottom();
  }

  function addMessage(conversationId, senderRole, payload) {
    const list = conversations();
    const current = list.find(c => String(c.id) === String(conversationId));
    if (!current) return false;
    const now = new Date().toISOString();
    current.messages = current.messages || [];
    current.messages.push({ id:`MSG-${Date.now()}`, senderId: senderRole === 'doctor' ? doctorId() : patientId(), senderRole, ...payload, createdAt:now, readBy:[senderRole] });
    current.updatedAt = now;
    return write('shifaa_conversations', list);
  }

  function scrollMessagesToBottom() {
    const panel = $('#chat-messages');
    if (panel) panel.scrollTop = panel.scrollHeight;
  }

  function setRecordStatus(text, isRecording = false) {
    const status = $('#chat-record-status');
    const button = $('#chat-record-button');
    if (status) status.textContent = text;
    if (button) {
      button.classList.toggle('is-recording', isRecording);
      const span = $('span', button);
      if (span) span.textContent = isRecording ? t('إيقاف التسجيل','Stop recording') : t('تسجيل صوتي','Record voice');
      const icon = $('i', button);
      if (icon) icon.setAttribute('data-lucide', isRecording ? 'square' : 'mic');
    }
    if (window.lucide) window.lucide.createIcons();
  }

  async function toggleRecording() {
    const selectedId = read('shifaa_open_chat_id', null);
    if (!selectedId) return;
    if (activeRecorder && activeRecorder.state === 'recording') { activeRecorder.stop(); return; }
    if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder) {
      notify(t('المتصفح لا يدعم تسجيل الصوت. افتح شفاء من متصفح حديث وعلى اتصال آمن HTTPS.','This browser does not support audio recording. Open Shifaa in a modern browser over HTTPS.'));
      return;
    }
    try {
      activeStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const options = MediaRecorder.isTypeSupported('audio/webm;codecs=opus') ? { mimeType:'audio/webm;codecs=opus' } : {};
      activeRecorder = new MediaRecorder(activeStream, options);
      const chunks = [];
      activeRecorder.addEventListener('dataavailable', e => { if (e.data?.size) chunks.push(e.data); });
      activeRecorder.addEventListener('stop', async () => {
        clearInterval(recordingTimer);
        const blob = new Blob(chunks, { type: activeRecorder.mimeType || 'audio/webm' });
        activeStream?.getTracks().forEach(track => track.stop()); activeStream = null;
        activeRecorder = null;
        setRecordStatus('');
        if (!blob.size) return;
        if (blob.size > 900 * 1024) { notify(t('التسجيل طويل جدًا للنسخة التجريبية. جرّب تسجيلًا أقصر.','Recording is too large for this demo. Please make a shorter recording.')); return; }
        const dataUrl = await blobToDataUrl(blob);
        if (addMessage(selectedId, role(), { audioDataUrl:dataUrl, audioMime:blob.type })) render(role(), selectedId);
      });
      activeRecorder.start(500);
      recordingStartedAt = Date.now();
      setRecordStatus(t('جارٍ التسجيل… اضغط للإيقاف','Recording… tap to stop'), true);
      recordingTimer = setInterval(() => {
        const secs = Math.floor((Date.now() - recordingStartedAt) / 1000);
        const status = $('#chat-record-status');
        if (status) status.textContent = `${t('جارٍ التسجيل','Recording')} · ${String(Math.floor(secs / 60)).padStart(2,'0')}:${String(secs % 60).padStart(2,'0')}`;
        if (secs >= 60 && activeRecorder?.state === 'recording') activeRecorder.stop();
      }, 500);
    } catch (error) {
      setRecordStatus('');
      notify(t('لم نتمكن من فتح الميكروفون. راجع صلاحيات المتصفح.','Could not access the microphone. Check your browser permissions.'));
    }
  }

  function blobToDataUrl(blob) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result));
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  }

  async function handleFile(file, tabRole, conversationId) {
    if (!file || !conversationId) return;
    if (file.size > 1.5 * 1024 * 1024) { notify(t('حجم الملف أكبر من 1.5 ميجابايت في النسخة التجريبية.','File size exceeds 1.5 MB in this demo.')); return; }
    try {
      const dataUrl = await blobToDataUrl(file);
      const kind = file.type.startsWith('image/') ? 'image' : 'file';
      const message = { file:{ name:file.name, type:file.type, kind, sizeLabel:`${Math.max(1, Math.round(file.size / 1024))} KB`, dataUrl } };
      if (addMessage(conversationId, tabRole, message)) render(tabRole, conversationId);
    } catch { notify(t('تعذر قراءة الملف المرفق.','Could not read the attached file.')); }
  }

  function openChats() { render(role()); }
  function init() {
    const side = $('#sidebar');
    side?.addEventListener('click', e => {
      const link = e.target.closest('.sidebar-nav [data-wf-tab="chats"]');
      if (!link) return;
      e.preventDefault(); e.stopPropagation();
      history.replaceState(null, '', '#chats');
      openChats();
    });
    if (location.hash === '#chats') openChats();
    window.addEventListener('shifaa:languagechange', () => {
      if (location.hash === '#chats') render(role(), read('shifaa_open_chat_id', null));
    });
    window.addEventListener('storage', e => {
      if (['shifaa_conversations','shifaa_demo_bookings'].includes(e.key) && location.hash === '#chats') render(role(), read('shifaa_open_chat_id', null));
    });
    window.addEventListener('beforeunload', () => {
      clearInterval(recordingTimer);
      activeStream?.getTracks().forEach(track => track.stop());
    });
  }

  window.ShifaaChat = {
    openConversation(id) {
      write('shifaa_open_chat_id', id);
      if (document.body.dataset.role !== 'doctor') {
        if (!location.pathname.toLowerCase().endsWith('patient-dashboard.html')) { location.href = 'patient-dashboard.html#chats'; return; }
      }
      history.replaceState(null, '', '#chats');
      render(role(), id);
    },
    refresh() { render(role(), read('shifaa_open_chat_id', null)); }
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, { once:true }); else init();
})();
