document.addEventListener('DOMContentLoaded', () => {
  const form = document.querySelector('.booking-layout');
  if (!form) return;
  const profiles = {
    '1': { name:'د. محمد حسن', specialty:'استشاري القلب والأوعية', photo:'images/doctor-mohamed-hassan.jpg', location:'عيادة النخيل · الدقي، الجيزة', fee:'٤٥٠ ج.م' },
    '2': { name:'د. منى إبراهيم', specialty:'استشارية القلب والباطنة', photo:'images/doctor-mona-ibrahim.jpg', location:'مدينة نصر، القاهرة · مكرم عبيد', fee:'٥٠٠ ج.م' },
    '3': { name:'د. عمر عادل', specialty:'أخصائي القلب والأوعية الدموية', photo:'images/doctor-omar-adel.jpg', location:'المهندسين، الجيزة · جامعة الدول', fee:'٣٥٠ ج.م' }
  };
  const selectedDoctorId = new URLSearchParams(location.search).get('doctor') || '1';
  const doctor = profiles[selectedDoctorId] || profiles['1'];
  const doctorIdField = form.querySelector('[name="DoctorId"]');
  if (doctorIdField) doctorIdField.value = selectedDoctorId;
  const doctorName = document.querySelector('.summary-doctor-name');
  const doctorSpecialty = document.querySelector('.summary-doctor-specialty');
  const doctorPhoto = document.querySelector('.summary-doctor-photo');
  const locationValue = document.querySelector('.summary-list div:first-child dd');
  const feeValue = document.querySelector('.summary-total strong');
  if (doctorName) doctorName.textContent = doctor.name;
  if (doctorSpecialty) doctorSpecialty.textContent = doctor.specialty;
  if (doctorPhoto) { doctorPhoto.src = doctor.photo; doctorPhoto.alt = doctor.name; }
  if (locationValue) locationValue.textContent = doctor.location;
  if (feeValue) feeValue.textContent = doctor.fee;

  function bind(name, id) {
    const target = document.getElementById(id);
    form.querySelectorAll(`[name="${name}"]`).forEach(input => input.addEventListener('change', () => {
      if (target) target.textContent = input.dataset.summary || input.value;
    }));
  }
  bind('AppointmentDate', 'SummaryDate');
  bind('AppointmentTime', 'SummaryTime');

  form.addEventListener('submit', event => {
    event.preventDefault();
    if (!form.reportValidity()) return;
    const data = Object.fromEntries(new FormData(form).entries());
    const currentUser = (() => {
      try { return JSON.parse(localStorage.getItem('shifaa_currentUser') || localStorage.getItem('currentUser') || '{}'); }
      catch { return {}; }
    })();
    const bookings = (() => { try { return JSON.parse(localStorage.getItem('shifaa_demo_bookings') || '[]'); } catch { return []; } })();
    const ownerId = String(currentUser.id || currentUser.email || currentUser.Email || currentUser.phone || currentUser.PhoneNumber || 'demo-patient');
    const patientName = data.PatientName || currentUser.name || currentUser.FullName || 'المريض';
    const item = {
      ...data,
      DoctorId: String(data.DoctorId || selectedDoctorId),
      DoctorName: doctor.name,
      DoctorSpecialty: doctor.specialty,
      PatientName: patientName,
      patientId: ownerId,
      id: `SH-${Date.now()}`,
      createdAt: new Date().toISOString(),
      status: 'طلب محفوظ تجريبيًا'
    };
    bookings.push(item);
    localStorage.setItem('shifaa_demo_bookings', JSON.stringify(bookings));

    let box = document.getElementById('booking-confirmation');
    if (!box) { box = document.createElement('div'); box.id = 'booking-confirmation'; box.className = 'card booking-confirmation'; form.appendChild(box); }
    const strong = document.createElement('strong'); strong.textContent = 'تم حفظ طلب الحجز على هذا الجهاز.';
    const p = document.createElement('p'); p.textContent = `رقم الطلب ${item.id} — ${item.AppointmentDate} — ${item.AppointmentTime}`;
    const small = document.createElement('small'); small.textContent = 'يمكنك بدء محادثة مع الطبيب من زر الشات بجوار اسمه. الحجز في هذه النسخة تجريبي ومحلي وليس حجزًا مؤكدًا على خادم.';
    const link = document.createElement('a'); link.href = 'patient-dashboard.html#chats'; link.className = 'btn btn-primary'; link.textContent = 'الانتقال إلى محادثاتي'; link.style.marginTop = '10px';
    box.replaceChildren(strong, p, small, link);
    box.scrollIntoView({ behavior:'smooth', block:'center' });
  });
});
