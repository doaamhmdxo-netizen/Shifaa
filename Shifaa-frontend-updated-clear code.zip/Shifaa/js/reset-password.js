// ==========================================================
// reset-password.js: التأكد إن الكلمتين متطابقتين قبل الحفظ
// ==========================================================

document.addEventListener("DOMContentLoaded", function () {
  const form = document.querySelector(".auth-form");
  const newPassword = document.getElementById("NewPassword");
  const confirmPassword = document.getElementById("ConfirmPassword");

  if (!form || !newPassword || !confirmPassword) return;

  // لما المستخدم يكتب تاني بنشيل رسالة الخطأ.
  function clearMessage() { confirmPassword.setCustomValidity(""); }
  newPassword.addEventListener("input", clearMessage);
  confirmPassword.addEventListener("input", clearMessage);

  // الفحص بتاع required و minlength بيشتغل قبل الحدث ده
  form.addEventListener("submit", function (event) {
    event.preventDefault();

    if (newPassword.value !== confirmPassword.value) {
      confirmPassword.setCustomValidity(confirmPassword.dataset.mismatchMessage);
      confirmPassword.reportValidity(); // بتظهر الرسالة جنب الحقل
      return;
    }

    // مؤقت للمرحلة أ: بنروح للصفحة اللي بعدها. هنمسحه في المرحلة ب
    window.location.href = "password-updated.html";
  });
});