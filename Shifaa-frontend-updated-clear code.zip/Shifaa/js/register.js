// ==========================================================
// register.js: سلوك صفحة إنشاء الحساب
// ==========================================================

document.addEventListener("DOMContentLoaded", function () {
  const registerForm = document.querySelector(".auth-form");

});