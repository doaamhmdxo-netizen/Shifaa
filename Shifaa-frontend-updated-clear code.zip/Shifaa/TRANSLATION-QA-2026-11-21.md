# Shifaa bilingual translation QA — 21 Nov 2026

## Scope checked
All 16 HTML screens in this project were checked:

- index.html
- login.html, register.html
- forgot-password.html, reset-password.html, reset-link-sent.html, password-updated.html
- verify-email.html, two-factor.html, access-denied.html
- patient-dashboard.html, doctor-dashboard.html, admin-overview.html
- find-doctor.html, book-appointment.html, nearest-pharmacy.html

## Changes in this pass
- Added English translation for the public home page meta description (index.html).
- Added translations for doctor-image alternative text, account-type and filter-result accessible labels.
- Added English formatting for the initial consultation-fee range and reversible Arabic/English handling for dynamic EGP amounts.
- Kept the mobile navigation's accessible label synchronized with the selected language.

## Validation
- All 16 HTML pages contain the shared language toggle and load `js/auth-language.js`.
- All visible static Arabic text nodes, document titles, and checked text attributes have corresponding translation entries.
- All local script and stylesheet references resolve.
- All JavaScript files pass `node --check`.
- All CSS stylesheets parse without syntax errors.

## Notes
The interface language is saved in localStorage and applied on each page load. Dynamic text inserted by the existing application scripts is handled by the shared translation observer or by the relevant screen-specific language-aware rendering.
