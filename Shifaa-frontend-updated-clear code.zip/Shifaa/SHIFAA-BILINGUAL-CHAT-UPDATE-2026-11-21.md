# Shifaa — Bilingual UI & Chat update (21 Nov 2026)

## Included in this update

- Added a shared Arabic/English language switch to all 16 HTML screens.
- Language preference is persisted across pages; page direction changes between RTL (Arabic) and LTR (English).
- Expanded translations for navigation, dashboards, doctor search, booking, patient and doctor workflows, admin views, pharmacy interactions, dynamic forms, messages, alerts, labels, placeholders, and dates.
- Synchronized the patient settings language selector with the global language preference.
- Stabilized the registration page's desktop layout so the header/footer do not jump as the wizard changes steps. The background image remains independent from the registration card. Smaller screens retain natural page scrolling.
- Added chat entry icons to the doctor cards. Chat access checks for a non-cancelled appointment record for that patient and doctor; without one, a booking-required prompt appears with a link to book.
- Expanded the patient/doctor chat UI with text messages, local voice recording and playback, file/image attachments, unread/read indicators, audio/video call controls, and a local microphone/camera preview.
- Added `docs/chat-realtime-signaling-contract.md` describing the backend and WebRTC signaling needed for real-time calls.

## Important demo limitations

This project is still a static front-end demo. Bookings, chat conversations, and recorded voice notes are stored in the current browser's `localStorage`; they are not authenticated server records and are not synchronized between different devices or accounts. The audio/video controls currently provide a local device preview only, not a remote call. A production implementation requires a secure backend, authenticated patient/doctor accounts, a database, server-side appointment authorization, protected media storage, real-time messaging, and WebRTC signaling with STUN/TURN infrastructure. The appointment gate in this demo therefore checks local demo booking data only.

## Validation performed

- JavaScript syntax: 21 files checked with `node --check`.
- CSS syntax: 15 stylesheets parsed; no syntax errors reported.
- HTML: 16 pages checked; no duplicate IDs or missing local script, stylesheet, and image references found.
- CSS `url()` references: no missing local assets found.
- A full visual browser run was not completed in the available headless environment, so final appearance should still be checked in a browser at desktop and mobile widths.
