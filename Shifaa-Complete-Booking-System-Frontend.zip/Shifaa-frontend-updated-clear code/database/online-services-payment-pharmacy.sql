/* Shifaa online services migration - SQL Server
   Additive migration: keeps the existing PATIENT, DOCTOR, APPOINTMENT, PHARMACY and ADMIN tables.
   The prescription remains associated with APPOINTMENT (existing PrescriptionDetails/PatientFile fields).
   No card number, CVV, PIN, wallet password, or other payment credentials are stored here.
*/

CREATE TABLE PAYMENT
(
    PaymentID INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    AppointmentID INT NULL,
    PharmacyOrderID INT NULL,
    Provider NVARCHAR(30) NOT NULL CONSTRAINT DF_PAYMENT_Provider DEFAULT N'Paymob',
    ProviderTransactionID NVARCHAR(150) NULL,
    PaymentMethod NVARCHAR(40) NOT NULL,
    Amount DECIMAL(10,2) NOT NULL,
    Currency CHAR(3) NOT NULL CONSTRAINT DF_PAYMENT_Currency DEFAULT 'EGP',
    PaymentStatus NVARCHAR(30) NOT NULL,
    CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_PAYMENT_CreatedAt DEFAULT SYSUTCDATETIME(),
    PaidAt DATETIME2(0) NULL,
    RefundStatus NVARCHAR(30) NULL,
    ProviderResponseReference NVARCHAR(200) NULL,
    CONSTRAINT FK_PAYMENT_APPOINTMENT FOREIGN KEY (AppointmentID) REFERENCES APPOINTMENT(AppointmentID),
    CONSTRAINT CK_PAYMENT_OneTarget CHECK
    (
        (CASE WHEN AppointmentID IS NOT NULL THEN 1 ELSE 0 END) +
        (CASE WHEN PharmacyOrderID IS NOT NULL THEN 1 ELSE 0 END) = 1
    ),
    CONSTRAINT CK_PAYMENT_Amount CHECK (Amount >= 0),
    CONSTRAINT CK_PAYMENT_Status CHECK (PaymentStatus IN (N'Pending',N'Paid',N'Failed',N'Cancelled',N'RefundPending',N'Refunded')),
    CONSTRAINT CK_PAYMENT_Method CHECK (PaymentMethod IN (N'Card',N'MobileWallet',N'Other'))
);
GO

CREATE TABLE PHARMACY_ORDER
(
    PharmacyOrderID INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    AppointmentID INT NOT NULL,
    PharmacyID INT NOT NULL,
    PrescriptionFileReference NVARCHAR(500) NULL,
    DeliveryAddress NVARCHAR(300) NOT NULL,
    DeliveryPhone NVARCHAR(20) NOT NULL,
    PatientNotes NVARCHAR(MAX) NULL,
    PharmacyConfirmedTotal DECIMAL(10,2) NULL,
    OrderStatus NVARCHAR(35) NOT NULL CONSTRAINT DF_PHARMACY_ORDER_Status DEFAULT N'Submitted',
    CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_PHARMACY_ORDER_CreatedAt DEFAULT SYSUTCDATETIME(),
    UpdatedAt DATETIME2(0) NULL,
    CONSTRAINT FK_PHARMACY_ORDER_APPOINTMENT FOREIGN KEY (AppointmentID) REFERENCES APPOINTMENT(AppointmentID),
    CONSTRAINT FK_PHARMACY_ORDER_PHARMACY FOREIGN KEY (PharmacyID) REFERENCES PHARMACY(PharmacyID),
    CONSTRAINT CK_PHARMACY_ORDER_Total CHECK (PharmacyConfirmedTotal IS NULL OR PharmacyConfirmedTotal >= 0),
    CONSTRAINT CK_PHARMACY_ORDER_Status CHECK (OrderStatus IN (N'Submitted',N'UnderReview',N'AvailabilityConfirmed',N'AwaitingPayment',N'Paid',N'Preparing',N'OutForDelivery',N'Delivered',N'Rejected',N'Cancelled'))
);
GO

/* Add the PharmacyOrder foreign key after both tables exist. */
ALTER TABLE PAYMENT
ADD CONSTRAINT FK_PAYMENT_PHARMACY_ORDER
FOREIGN KEY (PharmacyOrderID) REFERENCES PHARMACY_ORDER(PharmacyOrderID);
GO

CREATE INDEX IX_PAYMENT_AppointmentID ON PAYMENT(AppointmentID) WHERE AppointmentID IS NOT NULL;
CREATE INDEX IX_PAYMENT_PharmacyOrderID ON PAYMENT(PharmacyOrderID) WHERE PharmacyOrderID IS NOT NULL;
CREATE INDEX IX_PAYMENT_ProviderTransactionID ON PAYMENT(ProviderTransactionID) WHERE ProviderTransactionID IS NOT NULL;
CREATE INDEX IX_PHARMACY_ORDER_Status_CreatedAt ON PHARMACY_ORDER(OrderStatus, CreatedAt DESC);
GO

/* Integration notes:
   1) Create the payment intent/order on the backend; never expose Paymob secret keys in JavaScript.
   2) Verify the Paymob callback/webhook server-side before changing PAYMENT.PaymentStatus to Paid.
   3) Confirm online appointments only after a verified successful payment.
   4) Pharmacy confirms availability and total first; then create a payment for the PHARMACY_ORDER.
   5) Store prescription files in private, access-controlled server storage; save only a protected file reference here.
   6) For a production schema, add the exact prescription entity/table if the final approved ERD models it separately.
*/
