# Shifaa – changes required in the academic diagrams

The uploaded archive contains frontend files and SQL scripts, but no editable ERD, RS, Use Case, or Activity Diagram source files. Therefore this note records the exact changes to apply to the original diagram files; it does not fabricate replacement diagrams.

## ERD / Chen
- Add **PAYMENT**. It records Provider (Paymob), ProviderTransactionID, PaymentMethod, Amount, Currency, PaymentStatus, CreatedAt, PaidAt, and RefundStatus.
- A payment belongs to exactly one target: **APPOINTMENT** or **PHARMACY_ORDER**. In the SQL implementation this is represented by two nullable foreign keys with a CHECK constraint requiring exactly one target.
- Add **PHARMACY_ORDER** related to **APPOINTMENT** and **PHARMACY**. It stores the prescription file reference, delivery address/phone, patient notes, pharmacy-confirmed total, order status, and timestamps.
- Keep the user's earlier decision: the prescription remains associated with APPOINTMENT. The new pharmacy order is created from that appointment's prescription; do not create an unrelated prescription workflow.
- Do not add PHARMACY_ORDER_ITEM yet: the current SQL stores prescription details as appointment text/file references, not structured medicine rows. Add item rows only if the final frontend/database models medicine line items explicitly.
- Do not create direct many-to-many relationships between ADMIN and all business entities. Admin oversight is represented by role permissions and action logging at the backend layer.

## Relational Schema (RS)
- PAYMENT(AppointmentID FK nullable, PharmacyOrderID FK nullable, Provider, ProviderTransactionID, PaymentMethod, Amount, Currency, PaymentStatus, CreatedAt, PaidAt, RefundStatus, ProviderResponseReference). Exactly one of the two FKs must be populated.
- PHARMACY_ORDER(AppointmentID FK, PharmacyID FK, PrescriptionFileReference, DeliveryAddress, DeliveryPhone, PatientNotes, PharmacyConfirmedTotal, OrderStatus, CreatedAt, UpdatedAt).

## Use Case additions
- Patient: Pay for online consultation; view payment result; send prescription to pharmacy; review pharmacy quote; pay pharmacy order; track delivery.
- Pharmacy: Review prescription; confirm medicine availability and total; update preparation/delivery status.
- Admin: View payment transactions; monitor failed/pending payments; review refund requests; monitor pharmacy orders; manage pharmacy account status.
- Admin must not manually mark a payment as paid. Payment confirmation is provided by verified Paymob server notification.

## Activity additions
- Online booking: choose doctor/time → create pending appointment → initiate Paymob payment on backend → verify callback/webhook → confirm appointment only on verified success; otherwise keep pending/failed and allow retry.
- Pharmacy order: patient sends appointment prescription → pharmacy reviews → pharmacy confirms availability and total → patient accepts and pays via Paymob → verified payment → pharmacy prepares → out for delivery → delivered. Include rejected/unavailable and payment-failed branches.

## Important implementation boundary
The HTML/JavaScript in this archive is a local demo only. Live Paymob transactions, secure prescription uploads, cross-device pharmacy order sharing, and delivery updates require a backend, authenticated APIs, secure file storage, and verified provider webhooks.
