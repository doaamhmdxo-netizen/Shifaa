/* Shifaa front-end workflows. Demo data is browser-local only; production needs secure APIs/database. */
(() => {
  'use strict';
  const $ = (s, r=document) => r.querySelector(s);
  const $$ = (s, r=document) => [...r.querySelectorAll(s)];
  const KEY = 'shifaa_';
  const read = (key, fallback=[]) => { try { return JSON.parse(localStorage.getItem(KEY+key)) ?? fallback; } catch { return fallback; } };
  const save = (key, value) => localStorage.setItem(KEY+key, JSON.stringify(value));
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const demoAppointments = [
    {id:'A-101',name:'يوسف عادل',time:'05:30 م',type:'متابعة',status:'بانتظار التأكيد',phone:'01012345678'},
    {id:'A-102',name:'نورهان علي',time:'06:00 م',type:'كشف جديد',status:'تم التأكيد',phone:'01023456789'},
    {id:'A-103',name:'كريم سامح',time:'06:30 م',type:'متابعة',status:'تم التأكيد',phone:'01034567890'},
    {id:'A-104',name:'مريم خالد',time:'07:00 م',type:'كشف جديد',status:'بانتظار التأكيد',phone:'01045678901'}
  ];
  const demoDoctors = [
    {name:'د. منى إبراهيم',specialty:'قلب وباطنة',city:'القاهرة',status:'نشط'},
    {name:'د. عمر عادل',specialty:'قلب وأوعية',city:'الجيزة',status:'نشط'},
    {name:'د. سارة أمين',specialty:'طب الأطفال',city:'القاهرة',status:'نشط'}
  ];
  const demoPatients = [
    {name:'أحمد محمود',type:'مريض',city:'الجيزة',status:'نشط'},
    {name:'نورهان علي',type:'مريضة',city:'القاهرة',status:'نشط'},
    {name:'يوسف عادل',type:'مريض',city:'القاهرة',status:'نشط'}
  ];
  // Shared demo records: all roles read the same browser-local records.
  const readBookings = () => { try { return JSON.parse(localStorage.getItem('shifaa_demo_bookings') || '[]'); } catch { return []; } };
  const bookingPatientId = b => String(b.patientId || b.PatientId || b.patientEmail || '').toLowerCase();
  const bookingDoctorId = b => String(b.DoctorId || b.doctorId || '');
  const userKey = user => String(user?.id||user?.email||user?.phone||'').toLowerCase();
  function medicalRecordFor(user) { const key=userKey(user);const records=read('patientMedicalRecords',{});return (key&&records[key])||read('patientMedicalRecord',{}); }
  function currentDoctorIdentity() {
    const user=currentUser(), settings=read('doctorSettings',{});
    const name=String(settings.name||user.name||$('.topbar-user-name')?.textContent||'').trim();
    const explicitId=String(user.doctorId||settings.doctorId||user.id||'').trim();
    const known=[['1','د. محمد حسن'],['2','د. منى إبراهيم'],['3','د. عمر عادل']];
    const matched=known.find(([,n])=>n.replace(/[أإآ]/g,'ا').replace(/\s+/g,'').toLowerCase()===name.replace(/[أإآ]/g,'ا').replace(/\s+/g,'').toLowerCase());
    return {id:explicitId && ['1','2','3'].includes(explicitId)?explicitId:(matched?.[0]||''),name};
  }
  function linkedDoctorAppointments() {
    const manual=read('doctorAppointments',[]), bookings=readBookings();
    const doctor=currentDoctorIdentity();
    const scopedBookings=currentRole()==='doctor'?bookings.filter(b=>{
      const id=bookingDoctorId(b), name=String(b.DoctorName||b.doctorName||'').trim();
      return (doctor.id && id===doctor.id) || (doctor.name && name && name.toLowerCase()===doctor.name.toLowerCase());
    }):bookings;
    const linked=scopedBookings.map(b=>{
      const paymentStatus=b.paymentStatus||'لم يتم الدفع';
      const status=b.doctorStatus==='مرفوض'?'مرفوض':b.doctorStatus==='ملغى'?'ملغى':paymentStatus==='Paid'?'تم التأكيد':b.doctorStatus==='تمت الموافقة'?'بانتظار الدفع':'بانتظار موافقة الطبيب';
      return {id:b.id,name:b.PatientName||b.patientName||'المريض',patientId:bookingPatientId(b),doctorId:bookingDoctorId(b),doctorName:b.DoctorName||'',time:[b.AppointmentDate,b.AppointmentTime].filter(Boolean).join(' · '),type:'استشارة أونلاين',status,paymentStatus,phone:b.PatientPhone||b.PhoneNumber||'',notes:b.Notes||'',source:'patient-booking',createdAt:b.createdAt};
    });
    const all=[...linked,...manual.filter(m=>!linked.some(x=>x.id===m.id))];
    return currentRole()==='doctor'?all.filter(a=>a.source==='patient-booking' || a.doctorId===doctor.id):all;
  }
  const currentLanguage = () => (localStorage.getItem('shifaa-language') || localStorage.getItem('shifaa-auth-language') || 'ar');
  const dateLocale = () => currentLanguage() === 'en' ? 'en-US' : 'ar-EG';
  const currentRole = () => document.body.dataset.role || (/(login|register|forgot-password|reset-password|reset-link-sent|password-updated|verify-email|two-factor|access-denied)\.html$/i.test(location.pathname) ? 'visitor' : 'patient');
  function currentUser() {
    const stored = read('currentUser', null);
    if (stored && (stored.name || stored.email)) return stored;
    const name = $('.topbar-user-name')?.textContent?.trim() || (currentRole()==='doctor'?'د. محمد حسن':currentRole()==='admin'?'مسؤول شفاء':'مستخدم شفاء');
    const roleLabel = currentRole()==='doctor'?'طبيب':currentRole()==='admin'?'إدارة':currentRole()==='visitor'?'زائر':'مريض';
    return {name, role:currentRole(), roleLabel};
  }
  function toast(message) {
    let node = $('#wf-toast');
    if (!node) { node=document.createElement('div'); node.id='wf-toast'; node.className='wf-toast'; node.setAttribute('role','status'); node.setAttribute('aria-live','polite'); document.body.append(node); }
    node.textContent=message; node.hidden=false; clearTimeout(toast.timer); toast.timer=setTimeout(()=>node.hidden=true,3400);
  }
  function dialog(title, content, onReady) {
    const backdrop=document.createElement('div'); backdrop.className='wf-dialog-backdrop';
    backdrop.innerHTML=`<section class="wf-dialog" role="dialog" aria-modal="true" aria-label="${esc(title)}"><header class="wf-dialog-head"><h2>${esc(title)}</h2><button class="wf-dialog-close" type="button" aria-label="إغلاق">×</button></header>${content}</section>`;
    document.body.append(backdrop);
    const close=()=>backdrop.remove();
    $('.wf-dialog-close',backdrop).addEventListener('click',close);
    backdrop.addEventListener('click',e=>{if(e.target===backdrop)close()});
    backdrop.addEventListener('keydown',e=>{if(e.key==='Escape')close()});
    onReady?.(backdrop,close); $('.wf-dialog',backdrop).focus?.(); return backdrop;
  }
  function supportDialog(sourceOverride) {
    const user=currentUser();
    const source=sourceOverride || (currentRole()==='doctor'?'صفحة الطبيب':currentRole()==='admin'?'لوحة الأدمن':'صفحة المريض');
    dialog('محتاج مساعدة؟', `<p class="wf-muted">اكتب رسالتك لفريق شفاء. يمكنك إرسال شكوى أو استفسار أو الإبلاغ عن مشكلة، وسيتم إظهارها في صندوق رسائل الدعم لدى الإدارة.</p>
      <form id="wf-support-form">
        <div class="wf-field"><label for="wf-support-kind">نوع الرسالة</label><select id="wf-support-kind" name="kind"><option>استفسار</option><option>شكوى</option><option>مشكلة تقنية</option><option>طلب مساعدة</option><option>اقتراح</option><option>أخرى</option></select></div>
        <div class="wf-field"><label for="wf-support-subject">عنوان الرسالة</label><input id="wf-support-subject" name="subject" required maxlength="120" placeholder="اكتب عنوانًا واضحًا للرسالة"></div>
        <div class="wf-field"><label for="wf-support-message">تفاصيل الرسالة</label><textarea id="wf-support-message" name="message" required minlength="5" maxlength="3000" placeholder="اكتب كل التفاصيل التي تريد أن يعرفها فريق شفاء..."></textarea></div>
        <div class="wf-muted">سيتم إرفاق اسمك ونوع حسابك ومصدر الرسالة ووقت الإرسال تلقائيًا.</div>
        <div class="wf-dialog-foot"><button class="wf-btn" type="submit">إرسال إلى فريق شفاء</button><button class="wf-btn soft" type="button" data-close>إلغاء</button></div>
      </form>`, (root,close)=>{
      $('[data-close]',root).onclick=close;
      $('#wf-support-form',root).onsubmit=e=>{
        e.preventDefault(); const fd=new FormData(e.currentTarget);
        const messages=read('supportMessages',[]);
        const createdAt=new Date().toISOString();
        messages.unshift({id:'SUP-'+Date.now(),senderId:user.id||user.email||null,from:user.name||'مستخدم شفاء',senderName:user.name||'مستخدم شفاء',email:user.email||'',role:currentRole(),roleLabel:currentRole()==='doctor'?'طبيب':currentRole()==='admin'?'إدارة':currentRole()==='visitor'?'زائر':'مريض',source,kind:fd.get('kind'),category:fd.get('kind'),subject:fd.get('subject').trim(),message:fd.get('message').trim(),date:createdAt,createdAt,status:'جديدة',reply:'',repliedAt:''});
        save('supportMessages',messages); close(); toast('تم إرسال رسالتك إلى صندوق دعم شفاء.');
      };
    });
  }
  const panel = (title, subtitle, content, actions='') => `<div class="page-header"><div><h1 class="page-title">${title}</h1><p class="page-subtitle">${subtitle}</p></div>${actions}</div><div class="wf-screen">${content}</div>`;
  const stat = (icon,value,label) => `<article class="wf-panel wf-col-4"><div class="wf-stat"><span class="wf-stat-icon"><i data-lucide="${icon}"></i></span><div><strong>${value}</strong><span>${label}</span></div></div></article>`;
  const badge = status => `<span class="wf-badge ${status==='تم التأكيد'||status==='نشط'||status==='تم الرد'||status==='رفع الإيقاف'?'done':status==='ملغى'||status==='مرفوض'||status==='محظور'||status==='حظر'?'cancelled':status==='مغلقة'?'closed':status==='جديدة'?'new':status==='تحذير'||status==='إيقاف مؤقت'||status==='موقوف مؤقتًا'?'warning':'pending'}">${esc(status)}</span>`;
  function refreshIcons(){ if(window.lucide) window.lucide.createIcons(); }
  function setActive(tab){ $$('.sidebar-nav .nav-item,.sidebar-bottom .nav-item').forEach(a=>{const active=a.dataset.wfTab===tab;a.classList.toggle('active',active);if(active)a.setAttribute('aria-current','page');else a.removeAttribute('aria-current')}); }
  function renderPatient(tab) {
    const main=$('.page-content'); if(!main)return;
    setActive(tab);
    if(tab==='medical') {
      const legacy=read('patientMedical',{blood:'غير محددة',allergies:'',conditions:'',emergency:'',height:'',weight:''});
      const profile=medicalRecordFor(currentUser()).schemaVersion?medicalRecordFor(currentUser()):{
        schemaVersion:2, patientId:currentUser().id||currentUser().email||null,
        bloodType:legacy.blood||'غير محددة', heightCm:legacy.height||'', weightKg:legacy.weight||'',
        vitals:{bloodPressureSystolic:null,bloodPressureDiastolic:null,heartRateBpm:null,bodyTemperatureC:null,oxygenSaturationPercent:null,bloodGlucoseMgDl:null,measurementDate:''},
        allergies:legacy.allergies&&!['لم يتم تسجيلها','لا يوجد'].includes(legacy.allergies)?[legacy.allergies]:[], chronicConditions:legacy.conditions&&!['لا توجد بيانات مضافة','لا توجد بيانات'].includes(legacy.conditions)?[legacy.conditions]:[],
        surgeries:[], medications:[], emergencyContact:{name:'',relationship:'',phone:legacy.emergency&&!['لم يحدد','غير محدد'].includes(legacy.emergency)?legacy.emergency:''}, notes:'',
        createdAt:null, updatedAt:null
      };
      const vitals=profile.vitals||{};
      const lines=v=>Array.isArray(v)?v.join('\n'):(v||'');
      const number=v=>(v!==null&&v!==undefined&&v!==''&&Number.isFinite(Number(v)))?Number(v):null;
      const height=number(profile.heightCm),weight=number(profile.weightKg);
      const bmi=height>0&&weight>0?(weight/((height/100)**2)).toFixed(1):'غير مسجل';
      const bloodPressure=number(vitals.bloodPressureSystolic)!==null&&number(vitals.bloodPressureDiastolic)!==null?`${vitals.bloodPressureSystolic}/${vitals.bloodPressureDiastolic}`:'غير مسجل';
      const display=(value,unit='')=>value!==null&&value!==undefined&&value!==''?`${esc(value)}${unit}`:'غير مسجل';
      const metric=(icon,label,value,unit='')=>`<article class="wf-medical-metric-card"><span class="wf-medical-metric-icon"><i data-lucide="${icon}"></i></span><div><span class="wf-medical-metric-label">${label}</span><strong class="wf-medical-metric-value">${display(value,unit)}</strong></div></article>`;
      main.innerHTML=panel('ملفي الطبي','ملف صحي أشمل يجمع مؤشراتك الحيوية وبياناتك الصحية وتاريخك الطبي ومعلومات الطوارئ.',`
        <section class="wf-hero wf-medical-hero"><div><div class="wf-eyebrow">السجل الصحي الشخصي</div><h2>صورة أوضح عن صحتك في مكان واحد</h2><p>سجّل قياساتك الصحية الأساسية وتاريخك الطبي، وحدّثها عند إجراء قياسات جديدة حتى تكون المعلومات المهمة متاحة عند مراجعة الطبيب.</p></div><span class="wf-badge">ملف صحي قابل للتحديث</span></section>
        <section class="wf-medical-overview" aria-label="ملخص المؤشرات الصحية">
          ${metric('droplet','فصيلة الدم',profile.bloodType&&profile.bloodType!=='غير محددة'?profile.bloodType:null)}
          ${metric('calculator','مؤشر كتلة الجسم',bmi==='غير مسجل'?null:bmi,'')}
          ${metric('activity','ضغط الدم',bloodPressure==='غير مسجل'?null:bloodPressure,' mmHg')}
          ${metric('heart-pulse','معدل النبض',vitals.heartRateBpm,' نبضة/دقيقة')}
          ${metric('thermometer','درجة الحرارة',vitals.bodyTemperatureC,' °C')}
          ${metric('wind','الأكسجين بالدم',vitals.oxygenSaturationPercent,'%')}
          ${metric('droplet','مستوى السكر',vitals.bloodGlucoseMgDl,' mg/dL')}
        </section>
        <form id="wf-medical-record" class="wf-medical-form">
          <section class="wf-panel wf-medical-section"><div class="wf-panel-head"><div><span class="wf-section-kicker">01 · بيانات الجسم</span><h3>البيانات الأساسية ومؤشر كتلة الجسم</h3></div><i data-lucide="user-round"></i></div>
            <div class="wf-screen-grid">
              <div class="wf-field wf-col-4"><label for="wf-blood">فصيلة الدم</label><select id="wf-blood" name="bloodType">${['غير محددة','A+','A-','B+','B-','AB+','AB-','O+','O-'].map(x=>`<option ${profile.bloodType===x?'selected':''}>${x}</option>`).join('')}</select></div>
              <div class="wf-field wf-col-4"><label for="wf-height">الطول (سم)</label><input id="wf-height" name="heightCm" type="number" min="30" max="250" step="0.1" value="${esc(profile.heightCm)}" placeholder="مثال: 170"></div>
              <div class="wf-field wf-col-4"><label for="wf-weight">الوزن (كجم)</label><input id="wf-weight" name="weightKg" type="number" min="1" max="500" step="0.1" value="${esc(profile.weightKg)}" placeholder="مثال: 70"></div>
              <div class="wf-field wf-col-4"><label for="wf-bmi-display">مؤشر كتلة الجسم (BMI)</label><output class="wf-medical-readout" id="wf-bmi-display" aria-live="polite">${bmi}</output><small class="wf-muted">يُحسب تلقائيًا من الطول والوزن.</small></div>
            </div>
          </section>
          <section class="wf-panel wf-medical-section"><div class="wf-panel-head"><div><span class="wf-section-kicker">02 · المؤشرات الحيوية</span><h3>القياسات الصحية والمتابعة</h3></div><i data-lucide="heart-pulse"></i></div>
            <div class="wf-screen-grid">
              <div class="wf-field wf-col-4"><label for="wf-bp-systolic">ضغط الدم الانقباضي (mmHg)</label><input id="wf-bp-systolic" name="bloodPressureSystolic" type="number" min="30" max="300" step="1" value="${esc(vitals.bloodPressureSystolic??'')}" placeholder="مثال: 120"></div>
              <div class="wf-field wf-col-4"><label for="wf-bp-diastolic">ضغط الدم الانبساطي (mmHg)</label><input id="wf-bp-diastolic" name="bloodPressureDiastolic" type="number" min="20" max="200" step="1" value="${esc(vitals.bloodPressureDiastolic??'')}" placeholder="مثال: 80"></div>
              <div class="wf-field wf-col-4"><label for="wf-heart-rate">معدل نبض القلب (نبضة/دقيقة)</label><input id="wf-heart-rate" name="heartRateBpm" type="number" min="1" max="300" step="1" value="${esc(vitals.heartRateBpm??'')}" placeholder="مثال: 75"></div>
              <div class="wf-field wf-col-4"><label for="wf-temperature">درجة حرارة الجسم (°C)</label><input id="wf-temperature" name="bodyTemperatureC" type="number" min="25" max="50" step="0.1" value="${esc(vitals.bodyTemperatureC??'')}" placeholder="مثال: 37"></div>
              <div class="wf-field wf-col-4"><label for="wf-oxygen">نسبة تشبع الأكسجين (SpO₂ %)</label><input id="wf-oxygen" name="oxygenSaturationPercent" type="number" min="1" max="100" step="0.1" value="${esc(vitals.oxygenSaturationPercent??'')}" placeholder="مثال: 98"></div>
              <div class="wf-field wf-col-4"><label for="wf-glucose">مستوى السكر (mg/dL)</label><input id="wf-glucose" name="bloodGlucoseMgDl" type="number" min="1" max="2000" step="0.1" value="${esc(vitals.bloodGlucoseMgDl??'')}" placeholder="مثال: 95"></div>
              <div class="wf-field wf-col-4"><label for="wf-measurement-date">تاريخ القياس</label><input id="wf-measurement-date" name="measurementDate" type="date" value="${esc(vitals.measurementDate||'')}"></div>
            </div>
            <p class="wf-medical-form-note">أدخل القياسات الفعلية كما ظهرت في جهاز القياس أو التقرير الطبي، واترك أي حقل غير متاح فارغًا. هذه البيانات للتوثيق والمتابعة ولا تمثل تشخيصًا طبيًا.</p>
          </section>
          <div class="wf-screen-grid">
            <section class="wf-panel wf-col-6 wf-medical-section"><div class="wf-panel-head"><div><span class="wf-section-kicker">03 · الحساسية</span><h3>الحساسية الدوائية والغذائية</h3></div><i data-lucide="shield-check"></i></div><div class="wf-field"><label for="wf-allergies">الحساسية المعروفة</label><textarea id="wf-allergies" name="allergies" placeholder="اكتب كل نوع حساسية في سطر منفصل، مع توضيح رد الفعل إن وجد، أو اكتب: لا يوجد">${esc(lines(profile.allergies))}</textarea><small class="wf-muted">يفضل كتابة اسم المادة ورد الفعل المعروف ودرجة الحساسية إن وجدت.</small></div></section>
            <section class="wf-panel wf-col-6 wf-medical-section"><div class="wf-panel-head"><div><span class="wf-section-kicker">04 · التاريخ المرضي</span><h3>الأمراض والحالات المزمنة</h3></div><i data-lucide="heart-pulse"></i></div><div class="wf-field"><label for="wf-conditions">الحالات المرضية</label><textarea id="wf-conditions" name="chronicConditions" placeholder="اكتب كل حالة مرضية في سطر منفصل، مع تاريخ التشخيص أو الملاحظات إن أمكن">${esc(lines(profile.chronicConditions))}</textarea></div></section>
            <section class="wf-panel wf-col-6 wf-medical-section"><div class="wf-panel-head"><div><span class="wf-section-kicker">05 · العمليات والإجراءات</span><h3>العمليات السابقة</h3></div><i data-lucide="clipboard-list"></i></div><div class="wf-field"><label for="wf-surgeries">العمليات أو الإجراءات الطبية السابقة</label><textarea id="wf-surgeries" name="surgeries" placeholder="اسم العملية — التاريخ — أي ملاحظات مهمة">${esc(lines(profile.surgeries))}</textarea></div></section>
            <section class="wf-panel wf-col-6 wf-medical-section"><div class="wf-panel-head"><div><span class="wf-section-kicker">06 · الأدوية</span><h3>الأدوية الحالية</h3></div><i data-lucide="pill"></i></div><div class="wf-field"><label for="wf-medications">الأدوية والجرعات</label><textarea id="wf-medications" name="medications" placeholder="اسم الدواء — الجرعة — عدد المرات — ملاحظات">${esc(lines(profile.medications))}</textarea></div></section>
            <section class="wf-panel wf-col-12 wf-medical-section"><div class="wf-panel-head"><div><span class="wf-section-kicker">07 · للطوارئ</span><h3>جهة اتصال للطوارئ</h3></div><i data-lucide="phone-call"></i></div><div class="wf-screen-grid">
              <div class="wf-field wf-col-4"><label for="wf-emergency-name">اسم الشخص</label><input id="wf-emergency-name" name="emergencyName" value="${esc(profile.emergencyContact?.name||'')}" placeholder="الاسم بالكامل"></div>
              <div class="wf-field wf-col-4"><label for="wf-emergency-relation">صلة القرابة</label><input id="wf-emergency-relation" name="emergencyRelationship" value="${esc(profile.emergencyContact?.relationship||'')}" placeholder="مثال: الأب / الزوجة"></div>
              <div class="wf-field wf-col-4"><label for="wf-emergency-phone">رقم الهاتف</label><input id="wf-emergency-phone" name="emergencyPhone" type="tel" inputmode="tel" value="${esc(profile.emergencyContact?.phone||'')}" placeholder="01xxxxxxxxx"></div>
            </div></section>
            <section class="wf-panel wf-col-12 wf-medical-section"><div class="wf-panel-head"><div><span class="wf-section-kicker">08 · ملاحظات إضافية</span><h3>معلومات تحب أن يعرفها الطبيب</h3></div><i data-lucide="notebook-pen"></i></div><div class="wf-field"><label for="wf-medical-notes">ملاحظات طبية</label><textarea id="wf-medical-notes" name="notes" placeholder="أي معلومات صحية إضافية أو ملاحظات مهمة...">${esc(profile.notes||'')}</textarea></div></section>
          </div>
          <div class="wf-medical-savebar"><div><strong>آخر تحديث</strong><small>${profile.updatedAt?esc(new Date(profile.updatedAt).toLocaleString(dateLocale())):'لم يتم حفظ الملف بعد'}</small></div><button class="wf-btn" type="submit"><i data-lucide="save"></i> حفظ الملف الطبي</button></div>
        </form>
        <section class="wf-db-note"><i data-lucide="database"></i><div><strong>خصوصية بياناتك الصحية</strong><p>هذه النسخة تحفظ البيانات محليًا في هذا المتصفح لأغراض التجربة فقط. لا تُدخل بيانات صحية حقيقية قبل تشغيل خادم آمن ومصادقة وصلاحيات وتخزين محمي.</p></div></section>`);
      const medicalForm=$('#wf-medical-record');
      if(medicalForm) {
        const heightField=$('#wf-height',medicalForm),weightField=$('#wf-weight',medicalForm),bmiOutput=$('#wf-bmi-display',medicalForm);
        const updateBmi=()=>{
          const h=Number(heightField?.value),w=Number(weightField?.value);
          bmiOutput.textContent=Number.isFinite(h)&&h>0&&Number.isFinite(w)&&w>0?(w/((h/100)**2)).toFixed(1):'أدخل الطول والوزن لحسابه';
        };
        heightField?.addEventListener('input',updateBmi);weightField?.addEventListener('input',updateBmi);
        medicalForm.addEventListener('submit',e=>{
          e.preventDefault();const fd=new FormData(e.currentTarget),now=new Date().toISOString();
          const list=name=>String(fd.get(name)||'').split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
          const numeric=name=>fd.get(name)===''||fd.get(name)===null?null:Number(fd.get(name));
          const previous=medicalRecordFor(currentUser());
          const next={schemaVersion:2,patientId:currentUser().id||currentUser().email||null,bloodType:fd.get('bloodType'),heightCm:fd.get('heightCm')||null,weightKg:fd.get('weightKg')||null,
            vitals:{bloodPressureSystolic:numeric('bloodPressureSystolic'),bloodPressureDiastolic:numeric('bloodPressureDiastolic'),heartRateBpm:numeric('heartRateBpm'),bodyTemperatureC:numeric('bodyTemperatureC'),oxygenSaturationPercent:numeric('oxygenSaturationPercent'),bloodGlucoseMgDl:numeric('bloodGlucoseMgDl'),measurementDate:fd.get('measurementDate')||null},
            allergies:list('allergies'),chronicConditions:list('chronicConditions'),surgeries:list('surgeries'),medications:list('medications'),emergencyContact:{name:String(fd.get('emergencyName')||'').trim(),relationship:String(fd.get('emergencyRelationship')||'').trim(),phone:String(fd.get('emergencyPhone')||'').trim()},notes:String(fd.get('notes')||'').trim(),createdAt:previous.createdAt||now,updatedAt:now};
          save('patientMedicalRecord',next);const medicalRecords=read('patientMedicalRecords',{});medicalRecords[String(next.patientId||'').toLowerCase()]=next;save('patientMedicalRecords',medicalRecords);save('patientMedical',{blood:next.bloodType,allergies:next.allergies.join('، ')||'لم يتم تسجيلها',conditions:next.chronicConditions.join('، ')||'لا توجد بيانات مضافة',emergency:next.emergencyContact.phone||'لم يحدد',height:next.heightCm,weight:next.weightKg});
          const activity=read('activityLog',[]);activity.unshift({id:'ACT-'+Date.now(),type:'medical-record-updated',patientId:String(next.patientId||'').toLowerCase(),patientName:currentUser().name,description:'تم تحديث الملف الطبي',createdAt:now});save('activityLog',activity);
          toast('تم حفظ الملف الطبي التجريبي بنجاح.');
          renderPatient('medical');
        });
      }
    } else if(tab==='prescriptions') {
      const user=currentUser(),uid=String(user.id||user.email||'').toLowerCase();
      const all=read('prescriptions',[]);
      const mine=all.filter(rx=>(rx.patientId&&String(rx.patientId).toLowerCase()===uid)||(!rx.patientId&&String(rx.patient||'').trim().toLowerCase()===String(user.name||'').trim().toLowerCase()));
      main.innerHTML=panel('روشتاتي الطبية','الوصفات التي أصدرها الأطباء لك بعد الاستشارة.',`<section class="wf-hero"><div><div class="wf-eyebrow">الوصفات الطبية</div><h2>وصفاتك في مكان واحد</h2><p>أي وصفة يكتبها الطبيب ويربطها بحسابك ستظهر هنا لتراجعها وترسلها للصيدلية.</p></div><span class="wf-badge">${mine.length} وصفة</span></section><section class="wf-panel"><div class="wf-panel-head"><h3>الوصفات المستلمة</h3></div>${mine.length?mine.map(rx=>`<article class="wf-message"><div class="wf-panel-head"><div><strong>${esc(rx.doctorName||'الطبيب المعالج')}</strong><small>${esc(rx.date||'')}</small></div>${badge(rx.status||'تم إصدارها')}</div><div class="wf-message-body">${esc(rx.details)}</div><small class="wf-muted">رقم الوصفة: ${esc(rx.id||'—')}</small></article>`).join(''):'<div class="wf-empty"><strong>لا توجد وصفات حتى الآن</strong>ستظهر هنا الوصفات التي يصدرها الطبيب المرتبط بحسابك.</div>'}</section>`);
    } else if(tab==='settings') {
      const user=currentUser(),settings=read('patientSettings',{phone:'',email:user.email||'',dateOfBirth:'',gender:'',city:'',notifications:true,emailNotifications:true,smsNotifications:false,language:currentLanguage()==='en'?'English':'العربية'});
      main.innerHTML=panel('إعدادات الحساب','حدّث بياناتك الشخصية ووسائل التواصل وتفضيلات الإشعارات.',`
        <section class="wf-hero"><div><div class="wf-eyebrow">إدارة حسابك</div><h2>بياناتك وتفضيلاتك تحت سيطرتك</h2><p>تقدر تراجع بيانات الحساب وتحدد طريقة استقبال التحديثات والتنبيهات.</p></div><span class="wf-badge">إعدادات المريض</span></section>
        <div class="wf-screen-grid"><section class="wf-panel wf-col-8"><div class="wf-panel-head"><div><span class="wf-section-kicker">البيانات الشخصية</span><h3>معلومات الحساب</h3></div><i data-lucide="user-round-cog"></i></div>
          <form id="wf-patient-settings"><div class="wf-screen-grid">
            <div class="wf-field wf-col-6"><label for="wf-p-name">الاسم بالكامل</label><input id="wf-p-name" name="name" value="${esc(user.name)}" required autocomplete="name"></div>
            <div class="wf-field wf-col-6"><label for="wf-p-phone">رقم الهاتف</label><input id="wf-p-phone" name="phone" type="tel" inputmode="tel" value="${esc(settings.phone)}" placeholder="01xxxxxxxxx" autocomplete="tel"></div>
            <div class="wf-field wf-col-6"><label for="wf-p-email">البريد الإلكتروني</label><input id="wf-p-email" name="email" type="email" value="${esc(settings.email||user.email||'')}" placeholder="name@example.com" autocomplete="email"></div>
            <div class="wf-field wf-col-6"><label for="wf-p-dob">تاريخ الميلاد</label><input id="wf-p-dob" name="dateOfBirth" type="date" value="${esc(settings.dateOfBirth)}"></div>
            <div class="wf-field wf-col-6"><label for="wf-p-gender">النوع</label><select id="wf-p-gender" name="gender"><option value="">اختر</option><option value="ذكر" ${settings.gender==='ذكر'?'selected':''}>ذكر</option><option value="أنثى" ${settings.gender==='أنثى'?'selected':''}>أنثى</option><option value="أفضل عدم التحديد" ${settings.gender==='أفضل عدم التحديد'?'selected':''}>أفضل عدم التحديد</option></select></div>
            <div class="wf-field wf-col-6"><label for="wf-p-city">المحافظة / المدينة</label><input id="wf-p-city" name="city" value="${esc(settings.city)}" placeholder="مثال: الجيزة"></div>
            <div class="wf-field wf-col-6"><label for="wf-p-lang">لغة الواجهة</label><select id="wf-p-lang" name="language"><option ${settings.language==='العربية'?'selected':''}>العربية</option><option ${settings.language==='English'?'selected':''}>English</option></select></div>
          </div><div class="wf-dialog-foot"><button class="wf-btn" type="submit"><i data-lucide="save"></i> حفظ التغييرات</button><button class="wf-btn soft" type="reset">إلغاء التعديلات</button></div></form></section>
          <aside class="wf-panel wf-col-4"><div class="wf-panel-head"><div><span class="wf-section-kicker">التنبيهات</span><h3>تفضيلات الإشعارات</h3></div><i data-lucide="bell-ring"></i></div>
            <form id="wf-patient-notifications"><label class="wf-setting-toggle"><span><strong>كل الإشعارات</strong><small>تحديثات الحساب والمواعيد</small></span><input type="checkbox" name="notifications" ${settings.notifications?'checked':''}></label><label class="wf-setting-toggle"><span><strong>البريد الإلكتروني</strong><small>استلام التحديثات على بريدك</small></span><input type="checkbox" name="emailNotifications" ${settings.emailNotifications?'checked':''}></label><label class="wf-setting-toggle"><span><strong>رسائل الهاتف</strong><small>تنبيهات المواعيد على الهاتف</small></span><input type="checkbox" name="smsNotifications" ${settings.smsNotifications?'checked':''}></label><button class="wf-btn soft" type="submit">حفظ تفضيلات التنبيه</button></form>
          </aside>
          <section class="wf-panel wf-col-12"><div class="wf-panel-head"><div><span class="wf-section-kicker">الأمان والخصوصية</span><h3>حماية الحساب</h3></div><i data-lucide="shield-check"></i></div><div class="wf-security-grid"><div><strong>كلمة المرور</strong><p class="wf-muted">تغيير كلمة المرور يحتاج خدمة مصادقة آمنة مرتبطة بالخادم.</p></div><span class="wf-badge">يتطلب ربط Backend</span><div><strong>التحقق بخطوتين</strong><p class="wf-muted">إعداد التحقق الإضافي سيظهر بعد توصيل خدمة الحسابات.</p></div><span class="wf-badge">غير مفعّل</span></div></section>
        </div>`);
      const patientSettingsForm=$('#wf-patient-settings');
      $('#wf-p-lang')?.addEventListener('change', event => {
        const value = event.target.value === 'English' ? 'en' : 'ar';
        window.ShifaaI18n?.setLanguage(value);
      });
      if(patientSettingsForm) patientSettingsForm.addEventListener('submit',e=>{
        e.preventDefault();const fd=new FormData(e.currentTarget);
        const next={...settings,phone:String(fd.get('phone')||'').trim(),email:String(fd.get('email')||'').trim(),dateOfBirth:fd.get('dateOfBirth')||'',gender:fd.get('gender')||'',city:String(fd.get('city')||'').trim(),language:fd.get('language')||'العربية'};
        const updated={...user,name:String(fd.get('name')||'').trim(),email:next.email,phone:next.phone};
        save('patientSettings',next);save('currentUser',updated);
        const nameNode=$('.topbar-user-name');if(nameNode)nameNode.textContent=updated.name;
        toast('تم حفظ بيانات حسابك محليًا بنجاح.');
      });
      const patientNotificationsForm=$('#wf-patient-notifications');
      if(patientNotificationsForm) patientNotificationsForm.addEventListener('submit',e=>{
        e.preventDefault();const fd=new FormData(e.currentTarget);
        const next={...read('patientSettings',settings),notifications:fd.get('notifications')==='on',emailNotifications:fd.get('emailNotifications')==='on',smsNotifications:fd.get('smsNotifications')==='on'};
        save('patientSettings',next);toast('تم حفظ تفضيلات الإشعارات.');
      });
    }
    refreshIcons();
  }
  function renderDoctor(tab) {
    const main=$('.page-content');if(!main)return;window.__shifaaDoctorTab=tab;setActive(tab);
    if(tab==='appointments') {
      const data=linkedDoctorAppointments();
      main.innerHTML=panel('جدول المواعيد','إدارة حجوزات العيادة وتأكيد الزيارات ومتابعة حالتها.',`
        <section class="wf-hero"><div><div class="wf-eyebrow">إدارة العيادة</div><h2>كل مواعيدك في مكان واحد</h2><p>راجع تفاصيل الزيارات، أكد الموعد أو ألغِه، وافتح ملف المريض قبل بدء الكشف.</p></div><button class="wf-btn" data-action="add-appointment"><i data-lucide="plus"></i> إضافة موعد</button></section>
        <div class="wf-screen-grid">${stat('calendar-days',data.length,'إجمالي المواعيد')}${stat('clock',data.filter(x=>x.status!=='تم التأكيد'&&x.status!=='ملغى').length,'بانتظار الإجراء')}${stat('check-circle',data.filter(x=>x.status==='تم التأكيد').length,'مواعيد مؤكدة')}</div>
        <section class="wf-panel"><div class="wf-panel-head"><h3>طلبات الحجز الواردة ومواعيدي</h3><span class="wf-muted">طلبات المرضى المرتبطة بحساب الطبيب الحالي</span></div><div class="wf-toolbar"><input class="wf-search" id="wf-appointment-search" placeholder="ابحث باسم المريض أو رقم الموعد"><select id="wf-appointment-filter" class="wf-search"><option value="all">كل الحالات</option><option>بانتظار موافقة الطبيب</option><option>بانتظار الدفع</option><option>تم التأكيد</option><option>مرفوض</option><option>ملغى</option></select></div><div id="wf-appointments-table">${appointmentsTable(data)}</div></section>`);
      const search=$('#wf-appointment-search'), filter=$('#wf-appointment-filter'), table=$('#wf-appointments-table');
      const draw=()=>{if(!search||!filter||!table)return;const q=search.value.trim().toLowerCase(),f=filter.value;const rows=linkedDoctorAppointments().filter(x=>(String(x.name||'').toLowerCase().includes(q)||String(x.id||'').toLowerCase().includes(q))&&(f==='all'||x.status===f));table.innerHTML=appointmentsTable(rows);};
      if(search)search.oninput=draw;if(filter)filter.onchange=draw;
    } else if(tab==='patients') {
      const patients=read('doctorPatients',demoPatients);
      main.innerHTML=panel('مرضاي','قائمة المرضى المرتبطين بعيادتك وملفاتهم الأساسية.',`
        <section class="wf-hero"><div><div class="wf-eyebrow">متابعة المرضى</div><h2>رعاية مستمرة لكل مريض</h2><p>ابحث عن مريض وافتح ملخص ملفه لمراجعة بيانات الزيارة.</p></div><span class="wf-badge">${patients.length} مرضى تجريبيين</span></section>
        <section class="wf-panel"><div class="wf-panel-head"><h3>قائمة المرضى</h3></div><div class="wf-toolbar"><input id="wf-patient-search" class="wf-search" placeholder="ابحث باسم المريض"></div><div id="wf-patients-list" class="wf-screen-grid">${patientCards(patients)}</div></section>`);
      const patientSearch=$('#wf-patient-search'), patientList=$('#wf-patients-list');if(patientSearch&&patientList)patientSearch.oninput=e=>{patientList.innerHTML=patientCards(patients.filter(p=>String(p.name||p.fullName||'').includes(e.target.value.trim())));};
    } else if(tab==='prescriptions') {
      const prescriptions=read('prescriptions',[]);
      main.innerHTML=panel('الوصفات الطبية','إنشاء وصفة وتسجيل تفاصيلها ضمن السجل التجريبي.',`
        <section class="wf-hero"><div><div class="wf-eyebrow">الوصفات العلاجية</div><h2>تنظيم الوصفات ومتابعتها</h2><p>أنشئ وصفة جديدة وحدد اسم المريض وتعليمات العلاج.</p></div><button class="wf-btn" data-action="new-prescription"><i data-lucide="file-plus-2"></i> إنشاء وصفة</button></section>
        <section class="wf-panel"><div class="wf-panel-head"><h3>الوصفات المحفوظة</h3><span class="wf-badge">${prescriptions.length} وصفة</span></div>${prescriptions.length?prescriptions.map((p,i)=>`<article class="wf-message"><div class="wf-panel-head"><div class="wf-person"><span class="wf-avatar">${i+1}</span><div><strong>${esc(p.patient)}</strong><small>${esc(p.date)} · ${esc(p.status||'مسودة')}</small></div></div>${badge('مسودة')}</div><div class="wf-message-body">${esc(p.details)}</div></article>`).join(''):'<div class="wf-empty"><strong>لا توجد وصفات حتى الآن</strong>ابدأ بإنشاء وصفة للمريض لتظهر هنا.</div>'}</section>`);
    } else if(tab==='hours') {
      const h=read('doctorHours',{days:['السبت','الأحد','الثلاثاء','الخميس'],from:'16:00',to:'21:00',break:'18:00'});
      main.innerHTML=panel('أوقات العمل','حدد أيام وساعات استقبال المرضى في العيادة.',`
        <section class="wf-hero"><div><div class="wf-eyebrow">تنظيم المواعيد</div><h2>جدول عمل يناسب عيادتك</h2><p>تظهر أوقات العمل للمرضى عند ربط النظام بخدمة الحجز.</p></div><span class="wf-badge">إعدادات الطبيب</span></section>
        <div class="wf-screen-grid"><section class="wf-panel wf-col-7"><div class="wf-panel-head"><h3>أيام العمل</h3></div><form id="wf-hours-form"><div class="wf-screen-grid">${['السبت','الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة'].map(d=>`<label class="wf-panel wf-col-4 wf-inline-check"><input type="checkbox" name="days" value="${d}" ${h.days.includes(d)?'checked':''}> ${d}</label>`).join('')}</div><div class="wf-screen-grid"><div class="wf-field wf-col-6"><label>من الساعة</label><input type="time" name="from" value="${esc(h.from)}" required></div><div class="wf-field wf-col-6"><label>إلى الساعة</label><input type="time" name="to" value="${esc(h.to)}" required></div><div class="wf-field wf-col-6"><label>استراحة اختيارية</label><input type="time" name="break" value="${esc(h.break||'')}"></div></div><button class="wf-btn">حفظ جدول العمل</button></form></section><aside class="wf-panel wf-col-5"><div class="wf-panel-head"><h3>ملخص الجدول الحالي</h3><i data-lucide="calendar-check"></i></div><p class="wf-muted">الأيام المحددة وساعات العمل التي قمت بحفظها.</p><div id="wf-hours-summary">${hoursSummary(h)}</div></aside></div>`);
      const hoursForm=$('#wf-hours-form');if(hoursForm)hoursForm.onsubmit=e=>{e.preventDefault();const fd=new FormData(e.currentTarget),next={days:fd.getAll('days'),from:fd.get('from'),to:fd.get('to'),break:fd.get('break')};if(!next.days.length||next.from>=next.to){toast('اختر يوم عمل واحدًا على الأقل وتأكد من صحة الساعات.');return;}save('doctorHours',next);const summary=$('#wf-hours-summary');if(summary)summary.innerHTML=hoursSummary(next);toast('تم حفظ أوقات العمل محليًا.');};
    } else if(tab==='settings') {
      const registration=read('registrationDraft',{});
      const s=read('doctorSettings',{name:registration.FullName||'د. محمد حسن',specialty:registration.Specialty||'القلب والأوعية الدموية',licenseNumber:registration.LicenseNumber||'',experienceYears:registration.ExperienceYears||'',consultationFee:registration.ConsultationFee||'',hospital:registration.HospitalName||'',clinic:registration.ClinicName||'عيادة النخيل - الدقي',clinicAddress:registration.ClinicAddress||'',phone:registration.PhoneNumber||'',bio:registration.Bio||''});
      main.innerHTML=panel('ملفي المهني','راجع بياناتك المهنية التي سجلتها عند الانضمام إلى شفاء، ويمكنك تحديثها في أي وقت.',`
        <section class="wf-hero"><div><div class="wf-eyebrow">الملف المهني للطبيب</div><h2>${esc(s.name||'ملف الطبيب')}</h2><p>${esc(s.specialty||'أضف تخصصك')} · ${s.experienceYears?esc(s.experienceYears)+' سنوات خبرة':'سنوات الخبرة غير محددة'}</p></div><span class="wf-badge">بيانات قابلة للتعديل</span></section>
        <div class="wf-screen-grid wf-doctor-profile-summary">
          <article class="wf-panel wf-col-4"><span class="wf-section-kicker">التخصص</span><strong>${esc(s.specialty||'غير مسجل')}</strong></article>
          <article class="wf-panel wf-col-4"><span class="wf-section-kicker">سنوات الخبرة</span><strong>${esc(s.experienceYears||'غير مسجل')}</strong></article>
          <article class="wf-panel wf-col-4"><span class="wf-section-kicker">سعر الكشف</span><strong>${s.consultationFee?esc(s.consultationFee)+' جنيه':'غير مسجل'}</strong></article>
          <article class="wf-panel wf-col-6"><span class="wf-section-kicker">المستشفى</span><strong>${esc(s.hospital||'غير مسجل')}</strong></article>
          <article class="wf-panel wf-col-6"><span class="wf-section-kicker">عنوان العيادة</span><strong>${esc(s.clinicAddress||s.clinic||'غير مسجل')}</strong></article>
        </div>
        <div class="wf-screen-grid"><section class="wf-panel wf-col-8"><div class="wf-panel-head"><h3>تعديل بيانات الملف المهني</h3></div>
          <form id="wf-doctor-settings" class="wf-doctor-profile-form">
            <div class="wf-screen-grid">
              <div class="wf-field wf-col-6"><label for="wf-doc-name">الاسم بالكامل</label><input id="wf-doc-name" name="name" value="${esc(s.name)}" required></div>
              <div class="wf-field wf-col-6"><label for="wf-doc-specialty">التخصص الطبي</label><input id="wf-doc-specialty" name="specialty" value="${esc(s.specialty)}" required placeholder="مثال: قلب وأوعية دموية"></div>
              <div class="wf-field wf-col-6"><label for="wf-doc-license">رقم الترخيص المهني</label><input id="wf-doc-license" name="licenseNumber" value="${esc(s.licenseNumber)}" required></div>
              <div class="wf-field wf-col-6"><label for="wf-doc-exp">سنوات الخبرة</label><input id="wf-doc-exp" name="experienceYears" type="number" min="0" max="70" step="1" value="${esc(s.experienceYears)}" required></div>
              <div class="wf-field wf-col-6"><label for="wf-doc-fee">سعر الكشف (جنيه)</label><input id="wf-doc-fee" name="consultationFee" type="number" min="0" step="1" value="${esc(s.consultationFee)}" required></div>
              <div class="wf-field wf-col-6"><label for="wf-doc-hospital">المستشفى التي تعمل بها</label><input id="wf-doc-hospital" name="hospital" value="${esc(s.hospital)}" placeholder="اسم المستشفى"></div>
              <div class="wf-field wf-col-6"><label for="wf-doc-clinic">اسم العيادة</label><input id="wf-doc-clinic" name="clinic" value="${esc(s.clinic)}"></div>
              <div class="wf-field wf-col-6"><label for="wf-doc-address">عنوان العيادة بالتفصيل</label><input id="wf-doc-address" name="clinicAddress" value="${esc(s.clinicAddress)}" placeholder="المنطقة، الشارع، رقم المبنى"></div>
              <div class="wf-field wf-col-6"><label for="wf-doc-phone">رقم التواصل</label><input id="wf-doc-phone" name="phone" type="tel" value="${esc(s.phone)}"></div>
              <div class="wf-field wf-col-12"><label for="wf-doc-bio">نبذة تعريفية ومؤهلات إضافية</label><textarea id="wf-doc-bio" name="bio" rows="4">${esc(s.bio)}</textarea></div>
            </div><button class="wf-btn" type="submit"><i data-lucide="save"></i> حفظ التعديلات</button>
          </form></section>
          <aside class="wf-panel wf-col-4"><div class="wf-panel-head"><h3>حالة الحساب المهني</h3><i data-lucide="badge-check"></i></div><p class="wf-muted">تظهر بياناتك في ملفك المهني، ويمكن مراجعتها واعتمادها من إدارة شفاء بعد ربط النظام بالخادم.</p>${badge('تجريبي')}</aside></div>`);
      const doctorSettingsForm=$('#wf-doctor-settings');if(doctorSettingsForm)doctorSettingsForm.onsubmit=e=>{e.preventDefault();const next=Object.fromEntries(new FormData(e.currentTarget));save('doctorSettings',next);const user=read('currentUser',{});save('currentUser',{...user,name:next.name,role:'doctor',roleLabel:'طبيب',specialty:next.specialty});toast('تم تحديث ملفك المهني محليًا.');renderDoctor('settings');};
    }
    refreshIcons();
  }
  function appointmentsTable(rows){return rows.length?`<div class="wf-table-wrap"><table class="wf-table"><thead><tr><th>رقم الموعد</th><th>المريض</th><th>رقم التواصل</th><th>الوقت</th><th>نوع الزيارة</th><th>الحالة</th><th>الإجراءات</th></tr></thead><tbody>${rows.map(a=>`<tr><td>${esc(a.id)}</td><td><strong>${esc(a.name)}</strong>${a.notes?`<small class="wf-muted">${esc(a.notes)}</small>`:''}</td><td>${esc(a.phone||'غير مسجل')}</td><td>${esc(a.time)}</td><td>${esc(a.type)}</td><td>${badge(a.status)}</td><td><button class="wf-btn soft small" data-action="patient-file" data-name="${esc(a.name)}">الملف</button>${a.status==='بانتظار موافقة الطبيب'?`<button class="wf-btn small" data-action="confirm-appointment" data-id="${esc(a.id)}">الموافقة</button><button class="wf-btn danger small" data-action="cancel-appointment" data-id="${esc(a.id)}">رفض الطلب</button>`:''}${a.status==='تم التأكيد'?`<button class="wf-btn warning small" data-action="start-exam" data-id="${esc(a.id)}">ابدأ الكشف</button>`:''}</td></tr>`).join('')}</tbody></table></div>`:'<div class="wf-empty"><strong>لا توجد طلبات حجز واردة لهذا الطبيب</strong>ستظهر هنا طلبات المرضى الموجهة إلى حسابك بمجرد إرسالها.</div>';}
  function patientCards(rows){return rows.length?rows.map(p=>`<article class="wf-panel wf-col-6"><div class="wf-panel-head"><div class="wf-person"><span class="wf-avatar">${esc(p.name[0])}</span><div><strong>${esc(p.name)}</strong><small>${esc(p.type)} · ${esc(p.city)}</small></div></div>${badge(p.status)}</div><button class="wf-btn soft small" data-action="patient-file" data-name="${esc(p.name)}">فتح ملف المريض</button></article>`).join(''):'<div class="wf-empty wf-col-12"><strong>لا يوجد مرضى مطابقون</strong>جرّب البحث باسم آخر.</div>';}
  function hoursSummary(h){return `<div class="wf-list">${h.days.map(d=>`<div class="wf-list-item"><strong>${esc(d)}</strong><span>${esc(h.from)} – ${esc(h.to)}</span></div>`).join('')||'<div class="wf-empty">لم يتم تحديد أيام عمل</div>'}</div>`;}
  function renderAdmin(tab) {
    const main=$('.page-content');if(!main)return;window.__shifaaAdminTab=tab;setActive(tab);
    const msgs=read('supportMessages',[]);
    if(tab==='messages') {
      main.innerHTML=panel('رسائل الدعم','كل الرسائل الواردة من المرضى والأطباء إلى فريق شفاء.',`
        <section class="wf-hero"><div><div class="wf-eyebrow">مركز التواصل</div><h2>صوت المستخدمين يهمنا</h2><p>تابع الشكاوى والاستفسارات والطلبات، وسجل رد فريق شفاء مع تحديث حالة الرسالة.</p></div><span class="wf-badge">${msgs.length} رسالة</span></section>
        <div class="wf-screen-grid">${stat('inbox',msgs.length,'إجمالي الرسائل')}${stat('mail-open',msgs.filter(m=>['جديدة','New'].includes(String(m.status||''))).length,'رسائل جديدة')}${stat('message-circle-check',msgs.filter(m=>m.status==='تم الرد').length,'تم الرد عليها')}</div>
        <section class="wf-panel"><div class="wf-panel-head"><h3>صندوق الوارد</h3><span class="wf-muted">مصدر الرسالة يوضح صفحة الإرسال ودور صاحبها</span></div><div class="wf-toolbar"><input id="wf-message-search" class="wf-search" placeholder="بحث بالاسم أو العنوان أو المحتوى"><select id="wf-message-filter" class="wf-search"><option value="all">كل الرسائل</option><option value="جديدة">جديدة</option><option value="قيد المراجعة">قيد المراجعة</option><option value="تم الرد">تم الرد</option><option value="مغلقة">مغلقة</option></select><select id="wf-message-role" class="wf-search"><option value="all">كل المرسلين</option><option value="patient">مرضى</option><option value="doctor">أطباء</option></select></div><div id="wf-message-list">${messageCards(msgs)}</div></section>`);
      const search=$('#wf-message-search'), filter=$('#wf-message-filter'), roleFilter=$('#wf-message-role'), list=$('#wf-message-list');
      const draw=()=>{if(!search||!filter||!roleFilter||!list)return;const q=search.value.trim().toLowerCase(),f=filter.value,r=roleFilter.value;const filtered=read('supportMessages',[]).filter(m=>(f==='all'||m.status===f)&&(r==='all'||m.role===r)&&[m.from,m.subject,m.message].join(' ').toLowerCase().includes(q));list.innerHTML=messageCards(filtered);};
      if(search)search.oninput=draw;if(filter)filter.onchange=draw;if(roleFilter)roleFilter.onchange=draw;
    } else if(tab==='doctors'||tab==='patients'||tab==='appointments'||tab==='pharmacies') {
      const title={doctors:'إدارة الأطباء',patients:'إدارة المرضى',appointments:'إدارة المواعيد',pharmacies:'إدارة الصيدليات'}[tab];
      const linkedPatients=(()=>{const bookings=readBookings();const unique=new Map();bookings.forEach(b=>{const pid=bookingPatientId(b)||String(b.PatientName||'').toLowerCase();if(pid&&!unique.has(pid))unique.set(pid,{id:pid,name:b.PatientName||'مريض',type:'مريض',city:b.City||'غير محدد',status:'نشط'});});return [...unique.values()];})();
      const rows=tab==='doctors'?read('adminDoctors',demoDoctors):tab==='patients'?[...read('adminPatients',demoPatients),...linkedPatients.filter(p=>!read('adminPatients',demoPatients).some(x=>String(x.email||x.id||x.name).toLowerCase()===String(p.id||p.name).toLowerCase()))]:tab==='appointments'?linkedDoctorAppointments():read('adminPharmacies',[{name:'صيدلية النخيل',specialty:'صيدلية مجتمعية',city:'الدقي',status:'مسجلة'},{name:'صيدلية الحياة',specialty:'صيدلية مجتمعية',city:'المهندسين',status:'مسجلة'}]);
      const cols=tab==='doctors'?['الاسم','التخصص','المحافظة','الحالة']:tab==='patients'?['الاسم','نوع الحساب','المحافظة','الحالة']:tab==='appointments'?['رقم الموعد','المريض','نوع الزيارة','الحالة']:['اسم الصيدلية','نوع النشاط','الموقع','الحالة'];
      main.innerHTML=panel(title,`مراجعة وتنظيم بيانات ${title.replace('إدارة ','')} داخل المنصة.`, `
        <section class="wf-hero"><div><div class="wf-eyebrow">إدارة المنصة</div><h2>${title}</h2><p>يمكن لفريق دعم شفاء إرسال تحذير أو إيقاف الحساب مؤقتًا أو حظره عند وجود مخالفة. السجلات الحالية أمثلة توضيحية.</p></div><span class="wf-badge">${rows.length} سجلات تجريبية</span></section>
        <section class="wf-panel"><div class="wf-panel-head"><h3>السجلات</h3><a class="wf-btn soft small" href="#moderation" data-admin-go="moderation">سجل إجراءات الإدارة</a></div><div class="wf-toolbar"><input class="wf-search" id="wf-admin-search" placeholder="ابحث في السجلات"><select class="wf-search" id="wf-admin-status"><option value="all">كل الحالات</option><option>نشط</option><option>مسجلة</option><option>تحذير</option><option>موقوف مؤقتًا</option><option>محظور</option><option>تم التأكيد</option><option>ملغى</option></select></div><div id="wf-admin-table">${adminTable(rows,cols,tab)}</div></section>`);
      const search=$('#wf-admin-search'), statusFilter=$('#wf-admin-status'), table=$('#wf-admin-table');const draw=()=>{if(!search||!statusFilter||!table)return;const q=search.value.trim().toLowerCase(),f=statusFilter.value;const sourceRows=tab==='appointments'?linkedDoctorAppointments():rows;const filtered=sourceRows.filter(r=>{const state=moderationFor(tab,r);return Object.values(r).join(' ').toLowerCase().includes(q)&&(f==='all'||(state?.status||r.status)===f||(f==='تحذير'&&(state?.warnings||[]).length>0));});table.innerHTML=adminTable(filtered,cols,tab);};if(search)search.oninput=draw;if(statusFilter)statusFilter.onchange=draw;
    } else if(tab==='payments') {
      const demoPayments=[
        {id:'PAY-DEMO-1001',payer:'أحمد محمود',purpose:'استشارة أونلاين',amount:'450.00 EGP',method:'Visa',status:'بانتظار الدفع',provider:'Paymob',date:'2026-11-26'},
        {id:'PAY-DEMO-1002',payer:'نورهان علي',purpose:'طلب صيدلية PH-DEMO-204',amount:'320.00 EGP',method:'محفظة إلكترونية',status:'فشل تجريبي',provider:'Paymob',date:'2026-11-25'},
        {id:'PAY-DEMO-1003',payer:'يوسف عادل',purpose:'استشارة أونلاين',amount:'500.00 EGP',method:'Mastercard',status:'مدفوع - مثال توضيحي',provider:'Paymob',date:'2026-11-24'}
      ];
      let rows=read('demoPayments',null);if(!rows){rows=demoPayments;save('demoPayments',rows);}
      main.innerHTML=panel('إدارة المدفوعات','متابعة معاملات الاستشارات وطلبات الصيدليات عبر بوابة Paymob.',`
        <section class="wf-hero"><div><div class="wf-eyebrow">المتابعة المالية</div><h2>مراجعة حالة الدفع</h2><p>يعرض هذا القسم حالة كل معاملة ورقمها وطريقتها. لا يستطيع الأدمن تحويل معاملة إلى «مدفوعة» يدويًا؛ تأكيد الدفع يجب أن يأتي من إشعار Paymob الموثّق عبر الخادم.</p></div><span class="wf-badge">Paymob · عرض تجريبي</span></section>
        <div class="wf-screen-grid">${stat('credit-card',rows.length,'معاملات في العينة')}${stat('clock',rows.filter(x=>String(x.status).includes('انتظار')).length,'بانتظار الدفع')}${stat('alert-circle',rows.filter(x=>String(x.status).includes('فشل')).length,'عمليات فاشلة')}</div>
        <section class="wf-panel"><div class="wf-panel-head"><h3>سجل المعاملات</h3><span class="wf-muted">بيانات توضيحية وليست معاملات حقيقية</span></div><div class="wf-table-wrap"><table class="wf-table"><thead><tr><th>رقم العملية</th><th>المستخدم</th><th>الغرض</th><th>المبلغ</th><th>الوسيلة</th><th>الحالة</th><th>التاريخ</th><th>الإجراء</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${esc(r.id)}</td><td>${esc(r.payer)}</td><td>${esc(r.purpose)}</td><td>${esc(r.amount)}</td><td>${esc(r.method)}</td><td>${badge(r.status)}</td><td>${esc(r.date)}</td><td><button class="wf-btn soft small" data-action="payment-details" data-id="${esc(r.id)}">التفاصيل</button>${String(r.status).includes('مدفوع')?` <button class="wf-btn warning small" data-action="payment-refund-request" data-id="${esc(r.id)}">طلب مراجعة استرداد</button>`:''}</td></tr>`).join('')}</tbody></table></div></section>
        <aside class="wf-panel"><div class="wf-panel-head"><h3>صلاحيات الأدمن في المدفوعات</h3><i data-lucide="shield-check"></i></div><ul class="online-admin-permissions"><li>عرض تفاصيل المعاملة وحالتها.</li><li>متابعة العمليات الفاشلة أو المعلّقة.</li><li>تسجيل طلب مراجعة استرداد وإحالته للإجراء المالي المعتمد.</li><li>لا يمكن تعديل المبلغ أو تزوير حالة الدفع أو الاطلاع على بيانات البطاقة الحساسة.</li></ul><p class="wf-muted">تنفيذ الاسترداد والتحقق من الدفع يحتاجان إلى Backend واتصال Paymob موثّق.</p></aside>`);
    } else if(tab==='pharmacy-orders') {
      const demoOrders=[{id:'PH-DEMO-204',patientName:'نورهان علي',pharmacyName:'صيدلية السلام',prescriptionFileName:'prescription-demo.pdf',status:'بانتظار مراجعة الصيدلية',paymentStatus:'لم يتم الدفع',createdAt:'2026-11-26T10:30:00Z',deliveryAddress:'الدقي، الجيزة'},{id:'PH-DEMO-205',patientName:'يوسف عادل',pharmacyName:'صيدلية النيل',prescriptionFileName:'rx-demo.jpg',status:'تم تأكيد التوافر والسعر',paymentStatus:'بانتظار الدفع',createdAt:'2026-11-25T13:00:00Z',deliveryAddress:'المهندسين، الجيزة'}];
      let rows=read('pharmacyOrders',null);if(!rows){rows=demoOrders;save('pharmacyOrders',rows);}
      main.innerHTML=panel('طلبات الصيدليات','متابعة الروشتات المرسلة للصيدليات ومراجعة حالة التجهيز والتوصيل.',`<section class="wf-hero"><div><div class="wf-eyebrow">خدمة الصيدليات</div><h2>طلبات الدواء أونلاين</h2><p>الصيدلية تراجع الروشتة وتؤكد توافر الأدوية والسعر، ثم يدفع المريض إلكترونيًا قبل تجهيز الطلب وتوصيله.</p></div><span class="wf-badge">${rows.length} طلب في العينة</span></section><div class="wf-screen-grid">${stat('file-text',rows.length,'طلبات مسجلة')}${stat('clock',rows.filter(x=>String(x.status).includes('انتظار')).length,'طلبات قيد المتابعة')}${stat('truck',rows.filter(x=>String(x.status).includes('توصيل')).length,'طلبات توصيل')}</div><section class="wf-panel"><div class="wf-panel-head"><h3>سجل طلبات الصيدليات</h3><span class="wf-muted">المرفقات والطلبات الفعلية تتطلب خادمًا آمنًا</span></div><div class="wf-table-wrap"><table class="wf-table"><thead><tr><th>رقم الطلب</th><th>المريض</th><th>الصيدلية</th><th>ملف الروشتة</th><th>حالة الطلب</th><th>حالة الدفع</th><th>عنوان التوصيل</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${esc(r.id)}</td><td>${esc(r.patientName)}</td><td>${esc(r.pharmacyName)}</td><td>${esc(r.prescriptionFileName||'—')}</td><td>${badge(r.status)}</td><td>${badge(r.paymentStatus)}</td><td>${esc(r.deliveryAddress||'—')}</td></tr>`).join('')}</tbody></table></div></section><aside class="wf-panel"><div class="wf-panel-head"><h3>مسؤوليات الأدمن</h3><i data-lucide="clipboard-check"></i></div><ul class="online-admin-permissions"><li>متابعة الطلبات وحالات مراجعة الصيدلية.</li><li>متابعة الشكاوى والتأخير أو رفض الطلب.</li><li>إدارة حالة حساب الصيدلية عند وجود مخالفة.</li><li>لا يعتمد الأدمن توافر الدواء أو يحدد السعر نيابةً عن الصيدلية.</li></ul></aside>`);
    } else if(tab==='moderation') {
      const logs=read('adminModerationLog',[]);
      const blocked=logs.filter(x=>x.action==='حظر').length, warnings=logs.filter(x=>x.action==='تحذير').length, suspended=logs.filter(x=>x.action==='إيقاف مؤقت').length;
      main.innerHTML=panel('إدارة المخالفات','مركز فريق دعم شفاء لمتابعة التحذيرات والإيقافات والحظر وقرارات رفعها.', `<section class="wf-hero"><div><div class="wf-eyebrow">سلامة المجتمع</div><h2>إجراءات واضحة ومسؤولة</h2><p>كل إجراء يُسجل مع اسم المسؤول والسبب والتاريخ، ويمكن مراجعة سجل القرارات في أي وقت.</p><p class="wf-muted"><strong>مهم:</strong> هذه نسخة واجهة تجريبية تحفظ القرارات داخل هذا المتصفح فقط؛ تعطيل الحساب فعليًا وإرسال التحذير للمستخدم يتطلب ربط صلاحيات وخدمات الخادم.</p></div><span class="wf-badge">${logs.length} إجراء مسجل</span></section><div class="wf-screen-grid">${stat('alert-triangle',warnings,'تحذيرات')}${stat('pause-circle',suspended,'إيقافات مؤقتة')}${stat('ban',blocked,'حالات حظر')}</div><section class="wf-panel"><div class="wf-panel-head"><h3>سجل إجراءات الإدارة</h3></div>${moderationLogTable(logs)}</section>`);
    } else if(tab==='reports') {
      const appointments=linkedDoctorAppointments(), support=read('supportMessages',[]), payments=read('demoPayments',[]), pharmacyOrders=read('pharmacyOrders',[]), activity=read('activityLog',[]);
      main.innerHTML=panel('التقارير والإحصائيات','نظرة تجميعية على بيانات النموذج التجريبي.',`<section class="wf-hero"><div><div class="wf-eyebrow">مؤشرات المنصة</div><h2>تقارير تشغيلية</h2><p>تساعدك المؤشرات التالية على متابعة النشاط. ستعتمد التقارير الفعلية على بيانات قاعدة البيانات.</p></div><div class="wf-toolbar"><button class="wf-btn" data-action="export-report" data-report="appointments">تصدير تقرير المواعيد CSV</button><button class="wf-btn soft" data-action="export-report" data-report="support">تصدير رسائل الدعم CSV</button></div></section><div class="wf-screen-grid">${stat('calendar-check',appointments.length,'مواعيد في العينة')}${stat('users',demoPatients.length,'مرضى في العينة')}${stat('messages-square',support.length,'رسائل الدعم')}${stat('credit-card',payments.length,'معاملات الدفع')}${stat('pill',pharmacyOrders.length,'طلبات الصيدليات')}${stat('activity',activity.length,'تحديثات مسجلة')}</div><section class="wf-panel"><div class="wf-panel-head"><h3>آخر التحديثات على حسابات المرضى والأطباء</h3></div>${activity.length?activity.slice(0,12).map(a=>`<div class="wf-list-item"><span>${esc(a.description||a.type)} · ${esc(a.patientName||'')}</span><small>${esc(new Date(a.createdAt).toLocaleString(dateLocale()))}</small></div>`).join(''):'<p class="wf-muted">لا توجد تحديثات مسجلة بعد.</p>'}</section><section class="wf-panel"><div class="wf-panel-head"><h3>ملخص الحالات</h3></div><div class="wf-list"><div class="wf-list-item"><span>مواعيد مؤكدة</span><strong>${appointments.filter(a=>a.status==='تم التأكيد').length}</strong></div><div class="wf-list-item"><span>مواعيد بانتظار التأكيد</span><strong>${appointments.filter(a=>a.status==='بانتظار التأكيد').length}</strong></div><div class="wf-list-item"><span>رسائل دعم جديدة</span><strong>${support.filter(m=>['جديدة','New'].includes(String(m.status||''))).length}</strong></div></div></section>`);
    } else if(tab==='settings') {
      const s=read('adminSettings',{platformName:'شفاء',supportEmail:'support@shifaa.example',notifications:true});
      main.innerHTML=panel('إعدادات المنصة','تفضيلات عامة لإدارة واجهة شفاء التجريبية.',`<div class="wf-screen-grid"><section class="wf-panel wf-col-7"><div class="wf-panel-head"><h3>الإعدادات العامة</h3></div><form id="wf-admin-settings"><div class="wf-field"><label>اسم المنصة</label><input name="platformName" value="${esc(s.platformName)}" required></div><div class="wf-field"><label>بريد الدعم المعروض</label><input name="supportEmail" type="email" value="${esc(s.supportEmail)}"></div><label class="wf-inline-check"><input type="checkbox" name="notifications" ${s.notifications?'checked':''}> تفعيل تنبيهات لوحة الإدارة</label><div class="wf-dialog-foot"><button class="wf-btn">حفظ الإعدادات</button></div></form></section><aside class="wf-panel wf-col-5"><div class="wf-panel-head"><h3>الأمان والصلاحيات</h3><i data-lucide="shield-check"></i></div><p class="wf-muted">إنشاء الأدوار والصلاحيات الحقيقية وإدارة حسابات فريق شفاء يجب أن تتم من الخادم، وليس من واجهة المتصفح.</p>${badge('تحتاج Backend')}</aside></div>`);
      const adminSettingsForm=$('#wf-admin-settings');if(adminSettingsForm)adminSettingsForm.onsubmit=e=>{e.preventDefault();const fd=new FormData(e.currentTarget);save('adminSettings',{platformName:fd.get('platformName'),supportEmail:fd.get('supportEmail'),notifications:fd.get('notifications')==='on'});toast('تم حفظ الإعدادات محليًا.');};
    }
    refreshIcons();
  }
  function messageCards(rows) {
    if(!rows.length)return '<div class="wf-empty"><strong>صندوق الدعم فارغ</strong>ستظهر هنا الرسائل التي يرسلها المرضى والأطباء من زر «محتاج مساعدة؟».</div>';
    return rows.map(m=>`<article class="wf-message"><div class="wf-panel-head"><div><h3>${esc(m.subject)}</h3><div class="wf-message-meta"><span>${esc(m.from)}</span><span>· ${esc(m.roleLabel|| (m.role==='doctor'?'طبيب':'مريض'))}</span><span>· ${esc(m.source||'واجهة شفاء')}</span><span>· ${esc(new Date(m.date).toLocaleString(dateLocale()))}</span></div></div>${badge(m.status)}</div><div class="wf-message-meta"><span>نوع الرسالة: ${esc(m.kind)}</span><span>رقم: ${esc(m.id)}</span></div><div class="wf-message-body">${esc(m.message)}</div>${m.reply?`<div class="wf-reply"><strong>رد فريق شفاء</strong><p>${esc(m.reply)}</p><small class="wf-muted">${m.repliedAt?esc(new Date(m.repliedAt).toLocaleString(dateLocale())):''}</small></div>`:''}<div class="wf-toolbar" style="margin-top:14px"><button class="wf-btn small" data-action="reply-message" data-id="${esc(m.id)}">${m.reply?'تعديل الرد':'كتابة رد'}</button><button class="wf-btn soft small" data-action="message-review" data-id="${esc(m.id)}">${m.status==='قيد المراجعة'?'إعادة فتح':'قيد المراجعة'}</button><button class="wf-btn danger small" data-action="message-close" data-id="${esc(m.id)}">إغلاق الرسالة</button></div></article>`).join('');
  }
  function moderationKey(kind,row){return `${kind}|${row.name||row.id||'unknown'}|${row.city||row.location||''}`;}
  function moderationFor(kind,row){return read('adminModeration',{})[moderationKey(kind,row)]||null;}
  function adminTable(rows,cols,tab){if(!rows.length)return '<div class="wf-empty"><strong>لا توجد نتائج</strong>لم يتم العثور على سجلات مطابقة.</div>';return `<div class="wf-table-wrap"><table class="wf-table"><thead><tr>${cols.map(c=>`<th>${c}</th>`).join('')}<th>إجراء</th></tr></thead><tbody>${rows.map(r=>{const state=tab==='appointments'?null:moderationFor(tab,r);const status=state?.status||r.status;const values=tab==='appointments'?[r.id,r.name,r.type,status]:[r.name,r.specialty||r.type||r.city,r.city||r.specialty,status];const kindLabel={doctors:'طبيب',patients:'مريض',pharmacies:'صيدلية'}[tab]||'';return `<tr>${values.map((v,i)=>`<td>${i===values.length-1?badge(v):esc(v)}</td>`).join('')}<td class="wf-admin-actions"><button class="wf-btn soft small" data-action="admin-record" data-name="${esc(r.name||r.id||'سجل')}">التفاصيل</button>${tab!=='appointments'?`<button class="wf-btn warning small" data-action="admin-moderate" data-kind="${tab}" data-name="${esc(r.name||'') }" data-city="${esc(r.city||'') }" data-role-label="${kindLabel}">إدارة الحالة</button>`:''}</td></tr>`}).join('')}</tbody></table></div>`;}
  function moderationLogTable(rows){if(!rows.length)return '<div class="wf-empty"><strong>لا توجد إجراءات بعد</strong>ستظهر هنا كل التحذيرات والإيقافات وقرارات الحظر التي يتخذها فريق الإدارة.</div>';return `<div class="wf-table-wrap"><table class="wf-table"><thead><tr><th>المستخدم</th><th>النوع</th><th>الإجراء</th><th>السبب</th><th>المسؤول</th><th>التاريخ</th></tr></thead><tbody>${rows.map(x=>`<tr><td>${esc(x.target)}</td><td>${esc(x.roleLabel)}</td><td>${badge(x.action)}</td><td>${esc(x.reason)}</td><td>${esc(x.actor)}</td><td>${esc(new Date(x.date).toLocaleString(dateLocale()))}</td></tr>`).join('')}</tbody></table></div>`;}
  function openModerationDialog(kind,name,city,roleLabel){
    const key=moderationKey(kind,{name,city}),states=read('adminModeration',{}),current=states[key]||{};
    dialog('إجراء إداري على الحساب',`<div class="wf-hero compact"><div><h2>${esc(name)}</h2><p>${esc(roleLabel)} · ${esc(city||'الموقع غير محدد')}</p></div><span class="wf-badge">${esc(current.status||'نشط')}</span></div><form id="wf-moderation-form"><div class="wf-field"><label for="wf-moderation-action">نوع الإجراء</label><select id="wf-moderation-action" name="action" required><option value="تحذير">إرسال تحذير رسمي</option><option value="إيقاف مؤقت">إيقاف الحساب مؤقتًا</option><option value="حظر">حظر الحساب</option><option value="رفع الإيقاف">رفع الإيقاف / إعادة التفعيل</option></select></div><div class="wf-field" id="wf-suspension-duration-wrap"><label for="wf-suspension-duration">مدة الإيقاف</label><select id="wf-suspension-duration" name="duration"><option value="24 ساعة">24 ساعة</option><option value="3 أيام">3 أيام</option><option value="7 أيام">7 أيام</option><option value="30 يومًا">30 يومًا</option></select></div><div class="wf-field"><label for="wf-moderation-reason">سبب الإجراء (إلزامي)</label><textarea id="wf-moderation-reason" name="reason" required minlength="5" maxlength="1000" placeholder="اكتب تفاصيل المخالفة أو سبب القرار..."></textarea></div><p class="wf-muted">سيُحفظ الإجراء في سجل الإدارة المحلي مع اسم المسؤول وتاريخه.</p><div class="wf-dialog-foot"><button class="wf-btn danger" type="submit">تأكيد الإجراء</button></div></form>`,(root,close)=>{
      const action=$('#wf-moderation-action',root),duration=$('#wf-suspension-duration-wrap',root);action.onchange=()=>duration.hidden=action.value!=='إيقاف مؤقت';duration.hidden=action.value!=='إيقاف مؤقت';
      $('#wf-moderation-form',root).onsubmit=e=>{e.preventDefault();const fd=new FormData(e.currentTarget),choice=fd.get('action'),reason=fd.get('reason').trim();if(reason.length<5)return;const all=read('adminModeration',{}),old=all[key]||{warnings:[]};old.warnings=old.warnings||[];if(choice==='تحذير'){old.warnings.unshift({reason,date:new Date().toISOString()});if(!['محظور','موقوف مؤقتًا'].includes(old.status))old.status='تحذير';}else if(choice==='إيقاف مؤقت'){old.previousStatus=old.status||'نشط';old.status='موقوف مؤقتًا';old.duration=fd.get('duration');}else if(choice==='حظر'){old.previousStatus=old.status||'نشط';old.status='محظور';old.duration='دون مدة محددة';}else{old.status=old.previousStatus||'نشط';old.duration='';old.previousStatus='';}all[key]=old;save('adminModeration',all);const logs=read('adminModerationLog',[]),actor=currentUser();logs.unshift({id:'MOD-'+Date.now(),target:name,kind,roleLabel,action:choice,reason,duration:fd.get('duration')||'',actor:actor.name||'مسؤول شفاء',date:new Date().toISOString()});save('adminModerationLog',logs);close();if(window.__shifaaAdminTab==='moderation')renderAdmin('moderation');else renderAdmin(kind);toast(choice==='تحذير'?'تم تسجيل التحذير.':choice==='حظر'?'تم تسجيل قرار الحظر في النموذج المحلي.':choice==='إيقاف مؤقت'?'تم تسجيل الإيقاف المؤقت.':'تم تسجيل إعادة التفعيل.');};
    });
  }
  function doctorPatientFile(name) {
    const key=String(name||'').trim().toLowerCase();
    const bookings=readBookings();
    const booking=bookings.find(b=>String(b.PatientName||b.patientName||'').trim().toLowerCase()===key);
    const patientId=booking?bookingPatientId(booking):'';
    const medical=read('patientMedicalRecords',{})[patientId]||read('patientMedicalRecord',{});
    const medicalMatches=!!patientId && String(medical.patientId||'').toLowerCase()===patientId;
    const profile=medicalMatches?medical:null;
    const prescriptions=read('prescriptions',[]).filter(rx=>String(rx.patientId||'').toLowerCase()===patientId || (!rx.patientId && String(rx.patient||'').trim().toLowerCase()===key));
    const list=v=>Array.isArray(v)&&v.length?v.join('، '):'غير مسجل';
    dialog('ملف المريض',`<div class="wf-person"><span class="wf-avatar">${esc(String(name||'م').charAt(0))}</span><div><strong>${esc(name||'المريض')}</strong><small>ملف مرتبط بطلبات الحجز في شفاء</small></div></div><div class="wf-screen-grid" style="margin-top:16px"><div class="wf-panel wf-col-6"><strong>بيانات الحجز</strong><p class="wf-muted">${booking?`رقم الطلب: ${esc(booking.id)}<br>حالة الدفع: ${esc(booking.paymentStatus||'قيد المراجعة')}`:'لا يوجد حجز مرتبط بهذا الاسم في هذا المتصفح.'}</p></div><div class="wf-panel wf-col-6"><strong>الملف الصحي</strong><p class="wf-muted">${profile?`فصيلة الدم: ${esc(profile.bloodType||'غير مسجلة')}<br>الطول: ${esc(profile.heightCm||'—')} سم · الوزن: ${esc(profile.weightKg||'—')} كجم<br>الحساسية: ${esc(list(profile.allergies))}<br>الأمراض المزمنة: ${esc(list(profile.chronicConditions))}<br>الأدوية الحالية: ${esc(list(profile.medications))}<br>ملاحظات: ${esc(profile.notes||'لا توجد')}`:'لم يُعثر على ملف طبي لهذا المريض. يجب أن يكون المريض قد حفظ ملفه من نفس حسابه.'}</p></div><div class="wf-panel wf-col-12"><strong>الوصفات الطبية المرتبطة</strong>${prescriptions.length?prescriptions.map(rx=>`<p class="wf-message-body">${esc(rx.details)} <small>(${esc(rx.date||'')})</small></p>`).join(''):'<p class="wf-muted">لا توجد وصفات محفوظة لهذا المريض حتى الآن.</p>'}</div></div><p class="wf-muted">البيانات هنا نموذج تجريبي مشترك على نفس المتصفح فقط. مشاركة الملفات الطبية بين أجهزة وحسابات مختلفة تتطلب Backend آمنًا وتحقق صلاحيات.</p>`);
  }
  function addAppointment() {
    dialog('إضافة موعد جديد',`<form id="wf-add-appointment"><div class="wf-field"><label>اسم المريض</label><input name="name" required></div><div class="wf-field"><label>رقم الهاتف (اختياري)</label><input name="phone" inputmode="tel"></div><div class="wf-field"><label>تاريخ ووقت الموعد</label><input name="time" type="datetime-local" required></div><div class="wf-field"><label>نوع الزيارة</label><select name="type"><option>كشف جديد</option><option>متابعة</option></select></div><div class="wf-dialog-foot"><button class="wf-btn">حفظ الموعد</button></div></form>`,(root,close)=>$('#wf-add-appointment',root).onsubmit=e=>{e.preventDefault();const fd=new FormData(e.currentTarget),date=new Date(fd.get('time'));if(Number.isNaN(date.getTime()))return;const rows=read('doctorAppointments',demoAppointments);rows.push({id:'A-'+Date.now(),name:fd.get('name').trim(),phone:fd.get('phone'),time:new Intl.DateTimeFormat(dateLocale(),{dateStyle:'medium',timeStyle:'short'}).format(date),type:fd.get('type'),status:'بانتظار التأكيد'});save('doctorAppointments',rows);close();renderDoctor('appointments');toast('تمت إضافة الموعد محليًا.');});
  }
  function bindGlobalActions() {
    document.addEventListener('keydown',e=>{const help=e.target.closest('.help-card');if(help&&(e.key==='Enter'||e.key===' ')){e.preventDefault();supportDialog();}});
    window.addEventListener('storage',e=>{if(!e.key)return;const role=currentRole();if(role==='admin'&&e.key==='shifaa_supportMessages'&&window.__shifaaAdminTab==='messages')renderAdmin('messages');if(role==='doctor'&&['shifaa_demo_bookings','shifaa_patientMedicalRecord','shifaa_patientMedicalRecords','shifaa_prescriptions'].includes(e.key)){if(window.__shifaaDoctorTab)renderDoctor(window.__shifaaDoctorTab);if(e.key==='shifaa_demo_bookings'){const latest=readBookings()[0];const doctor=currentDoctorIdentity();if(latest&&((doctor.id&&bookingDoctorId(latest)===doctor.id)||(doctor.name&&String(latest.DoctorName||'').toLowerCase()===doctor.name.toLowerCase())))toast('وصل طلب حجز جديد إلى حسابك. افتح جدول المواعيد لمراجعته.');}}if(role==='admin'&&['shifaa_demo_bookings','shifaa_patientMedicalRecord','shifaa_patientMedicalRecords','shifaa_prescriptions','shifaa_activityLog'].includes(e.key)&&window.__shifaaAdminTab)renderAdmin(window.__shifaaAdminTab);});
    document.addEventListener('click',e=>{
      const navbarHelp=e.target.closest('.navbar-link');
      if(navbarHelp && /المساعدة|help/i.test(navbarHelp.textContent||'')){e.preventDefault();supportDialog('شريط التنقل');return;}
      const help=e.target.closest('.help-card');if(help){e.preventDefault();e.stopPropagation();supportDialog('القائمة الجانبية');return;}
      const nav=e.target.closest('[data-wf-tab]');
      if(nav){
        const role=currentRole(),label=(nav.textContent||'').trim();let tab=nav.dataset.wfTab;
        if(!tab && role==='patient'){if(label.includes('ملفي الطبي'))tab='medical';else if(label.includes('الإعدادات'))tab='settings';}
        if(tab){e.preventDefault();if(role==='doctor')renderDoctor(tab);else if(role==='admin')renderAdmin(tab);else renderPatient(tab);return;}
      }
      const adminGo=e.target.closest('[data-admin-go]');if(adminGo&&currentRole()==='admin'){e.preventDefault();renderAdmin(adminGo.dataset.adminGo);return;}
      const b=e.target.closest('[data-action]');if(!b)return;const action=b.dataset.action,id=b.dataset.id;
      if(action==='edit-medical') {const p=read('patientMedical',{blood:'غير محددة',allergies:'لم يتم تسجيلها',conditions:'لا توجد بيانات مضافة',emergency:'لم يحدد'});dialog('تحديث البيانات الطبية',`<form id="wf-medical-form"><div class="wf-field"><label>فصيلة الدم</label><select name="blood"><option ${p.blood==='غير محددة'?'selected':''}>غير محددة</option>${['A+','A-','B+','B-','AB+','AB-','O+','O-'].map(x=>`<option ${p.blood===x?'selected':''}>${x}</option>`).join('')}</select></div><div class="wf-field"><label>الحساسية</label><textarea name="allergies">${esc(p.allergies)}</textarea></div><div class="wf-field"><label>التاريخ المرضي</label><textarea name="conditions">${esc(p.conditions)}</textarea></div><div class="wf-field"><label>جهة اتصال للطوارئ</label><input name="emergency" value="${esc(p.emergency)}"></div><div class="wf-dialog-foot"><button class="wf-btn">حفظ البيانات</button></div></form>`,(root,close)=>$('#wf-medical-form',root).onsubmit=ev=>{ev.preventDefault();save('patientMedical',Object.fromEntries(new FormData(ev.currentTarget)));close();renderPatient('medical');toast('تم تحديث البيانات الطبية محليًا.');}); }
      if(action==='add-appointment')addAppointment();
      if(action==='pharmacy-contact'){dialog('التواصل مع الصيدلية',`<p>رقم الهاتف غير متاح في بيانات الصيدلية التجريبية، لذلك لم نضع رقمًا غير موثّق. يمكنك إرسال الروشتة من نموذج طلب الأدوية وسيتم التواصل بعد ربط النظام بالخادم.</p>`);return;}
      if(action==='admin-record'){dialog('تفاصيل السجل',`<div class="wf-hero"><div><h2>${esc(b.dataset.name||'السجل')}</h2><p>تم فتح تفاصيل السجل المحدد.</p></div></div><p class="wf-muted">هذه بيانات عرض تجريبية. مصدر البيانات الإداري الكامل يحتاج Backend وقاعدة بيانات موحدة.</p>`);return;}
      if(action==='confirm-appointment'||action==='cancel-appointment') {
        const bookingRows=readBookings(),booking=bookingRows.find(x=>x.id===id);
        if(booking){
          if(booking.doctorStatus!=='بانتظار المراجعة'){toast('تم التعامل مع طلب الحجز بالفعل.');return;}
          const approved=action==='confirm-appointment';
          booking.doctorStatus=approved?'تمت الموافقة':'مرفوض';
          booking.status=approved?'بانتظار الدفع':'مرفوض';
          booking.slotStatus=approved?'بانتظار الدفع':'متاح';
          booking.reviewedAt=new Date().toISOString();
          localStorage.setItem('shifaa_demo_bookings',JSON.stringify(bookingRows));
          const activity=read('activityLog',[]);
          activity.unshift({id:'ACT-'+Date.now(),type:approved?'appointment-approved':'appointment-rejected',patientId:bookingPatientId(booking),patientName:booking.PatientName,doctorName:booking.DoctorName,appointmentId:id,description:approved?'الطبيب وافق على الموعد، وينتظر دفع المريض':'الطبيب رفض طلب الحجز وتم تحرير الموعد',createdAt:booking.reviewedAt});
          save('activityLog',activity);
        }
        const rows=read('doctorAppointments',[]),row=rows.find(x=>x.id===id);
        if(row){row.status=action==='confirm-appointment'?'بانتظار الدفع':'مرفوض';save('doctorAppointments',rows);}
        renderDoctor('appointments');
        toast(action==='confirm-appointment'?'تمت الموافقة على الموعد. أصبح الدفع متاحًا للمريض.':'تم رفض الطلب وتحرير الموعد للحجز.');
      }
      if(action==='patient-file')doctorPatientFile(b.dataset.name||'المريض');
      if(action==='start-exam'){const row=linkedDoctorAppointments().find(x=>x.id===id);const sourceBooking=readBookings().find(x=>x.id===id);if(sourceBooking&&(sourceBooking.paymentStatus!=='Paid'||sourceBooking.IsConfirmed!==true)){toast('لا يمكن بدء الاستشارة قبل تأكيد الدفع.');return;}dialog('بدء الكشف',`<div class="wf-hero"><div><h2>${esc(row?.name||'المريض')}</h2><p>تم فتح مساحة الكشف التجريبية. لا يتم حفظ بيانات طبية فعلية.</p></div></div><div class="wf-field"><label>ملاحظات الزيارة</label><textarea id="wf-exam-notes" placeholder="ملاحظات الطبيب... "></textarea></div><div class="wf-dialog-foot"><button class="wf-btn" data-save-exam>حفظ ملاحظات تجريبية</button></div>`,(root,close)=>$('[data-save-exam]',root).onclick=()=>{const exams=read('examNotes',[]);exams.unshift({patient:row?.name||'المريض',notes:$('#wf-exam-notes',root).value,date:new Date().toISOString()});save('examNotes',exams);const activity=read('activityLog',[]);activity.unshift({id:'ACT-'+Date.now(),type:'doctor-visit-note',patientName:row?.name||'المريض',appointmentId:id,doctorName:currentUser().name,description:'الطبيب حفظ ملاحظة زيارة',createdAt:new Date().toISOString()});save('activityLog',activity);close();toast('تم حفظ الملاحظة في النموذج المحلي.');});}
      if(action==='new-prescription')dialog('إنشاء وصفة طبية',`<form id="wf-rx-form"><div class="wf-field"><label>اسم المريض</label><input name="patient" required></div><div class="wf-field"><label>تفاصيل الوصفة وتعليمات الاستخدام</label><textarea name="details" required minlength="3"></textarea></div><div class="wf-dialog-foot"><button class="wf-btn">حفظ الوصفة</button></div></form>`,(root,close)=>$('#wf-rx-form',root).onsubmit=ev=>{ev.preventDefault();const fd=new FormData(ev.currentTarget),list=read('prescriptions',[]),patientName=String(fd.get('patient')||'').trim(),linkedBooking=readBookings().find(x=>String(x.PatientName||x.patientName||'').trim().toLowerCase()===patientName.toLowerCase());const rx={id:'RX-'+Date.now(),patient:patientName,patientId:linkedBooking?bookingPatientId(linkedBooking):'',doctorId:currentUser().id||currentUser().email||'',doctorName:currentUser().name||'الطبيب',appointmentId:linkedBooking?.id||null,details:fd.get('details'),date:new Date().toLocaleDateString(dateLocale()),createdAt:new Date().toISOString(),status:'تم إصدارها'};list.unshift(rx);save('prescriptions',list);const activity=read('activityLog',[]);activity.unshift({id:'ACT-'+Date.now(),type:'prescription-issued',patientId:rx.patientId,patientName,doctorName:rx.doctorName,description:'تم إصدار وصفة طبية',createdAt:rx.createdAt});save('activityLog',activity);close();renderDoctor('prescriptions');toast('تم حفظ الوصفة محليًا.');});
      if(action==='reply-message'||action==='message-review'||action==='message-close') {const messages=read('supportMessages',[]),m=messages.find(x=>x.id===id);if(!m)return;if(action==='message-review'){m.status='قيد المراجعة';save('supportMessages',messages);renderAdmin('messages');toast('تم تحديث حالة الرسالة.');}else if(action==='message-close'){m.status='مغلقة';save('supportMessages',messages);renderAdmin('messages');toast('تم إغلاق الرسالة.');}else dialog('الرد على رسالة الدعم',`<div class="wf-message"><strong>${esc(m.subject)}</strong><p class="wf-muted">${esc(m.from)} · ${esc(m.source||'')}</p><div class="wf-message-body">${esc(m.message)}</div></div><form id="wf-reply-form"><div class="wf-field"><label>رد فريق شفاء</label><textarea name="reply" required>${esc(m.reply||'')}</textarea></div><div class="wf-dialog-foot"><button class="wf-btn">إرسال الرد وحفظه</button></div></form>`,(root,close)=>$('#wf-reply-form',root).onsubmit=ev=>{ev.preventDefault();m.reply=new FormData(ev.currentTarget).get('reply').trim();m.status='تم الرد';m.repliedAt=new Date().toISOString();save('supportMessages',messages);close();renderAdmin('messages');toast('تم حفظ رد فريق شفاء في سجل الرسالة.');});}
      if(action==='payment-details'&&currentRole()==='admin'){const row=read('demoPayments',[]).find(x=>x.id===id);dialog('تفاصيل معاملة الدفع',`<div class="wf-list"><div class="wf-list-item"><span>رقم العملية</span><strong>${esc(row?.id||id)}</strong></div><div class="wf-list-item"><span>مزود الدفع</span><strong>${esc(row?.provider||'Paymob')}</strong></div><div class="wf-list-item"><span>الحالة</span><strong>${esc(row?.status||'غير متاحة')}</strong></div></div><p class="wf-muted">هذه بيانات عرض تجريبية. تفاصيل المعاملة الحقيقية تُجلب من الخادم بعد التحقق من صلاحيات الأدمن.</p>`);return;}
      if(action==='payment-refund-request'&&currentRole()==='admin'){const rows=read('demoPayments',[]),row=rows.find(x=>x.id===id);if(row){row.refundReviewStatus='طلب مراجعة الاسترداد مسجل تجريبيًا';save('demoPayments',rows);}dialog('طلب مراجعة استرداد',`<p>تم تسجيل طلب مراجعة استرداد تجريبي للمعاملة ${esc(id)} على هذا المتصفح فقط. لم يتم تنفيذ استرداد مالي.</p><p class="wf-muted">تنفيذ الاسترداد يتطلب موافقة وإجراءً ماليًا عبر Backend وPaymob.</p>`);return;}
      if(action==='export-report'){const kind=b.dataset.report||'support';const rows=kind==='appointments'?read('doctorAppointments',demoAppointments):read('supportMessages',[]);const header=kind==='appointments'?['id','name','time','type','status','phone']:['id','from','role','source','kind','subject','message','status','reply'];const csv=[header.join(','),...rows.map(r=>header.map(k=>'"'+String(r[k]??'').replaceAll('"','""')+'"').join(','))].join('\n');const url=URL.createObjectURL(new Blob(['\ufeff'+csv],{type:'text/csv;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download=kind==='appointments'?'shifaa-appointments-report.csv':'shifaa-support-messages.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
      if(action==='admin-moderate'&&currentRole()==='admin'){openModerationDialog(b.dataset.kind,b.dataset.name,b.dataset.city,b.dataset.roleLabel);return;}
      if(action==='admin-record')dialog('تفاصيل السجل',`<div class="wf-hero"><div><h2>${esc(b.dataset.name)}</h2><p>هذا سجل توضيحي في واجهة العرض الحالية.</p></div></div><p class="wf-muted">تعديل واعتماد البيانات يتطلب ربط الواجهة بقاعدة بيانات وخدمات صلاحيات.</p>`);
    });
  }
  function showRegistrationSuccess(form, success) { form.hidden = true; form.insertAdjacentElement('afterend', success); }
  function setupRegistration() {
    const form=$('.auth-form'); if(!form || !location.pathname.endsWith('register.html')) return;
    let role=$('#AccountRole',form);
    let wrap=role?.closest('.form-group');
    if(!role){
      wrap=document.createElement('div'); wrap.className='form-group account-role-group';
      wrap.innerHTML='<label class="form-label" for="AccountRole">نوع الحساب</label><select class="form-input" id="AccountRole" name="AccountRole"><option value="patient">مريض</option><option value="doctor">طبيب</option><option value="admin">مسؤول الإدارة (أدمن)</option></select>';
      form.insertBefore(wrap,form.firstElementChild);
      role=$('#AccountRole',wrap);
    }
    let roleCardGrid=$('.wf-role-choice-grid',form);
    if(!roleCardGrid){
      roleCardGrid=document.createElement('div');roleCardGrid.className='wf-role-choice-grid';roleCardGrid.setAttribute('role','group');roleCardGrid.setAttribute('aria-label','اختيار نوع الحساب');
      roleCardGrid.innerHTML='<button class="wf-role-choice" type="button" data-account-role="patient" aria-pressed="false"><span class="wf-role-choice-icon" aria-hidden="true">👤</span><strong>مريض</strong><small>حجز ومتابعة الرعاية الصحية</small></button><button class="wf-role-choice" type="button" data-account-role="doctor" aria-pressed="false"><span class="wf-role-choice-icon" aria-hidden="true">🩺</span><strong>طبيب</strong><small>طلب انضمام وبيانات مهنية</small></button><button class="wf-role-choice" type="button" data-account-role="admin" aria-pressed="false"><span class="wf-role-choice-icon" aria-hidden="true">🛡️</span><strong>مسؤول الإدارة</strong><small>بدعوة معتمدة فقط</small></button>';
      wrap.append(roleCardGrid);
    }
    role.classList.add('wf-role-native-select');
    let info=$('.wf-registration-note',form);
    if(!info){info=document.createElement('div');info.className='wf-registration-note';wrap.after(info);}
    let adminRegistrationToken=null;
    let adminTokenExpiresAt=null;

    function clearAdminVerification(){
      adminRegistrationToken=null;adminTokenExpiresAt=null;
      const status=$('#wf-admin-invite-status',form);
      if(status){status.textContent='لم يتم التحقق من رابط الدعوة بعد.';status.className='wf-invite-status';}
      const submit=form.querySelector('button[type="submit"]');
      if(submit)submit.disabled=false;
    }
    function createAdminInviteFields(){
      const group=document.createElement('section');
      group.className='wf-admin-invitation';group.dataset.wfRoleField='1';
      group.innerHTML=`
        <div class="wf-admin-invitation-heading"><strong>دعوة إنشاء حساب مسؤول</strong><span>أدخل رابط الدعوة الرسمي الذي استلمته من مدير النظام.</span></div>
        <div class="wf-admin-invitation-row">
          <div class="form-group wf-admin-url-field"><label class="form-label" for="AdminInvitationUrl">رابط الدعوة</label><input class="form-input" id="AdminInvitationUrl" name="AdminInvitationUrl" type="url" inputmode="url" autocomplete="off" placeholder="https://example.com/admin-invite/…" required></div>
          <button class="btn btn-primary wf-verify-invite" id="VerifyAdminInvitation" type="button">التحقق من الدعوة</button>
        </div>
        <p id="wf-admin-invite-status" class="wf-invite-status" role="status" aria-live="polite">لن تتمكن من إنشاء الحساب قبل التحقق من الدعوة على الخادم.</p>
      `;
      wrap.after(group);
      const inviteInput=$('#AdminInvitationUrl',group), verifyButton=$('#VerifyAdminInvitation',group), status=$('#wf-admin-invite-status',group);
      inviteInput.addEventListener('input',clearAdminVerification);
      verifyButton.addEventListener('click',async()=>{
        const inviteUrl=inviteInput.value.trim();
        clearAdminVerification();
        if(!inviteUrl || !inviteInput.checkValidity()){
          inviteInput.reportValidity();status.textContent='أدخل رابط دعوة صحيحًا أولًا.';status.classList.add('error');return;
        }
        verifyButton.disabled=true;verifyButton.textContent='جارٍ التحقق…';status.textContent='يتم التحقق من صلاحية الدعوة…';status.className='wf-invite-status';
        try{
          const response=await fetch('/api/admin-invitations/validate',{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'},credentials:'same-origin',body:JSON.stringify({invitationUrl:inviteUrl})});
          const result=await response.json().catch(()=>({}));
          if(!response.ok || result.valid!==true || !result.registrationToken){
            status.textContent=result.message||'رابط الدعوة غير صالح أو منتهي الصلاحية أو تم استخدامه.';status.className='wf-invite-status error';return;
          }
          adminRegistrationToken=result.registrationToken;
          adminTokenExpiresAt=result.expiresAt||null;
          status.textContent='تم التحقق من الدعوة. يمكنك الآن إكمال بيانات الحساب وإرساله.'+(adminTokenExpiresAt?' تنتهي صلاحية التحقق: '+new Date(adminTokenExpiresAt).toLocaleString(dateLocale()):'' );
          status.className='wf-invite-status success';
        }catch(error){
          status.textContent='تعذّر الاتصال بخدمة التحقق. تأكد من تشغيل الخادم ثم حاول مرة أخرى.';status.className='wf-invite-status error';
        }finally{verifyButton.disabled=false;verifyButton.textContent='التحقق من الدعوة';}
      });
    }

    function update(){
      $$('[data-wf-role-field]',form).forEach(x=>x.remove());
      clearAdminVerification();
      const value=role.value;
      roleChoices.forEach(choice=>{const selected=choice.dataset.accountRole===value;choice.classList.toggle('is-selected',selected);choice.setAttribute('aria-pressed',String(selected));});
      const subtitle=$('.auth-subtitle');
      if(subtitle) subtitle.textContent=value==='patient'?'إنشاء حساب مريض':value==='doctor'?'طلب انضمام طبيب':'إنشاء حساب مسؤول الإدارة';
      const submitButton=form.querySelector('button[type="submit"]');
      if(submitButton) submitButton.textContent=value==='admin'?'إنشاء حساب المسؤول':'إنشاء الحساب';
      info.textContent=value==='patient'?'إنشاء حساب مريض بالبيانات الأساسية. في النسخة الحالية يتم حفظ بيانات العرض محليًا على هذا المتصفح فقط.':value==='doctor'?'طلب انضمام طبيب مع بيانات مهنية لمراجعتها. الحفظ الحالي تجريبي ومحلي ولا يرسل الطلب إلى خادم.':'حسابات الإدارة تتطلب رابط دعوة صالحًا وتأكيدًا من الخادم قبل إنشاء الحساب.';
      if(value==='doctor'){
        const fields=[
          ['Specialty','التخصص الطبي','text','مثال: قلب وأوعية دموية',true],
          ['LicenseNumber','رقم الترخيص المهني','text','رقم الترخيص أو القيد بالنقابة',true],
          ['ExperienceYears','سنوات الخبرة','number','عدد سنوات الخبرة',true],
          ['ConsultationFee','سعر الكشف بالجنيه','number','مثال: 300',true],
          ['HospitalName','اسم المستشفى التي تعمل بها','text','اسم المستشفى (إن وجد)',false],
          ['ClinicName','اسم العيادة','text','اسم العيادة',true],
          ['ClinicAddress','عنوان العيادة بالتفصيل','text','المنطقة والشارع ورقم المبنى',true],
          ['Bio','نبذة تعريفية والمؤهلات الإضافية','textarea','اكتب نبذة مختصرة عن خبرتك ومؤهلاتك',false]
        ];
        const section=document.createElement('section');section.className='wf-doctor-registration-fields';section.dataset.wfRoleField='1';
        section.innerHTML='<div class="wf-doctor-registration-heading"><strong>البيانات المهنية للطبيب</strong><span>أكمل بياناتك حتى يظهر ملفك المهني بصورة واضحة للمرضى.</span></div><div class="wf-doctor-registration-grid">'+fields.map(([name,label,type,placeholder,required])=>`<div class="form-group ${name==='Bio'?'wf-doctor-field-wide':''}"><label class="form-label" for="${name}">${label}${required?' <span aria-hidden="true">*</span>':''}</label>${type==='textarea'?`<textarea class="form-input" id="${name}" name="${name}" rows="3" placeholder="${placeholder}" ${required?'required':''}></textarea>`:`<input class="form-input" id="${name}" name="${name}" type="${type}" ${type==='number'?(name==='ExperienceYears'?'min="0" max="70" step="1"':'min="0" step="1"'):''} placeholder="${placeholder}" ${required?'required':''}>`}</div>`).join('')+'</div>';
        wrap.after(section);
      }
      if(value==='admin') createAdminInviteFields();
    }
    const roleChoices=$$('[data-account-role]',form);
    roleChoices.forEach(choice=>choice.addEventListener('click',()=>{role.value=choice.dataset.accountRole;role.dispatchEvent(new Event('change',{bubbles:true}));}));
    role.addEventListener('change',update);update();
    form.addEventListener('submit',async e=>{
      const data=Object.fromEntries(new FormData(form));
      if(data.AccountRole==='admin'){
        e.preventDefault();
        if(!adminRegistrationToken){toast('تحقق من رابط الدعوة أولًا قبل إنشاء حساب المسؤول.');return;}
        if(adminTokenExpiresAt && Date.now()>=new Date(adminTokenExpiresAt).getTime()){
          clearAdminVerification();toast('انتهت صلاحية التحقق. أعد التحقق من رابط الدعوة.');return;
        }
        const submit=form.querySelector('button[type="submit"]');
        if(submit){submit.disabled=true;submit.textContent='جارٍ إنشاء الحساب…';}
        try{
          const response=await fetch('/api/auth/register-admin',{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'},credentials:'same-origin',body:JSON.stringify({registrationToken:adminRegistrationToken,fullName:data.FullName,email:data.Email,phoneNumber:data.PhoneNumber,password:data.Password,acceptTerms:data.AcceptTerms==='on'})});
          const result=await response.json().catch(()=>({}));
          if(!response.ok || result.created!==true){toast(result.message||'لم يتم إنشاء الحساب. تحقق من الدعوة والبيانات وحاول مرة أخرى.');return;}
          adminRegistrationToken=null;
          const success=document.createElement('div');success.className='wf-registration-result';success.setAttribute('role','status');success.textContent=result.message||'تم إنشاء حساب المسؤول بنجاح من الخادم. اتبع تعليمات تفعيل البريد الإلكتروني لإكمال الدخول.';
          showRegistrationSuccess(form, success);
        }catch(error){toast('تسجيل المسؤول يحتاج إلى تشغيل Backend؛ لم يتم إنشاء الحساب أو حفظ كلمة المرور محليًا.');}
        finally{if(submit&&submit.isConnected){submit.disabled=false;submit.textContent='إنشاء الحساب وإرسال رمز التحقق';}}
        return;
      }
      if(data.AccountRole==='doctor'){
        const missingDoctorData=[data.Specialty,data.LicenseNumber,data.ExperienceYears,data.ConsultationFee,data.ClinicName,data.ClinicAddress].some(value=>value===undefined||String(value).trim()==='');
        if(missingDoctorData){e.preventDefault();toast('أكمل جميع البيانات المهنية المطلوبة لإرسال طلب الانضمام.');return;}
        e.preventDefault();const safeDraft={...data};delete safeDraft.Password;save('registrationDraft',safeDraft);
        save('doctorSettings',{name:data.FullName,specialty:data.Specialty,licenseNumber:data.LicenseNumber,experienceYears:data.ExperienceYears,consultationFee:data.ConsultationFee,hospital:data.HospitalName||'',clinic:data.ClinicName,clinicAddress:data.ClinicAddress,phone:data.PhoneNumber,bio:data.Bio||''});
        save('currentUser',{name:data.FullName,email:data.Email,phone:data.PhoneNumber,role:'doctor',roleLabel:'طبيب'});
        const success=document.createElement('div');success.className='wf-registration-result';success.setAttribute('role','status');success.innerHTML='<strong>تم حفظ طلب الانضمام التجريبي.</strong><p>تم حفظ بيانات الطبيب في هذا المتصفح فقط. لم يتم إرسال الطلب إلى خادم أو اعتماده من الإدارة.</p><a class="btn btn-primary btn-block" href="doctor-dashboard.html">فتح لوحة الطبيب التجريبية</a><a class="link" href="index.html">العودة إلى الرئيسية</a>';
        showRegistrationSuccess(form, success);return;
      }
      e.preventDefault();const safeDraft={...data};delete safeDraft.Password;save('registrationDraft',safeDraft);save('currentUser',{name:data.FullName,email:data.Email,phone:data.PhoneNumber,role:'patient',roleLabel:'مريض'});
      const success=document.createElement('div');success.className='wf-registration-result';success.setAttribute('role','status');success.innerHTML='<strong>تم حفظ بيانات المريض التجريبية.</strong><p>البيانات محفوظة على هذا المتصفح فقط. إنشاء حساب حقيقي وتفعيل البريد يتطلبان Backend.</p><a class="btn btn-primary btn-block" href="patient-dashboard.html">فتح لوحة المريض التجريبية</a><a class="link" href="index.html">العودة إلى الرئيسية</a>';
      showRegistrationSuccess(form, success);
    });
  }
  function init() {
    setupRegistration();
    const role=currentRole();
    // Keep the original dashboard markup intact on initial load; workflows replace only the content area when a section is selected.
    if(role==='doctor') {
      const links=$$('.sidebar-nav .nav-item');links.forEach(a=>{const t=a.textContent.trim();const tab=t.includes('جدول')?'appointments':t.includes('مرضاي')?'patients':t.includes('محادثات')?'chats':t.includes('الوصفات')?'prescriptions':t.includes('أوقات')?'hours':null;if(tab)a.dataset.wfTab=tab;else a.removeAttribute('data-wf-tab');});
      const settings=$$('.sidebar-bottom .nav-item').find(a=>a.textContent.includes('الإعدادات')||a.textContent.includes('الملف الشخصي'));if(settings){settings.dataset.wfTab='settings';settings.href='#settings';}
      const main=$('.page-content');if(main)main.addEventListener('click',e=>{const a=e.target.closest('a[href="#"]');if(!a)return;const t=a.textContent.trim().toLowerCase();if(t.includes('إضافة موعد')||t.includes('add appointment')){e.preventDefault();addAppointment();}else if(t.includes('تعديل أوقات العمل')||t.includes('edit working hours')){e.preventDefault();renderDoctor('hours');}else if(t.includes('ابدأ الكشف')||t.includes('start exam')){e.preventDefault();const first=read('doctorAppointments',demoAppointments)[0];if(first){const b=document.createElement('button');b.dataset.action='start-exam';b.dataset.id=first.id;b.click();}}else if(t.includes('كل المواعيد')||t.includes('all appointments')){e.preventDefault();renderDoctor('appointments');}else if(t.includes('عرض الملف')||t.includes('view file')){e.preventDefault();doctorPatientFile(a.closest('tr')?.querySelector('td')?.textContent||'المريض');}});
    } else if(role==='admin') {
      const links=$$('.sidebar-nav .nav-item');
      links.forEach(a=>{const t=a.textContent.trim();const tab=t.includes('المدفوعات')?'payments':t.includes('طلبات الصيدليات')?'pharmacy-orders':t.includes('الأطباء')?'doctors':t.includes('المرضى')?'patients':t.includes('المواعيد')?'appointments':t.includes('الصيدليات')?'pharmacies':t.includes('التقارير')?'reports':t.includes('رسائل الدعم')?'messages':t.includes('المخالفات')?'moderation':null;if(tab){a.dataset.wfTab=tab;a.href='#'+tab;}else a.removeAttribute('data-wf-tab');});
      const settings=$$('.sidebar-bottom .nav-item').find(a=>a.textContent.includes('الإعدادات'));if(settings){settings.dataset.wfTab='settings';settings.href='#settings';}
      const nav=$('.sidebar-nav');if(nav){const messageLinks=$$('.nav-item',nav).filter(a=>a.textContent.includes('رسائل الدعم'));messageLinks.slice(1).forEach(a=>a.remove());if(!messageLinks.length){const link=document.createElement('a');link.className='nav-item';link.href='#messages';link.dataset.wfTab='messages';link.innerHTML='<i data-lucide="inbox"></i><span>رسائل الدعم</span>';nav.append(link);}}
      $$('.help-card').forEach(x=>x.remove());
    } else {
      const medical=$$('.sidebar-nav .nav-item').find(a=>a.textContent.includes('ملفي الطبي'));if(medical){medical.dataset.wfTab='medical';medical.href='#medical';}
      const settings=$$('.sidebar-bottom .nav-item').find(a=>a.textContent.includes('الإعدادات'));if(settings){settings.dataset.wfTab='settings';settings.href='#settings';}
    }
    bindGlobalActions();refreshIcons();
    if(role==='patient' && location.hash==='#medical') renderPatient('medical');
    if(role==='patient' && location.hash==='#settings') renderPatient('settings');
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',init,{once:true}); else init();
})();
