(() => {
  'use strict';
  const root = document.getElementById('doctor-profile-content');
  if (!root) return;
  const params = new URLSearchParams(location.search);
  const id = String(params.get('id') || '');
  const demo = {
    '1': {id:'1',name:'د. محمد حسن',specialty:'استشاري القلب والأوعية الدموية',location:'الدقي، الجيزة · شارع التحرير',rating:'4.9',reviews:'128',fee:'450',availability:'متاح اليوم · ٦:٠٠ م',image:'images/doctor-mohamed-hassan.jpg',bio:'استشاري القلب والأوعية الدموية. يمكنك مراجعة بيانات الطبيب وحجز استشارة أونلاين من خلال شفاء.',experience:'غير محددة في البيانات المعروضة',hospital:'غير محدد في البيانات المعروضة',clinic:'غير محددة في البيانات المعروضة'},
    '2': {id:'2',name:'د. منى إبراهيم',specialty:'استشارية القلب والباطنة',location:'مدينة نصر، القاهرة · مكرم عبيد',rating:'4.8',reviews:'91',fee:'500',availability:'متاح غدًا · ١٢:٣٠ م',image:'images/doctor-mona-ibrahim.jpg',bio:'استشارية القلب والباطنة. يمكنك مراجعة بيانات الطبيبة وحجز استشارة أونلاين من خلال شفاء.',experience:'غير محددة في البيانات المعروضة',hospital:'غير محدد في البيانات المعروضة',clinic:'غير محددة في البيانات المعروضة'},
    '3': {id:'3',name:'د. عمر عادل',specialty:'أخصائي القلب والأوعية الدموية',location:'المهندسين، الجيزة · جامعة الدول',rating:'4.7',reviews:'84',fee:'350',availability:'متاح اليوم · ٨:٠٠ م',image:'images/doctor-omar-adel.jpg',bio:'أخصائي القلب والأوعية الدموية. يمكنك مراجعة بيانات الطبيب وحجز استشارة أونلاين من خلال شفاء.',experience:'غير محددة في البيانات المعروضة',hospital:'غير محدد في البيانات المعروضة',clinic:'غير محددة في البيانات المعروضة'}
  };
  const escapeHTML = value => String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  const read = key => { try { return JSON.parse(localStorage.getItem(key) || 'null'); } catch { return null; } };
  const lang = () => (localStorage.getItem('shifaa-language') || localStorage.getItem('shifaa-auth-language') || 'ar') === 'en';
  const english = lang();
  let doctor = demo[id];
  // If this profile belongs to the currently signed-in demo doctor, show saved professional details.
  const currentUser = read('shifaa_currentUser') || read('shifaa_current_user') || {};
  const saved = read('shifaa_doctorSettings');
  if (doctor && saved && (String(saved.id || '') === id || (currentUser.role === 'doctor' && String(currentUser.doctorId || currentUser.id || '') === id))) {
    doctor = {...doctor, name:saved.name || doctor.name, specialty:saved.specialty || doctor.specialty, fee:saved.consultationFee || doctor.fee, bio:saved.bio || doctor.bio, experience:saved.experienceYears ? `${saved.experienceYears} سنوات` : doctor.experience, hospital:saved.hospital || doctor.hospital, clinic:saved.clinicAddress || saved.clinic || doctor.clinic};
  }
  if (!doctor) {
    root.innerHTML = `<section class="card doctor-profile-loading"><h2>${english?'Doctor profile not found':'لم يتم العثور على ملف الطبيب'}</h2><p>${english?'Please return to the doctor list and choose a doctor.':'ارجع إلى قائمة الأطباء واختر الطبيب الذي تريد عرض ملفه.'}</p><a class="btn btn-primary" href="find-doctor.html">${english?'Back to doctors':'العودة إلى الأطباء'}</a></section>`;
    return;
  }
  const text = (ar,en) => english ? en : ar;
  root.innerHTML = `
    <section class="card doctor-profile-card">
      <img class="doctor-profile-photo" src="${escapeHTML(doctor.image)}" alt="${escapeHTML(doctor.name)}" onerror="this.hidden=true"/>
      <div class="doctor-profile-main">
        <span class="badge badge-success">${escapeHTML(doctor.availability)}</span>
        <h2>${escapeHTML(doctor.name)}</h2><p class="doctor-profile-specialty">${escapeHTML(doctor.specialty)}</p>
        <div class="doctor-profile-meta"><span>★ ${escapeHTML(doctor.rating)} (${escapeHTML(doctor.reviews)} ${text('تقييمًا','reviews')})</span><span><i data-lucide="map-pin"></i>${escapeHTML(doctor.location)}</span></div>
        <div class="doctor-profile-stats"><div class="doctor-profile-stat"><small>${text('سعر الاستشارة','Consultation fee')}</small><strong>${escapeHTML(doctor.fee)} ${text('ج.م','EGP')}</strong></div><div class="doctor-profile-stat"><small>${text('سنوات الخبرة','Experience')}</small><strong>${escapeHTML(doctor.experience)}</strong></div><div class="doctor-profile-stat"><small>${text('التخصص','Specialty')}</small><strong>${escapeHTML(doctor.specialty)}</strong></div></div>
        <div class="doctor-profile-actions"><a class="btn btn-primary" href="book-appointment.html?doctor=${encodeURIComponent(doctor.id)}">${text('احجز استشارة أونلاين','Book online consultation')}</a><a class="btn btn-soft" href="find-doctor.html">${text('العودة للأطباء','Back to doctors')}</a></div>
      </div>
    </section>
    <div class="doctor-profile-sections">
      <section class="card doctor-profile-section"><h3>${text('نبذة عن الطبيب','About the doctor')}</h3><p>${escapeHTML(doctor.bio)}</p></section>
      <section class="card doctor-profile-section"><h3>${text('البيانات المهنية','Professional information')}</h3><p>${text('المستشفى: ','Hospital: ')}${escapeHTML(doctor.hospital)}<br/>${text('العيادة / العنوان: ','Clinic / address: ')}${escapeHTML(doctor.clinic)}</p></section>
    </div>
    <p class="doctor-profile-note">${text('ملاحظة: الملف يعرض المعلومات المتاحة حاليًا في بيانات المشروع التجريبية. أي بيانات مهنية غير مسجلة موضحة بأنها غير محددة، ولن نعرض معلومات غير مؤكدة.','Note: This profile displays information currently available in the demo project. Missing professional details are marked as unspecified rather than inferred.')}</p>`;
  if (window.lucide?.createIcons) window.lucide.createIcons();
  const toggle = document.getElementById('language-toggle');
  if (toggle) toggle.addEventListener('click', () => { setTimeout(() => location.reload(), 0); });
})();
