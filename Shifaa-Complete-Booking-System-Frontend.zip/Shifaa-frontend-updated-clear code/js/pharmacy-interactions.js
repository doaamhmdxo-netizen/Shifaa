document.addEventListener("DOMContentLoaded",()=>{
 const isEnglish=()=>document.documentElement.lang==='en';
 const msg=(ar,en)=>isEnglish()?en:ar;
 const area=document.getElementById("Area");if(!area)return;
 const form=area.closest("form");if(!form)return;
 function showLocationStatus(message) {
  let status=document.getElementById('pharmacy-location-status');
  if(!status){status=document.createElement('p');status.id='pharmacy-location-status';status.className='filter-count';status.setAttribute('role','status');status.setAttribute('aria-live','polite');form.appendChild(status);}
  status.textContent=message;
 }
 const locate=[...form.querySelectorAll("button")].find(b=>b.id==="UseMyLocation"||b.textContent.includes("موقعي")||b.textContent.toLowerCase().includes("my location"));
 if(locate) { locate.id="UseMyLocation"; locate.addEventListener("click",()=>{
  if(!navigator.geolocation){showLocationStatus(msg("المتصفح لا يدعم تحديد الموقع.","Your browser does not support geolocation."));return;}
  locate.disabled=true;locate.textContent=msg("جارٍ تحديد الموقع…","Finding your location…");
  navigator.geolocation.getCurrentPosition(pos=>{
   const {latitude,longitude}=pos.coords;locate.disabled=false;locate.textContent=msg("تم تحديد موقعي","My location detected");
   let a=document.getElementById("user-map-link");if(!a){a=document.createElement("a");a.id="user-map-link";a.className="text-link";a.target="_blank";a.rel="noopener";locate.insertAdjacentElement("afterend",a);}
   a.href=`https://www.google.com/maps/search/?api=1&query=${latitude},${longitude}`;a.textContent=msg("عرض موقعي على الخريطة","View my location on the map");
  },()=>{locate.disabled=false;locate.textContent=msg("استخدم موقعي","Use my location");showLocationStatus(msg("تعذر تحديد الموقع. اسمح بالوصول للموقع أو اختر المنطقة يدويًا.","Could not determine your location. Allow location access or choose an area manually."));},{timeout:10000});
 }); }
 const chips=["OpenNow","Open24Hours","UnderOneKm"].map(id=>document.getElementById(id)).filter(Boolean);
 chips.forEach(c=>c.addEventListener("change",()=>{let n=document.getElementById("pharmacy-demo-note");if(!n){n=document.createElement("p");n.id="pharmacy-demo-note";n.className="filter-count";form.appendChild(n);}n.textContent=msg("تم تحديث الفلاتر. بيانات الصيدليات في هذه النسخة تجريبية وليست متصلة بتوافر لحظي.","Filters updated. Pharmacy data in this version is demo data and is not connected to live availability."); }));
 const orderForm=document.getElementById('pharmacy-prescription-form');
 if(orderForm){
  const fileInput=document.getElementById('PrescriptionFile');
  const status=document.getElementById('pharmacy-order-status');
  orderForm.addEventListener('submit',event=>{
   event.preventDefault();
   if(!orderForm.reportValidity())return;
   const file=fileInput?.files?.[0];
   if(!file)return;
   const allowed=/\.(png|jpe?g|webp|pdf)$/i.test(file.name);
   if(!allowed){status.textContent=msg('من فضلك اختار صورة أو ملف PDF.','Please choose an image or PDF file.');return;}
   if(file.size>5*1024*1024){status.textContent=msg('حجم الملف يجب ألا يتجاوز ٥ ميجابايت.','The file must not exceed 5 MB.');return;}
   const data=new FormData(orderForm);
   const orders=(()=>{try{return JSON.parse(localStorage.getItem('shifaa_pharmacyOrders')||'[]')}catch(_){return []}})();
   // Store only non-sensitive demo metadata. Do not persist prescription names,
   // delivery address, phone number, or medical notes in browser storage.
   const order={id:'PH-'+Date.now(),pharmacyName:data.get('pharmacyName'),prescriptionFileName:'مرفق تجريبي - لم يتم رفعه',deliveryAddress:'يُدخل بأمان بعد ربط الخادم',patientName:'مريض تجريبي',createdAt:new Date().toISOString(),status:'بانتظار مراجعة الصيدلية',paymentStatus:'لم يتم الدفع',paymentProvider:'Paymob'};
   orders.unshift(order);
   try{localStorage.setItem('shifaa_pharmacyOrders',JSON.stringify(orders));}
   catch(_){status.textContent=msg('تعذر حفظ الطلب التجريبي. مساحة التخزين غير كافية.','Could not save the demo request. Browser storage is full.');return;}
   status.textContent=msg(`تم تسجيل طلب تجريبي رقم ${order.id}. لم يتم رفع ملف الروشتة أو إرسال الطلب للصيدلية فعليًا.`,`Demo request ${order.id} was saved. The prescription file was not uploaded and the pharmacy was not actually notified.`);
   orderForm.reset();
  });
 }
});
