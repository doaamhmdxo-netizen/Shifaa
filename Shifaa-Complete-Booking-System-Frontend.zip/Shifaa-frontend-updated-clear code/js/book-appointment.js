document.addEventListener('DOMContentLoaded', () => {
  const form = document.querySelector('.booking-layout');
  if (!form) return;

  const profiles = {
    '1': { name:'د. محمد حسن', specialty:'استشاري القلب والأوعية', photo:'images/doctor-mohamed-hassan.jpg', location:'استشارة أونلاين عبر شِفاء', fee:450 },
    '2': { name:'د. منى إبراهيم', specialty:'استشارية القلب والباطنة', photo:'images/doctor-mona-ibrahim.jpg', location:'استشارة أونلاين عبر شِفاء', fee:500 },
    '3': { name:'د. عمر عادل', specialty:'أخصائي القلب والأوعية الدموية', photo:'images/doctor-omar-adel.jpg', location:'استشارة أونلاين عبر شِفاء', fee:350 }
  };

  const selectedDoctorId = new URLSearchParams(location.search).get('doctor') || '1';
  const doctor = profiles[selectedDoctorId] || profiles['1'];
  const signedInUser = (() => { try { return JSON.parse(localStorage.getItem('shifaa_currentUser') || localStorage.getItem('currentUser') || '{}'); } catch { return {}; } })();
  const savedPatientSettings = (() => { try { return JSON.parse(localStorage.getItem('shifaa_patientSettings') || '{}'); } catch { return {}; } })();
  const patientNameInput = form.querySelector('[name="PatientName"]');
  const patientPhoneInput = form.querySelector('[name="PhoneNumber"]');
  const selfBooking = form.querySelector('[name="BookingFor"][value="Self"]');
  if (selfBooking?.checked) {
    if (patientNameInput && (signedInUser.name || signedInUser.FullName)) patientNameInput.value = signedInUser.name || signedInUser.FullName;
    if (patientPhoneInput && (signedInUser.phone || signedInUser.PhoneNumber || savedPatientSettings.phone)) patientPhoneInput.value = signedInUser.phone || signedInUser.PhoneNumber || savedPatientSettings.phone;
  }
  form.querySelectorAll('[name="BookingFor"]').forEach(choice => choice.addEventListener('change', () => {
    if (choice.value === 'Self' && choice.checked) {
      if (patientNameInput && (signedInUser.name || signedInUser.FullName)) patientNameInput.value = signedInUser.name || signedInUser.FullName;
      if (patientPhoneInput && (signedInUser.phone || signedInUser.PhoneNumber || savedPatientSettings.phone)) patientPhoneInput.value = signedInUser.phone || signedInUser.PhoneNumber || savedPatientSettings.phone;
    }
  }));
  const doctorIdField = form.querySelector('[name="DoctorId"]');
  if (doctorIdField) doctorIdField.value = selectedDoctorId;

  // Build upcoming dates and slots from the doctor's saved working hours.
  const dayGrid = form.querySelector('.day-grid');
  const timeGrid = form.querySelector('.time-grid');
  const savedHours = (() => { try { return JSON.parse(localStorage.getItem('shifaa_doctorHours') || 'null') || { days:['السبت','الأحد','الثلاثاء','الخميس'], from:'16:00', to:'21:00', break:'18:00' }; } catch { return { days:['السبت','الأحد','الثلاثاء','الخميس'], from:'16:00', to:'21:00', break:'18:00' }; } })();
  const arabicDays = ['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];
  const toMinutes = value => { const [h,m]=String(value||'').split(':').map(Number); return h*60+m; };
  const toClock = mins => `${String(Math.floor(mins/60)).padStart(2,'0')}:${String(mins%60).padStart(2,'0')}`;
  const occupiedSlots = (() => { try { return JSON.parse(localStorage.getItem('shifaa_demo_bookings') || '[]'); } catch { return []; } })();
  const availableDates = [];
  if (dayGrid) {
    for (let offset=1; offset<=14 && availableDates.length<7; offset++) {
      const date = new Date(); date.setHours(0,0,0,0); date.setDate(date.getDate()+offset);
      const dayName = arabicDays[date.getDay()];
      if (!Array.isArray(savedHours.days) || !savedHours.days.includes(dayName)) continue;
      availableDates.push(date);
    }
    dayGrid.innerHTML = availableDates.map((date,index) => {
      const value = `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`;
      const label = date.toLocaleDateString('ar-EG',{weekday:'long',day:'numeric',month:'long'});
      const id = `ShifaaDay${index}`;
      return `<input class="visually-hidden" ${index===0?'checked':''} data-summary="${label}" id="${id}" name="AppointmentDate" type="radio" value="${value}"><label class="slot day-slot" for="${id}"><span>${date.toLocaleDateString('ar-EG',{weekday:'long'})}</span><strong>${date.toLocaleDateString('ar-EG',{day:'numeric'})}</strong></label>`;
    }).join('') || '<p class="booking-empty-slots">لا توجد أيام عمل متاحة حاليًا. يرجى مراجعة الطبيب لاحقًا.</p>';
  }
  function renderAvailableTimes(dateValue) {
    if (!timeGrid) return;
    const from = toMinutes(savedHours.from || '16:00'), to = toMinutes(savedHours.to || '21:00');
    const pause = savedHours.break ? toMinutes(savedHours.break) : -1;
    const slots=[];
    for(let mins=from; mins+30<=to; mins+=30) {
      if(mins===pause) continue;
      const clock=toClock(mins);
      const isTaken=occupiedSlots.some(b=>String(b.DoctorId||b.doctorId||'')===String(selectedDoctorId)&&String(b.AppointmentDate||'')===String(dateValue)&&String(b.AppointmentTime||'')===clock&&!['ملغى','مرفوض','منتهي','cancelled','rejected','expired'].includes(String(b.status||'').toLowerCase()));
      slots.push({clock,isTaken});
    }
    timeGrid.innerHTML=slots.length?slots.map((slot,index)=>{const [h,m]=slot.clock.split(':').map(Number);const display=`${(h%12||12).toLocaleString('ar-EG')}:${String(m).padStart(2,'0').toLocaleString('ar-EG')} ${h<12?'ص':'م'}`;const id=`ShifaaTime${index}`;return `<input class="visually-hidden" ${!slot.isTaken&&index===slots.findIndex(x=>!x.isTaken)?'checked':''} ${slot.isTaken?'disabled':''} data-summary="${display} · بتوقيت القاهرة" id="${id}" name="AppointmentTime" type="radio" value="${slot.clock}"><label class="slot ${slot.isTaken?'is-unavailable':''}" for="${id}">${slot.isTaken?'محجوز':display}</label>`;}).join(''):'<p class="booking-empty-slots">لا توجد مواعيد متاحة في هذا اليوم.</p>';
  }
  const initialDate=dayGrid?.querySelector('[name="AppointmentDate"]:checked');
  if(initialDate) renderAvailableTimes(initialDate.value);
  dayGrid?.addEventListener('change',event=>{if(event.target.name==='AppointmentDate')renderAvailableTimes(event.target.value);});

  const doctorName = document.querySelector('.summary-doctor-name');
  const doctorSpecialty = document.querySelector('.summary-doctor-specialty');
  const doctorPhoto = document.querySelector('.summary-doctor-photo');
  const locationValue = document.querySelector('.summary-list div:first-child dd');
  const feeValue = document.querySelector('.summary-total strong');
  if (doctorName) doctorName.textContent = doctor.name;
  if (doctorSpecialty) doctorSpecialty.textContent = doctor.specialty;
  if (doctorPhoto) { doctorPhoto.src = doctor.photo; doctorPhoto.alt = doctor.name; }
  if (locationValue) locationValue.textContent = doctor.location;
  if (feeValue) feeValue.textContent = `${doctor.fee.toLocaleString('ar-EG')} ج.م`;

  function bind(name, id) {
    const target = document.getElementById(id);
    form.querySelectorAll(`[name="${name}"]`).forEach(input => input.addEventListener('change', () => {
      if (target) target.textContent = input.dataset.summary || input.value;
    }));
  }
  bind('AppointmentDate', 'SummaryDate');
  bind('AppointmentTime', 'SummaryTime');

  function renderPatientBookings() {
    const all = (() => { try { return JSON.parse(localStorage.getItem('shifaa_demo_bookings') || '[]'); } catch { return []; } })();
    const owner = String(signedInUser.id || signedInUser.email || signedInUser.Email || signedInUser.phone || signedInUser.PhoneNumber || 'demo-patient');
    const mine = all.filter(b => String(b.patientId || 'demo-patient') === owner).sort((a,b) => new Date(b.createdAt||0)-new Date(a.createdAt||0));
    let section = document.getElementById('my-bookings');
    if (!section) { section = document.createElement('section'); section.id='my-bookings'; section.className='card booking-confirmation'; form.insertAdjacentElement('afterend', section); }
    section.innerHTML = `<h2>حجوزاتي وطلبات الاستشارة</h2>${mine.length ? mine.map(b => {
      const status = b.status || 'بانتظار موافقة الطبيب';
      const canPay = ['بانتظار الدفع','بانتظار الدفع بعد الموافقة'].includes(status) && b.doctorStatus === 'تمت الموافقة';
      const paid = String(b.paymentStatus||'').toLowerCase() === 'paid';
      return `<article class="checkout-details" style="margin:12px 0;padding:14px;border:1px solid #e5e7eb;border-radius:12px"><div><strong>${b.DoctorName||'الطبيب'}</strong><span>${b.AppointmentDate||''} · ${b.AppointmentTime||''}</span></div><p>رقم الطلب: ${b.id}</p><p>الحالة: <strong>${status}</strong></p><p>الدفع: <strong>${paid?'مدفوع (تجريبي)':b.paymentStatus||'لم يتم الدفع'}</strong></p>${canPay?`<button type="button" class="btn btn-primary" data-demo-pay="${b.id}">دفع ${Number(b.ConsultationAmount||0).toLocaleString('ar-EG')} جنيه (تجريبي)</button>`:''}</article>`;
    }).join('') : '<p>لا توجد حجوزات حتى الآن.</p>'}`;
    section.querySelectorAll('[data-demo-pay]').forEach(button => button.addEventListener('click', () => {
      const rows = (() => { try { return JSON.parse(localStorage.getItem('shifaa_demo_bookings') || '[]'); } catch { return []; } })();
      const booking = rows.find(x => x.id === button.dataset.demoPay && String(x.patientId || 'demo-patient') === owner);
      if (!booking || booking.doctorStatus !== 'تمت الموافقة') return;
      booking.paymentStatus = 'Paid'; booking.status = 'تم التأكيد'; booking.IsConfirmed = true; booking.slotStatus = 'محجوز ومؤكد'; booking.paidAt = new Date().toISOString();
      localStorage.setItem('shifaa_demo_bookings', JSON.stringify(rows));
      const payments = (() => { try { return JSON.parse(localStorage.getItem('shifaa_demoPayments') || '[]'); } catch { return []; } })();
      payments.unshift({id:`PAY-${Date.now()}`,bookingId:booking.id,payer:booking.PatientName,purpose:'استشارة أونلاين',amount:`${booking.ConsultationAmount} EGP`,method:'Demo',status:'مدفوع تجريبيًا',provider:'محاكاة محلية',date:new Date().toLocaleDateString('ar-EG')});
      localStorage.setItem('shifaa_demoPayments', JSON.stringify(payments));
      const activity = (() => { try { return JSON.parse(localStorage.getItem('shifaa_activityLog') || '[]'); } catch { return []; } })();
      activity.unshift({id:`ACT-${Date.now()}`,type:'appointment-paid',patientId:owner,patientName:booking.PatientName,doctorName:booking.DoctorName,appointmentId:booking.id,description:'تم تسجيل الدفع التجريبي وتأكيد الحجز',createdAt:booking.paidAt});
      localStorage.setItem('shifaa_activityLog', JSON.stringify(activity));
      renderPatientBookings();
      alert('تم تسجيل الدفع التجريبي وتأكيد الموعد. لم يتم خصم أموال حقيقية.');
    }));
  }
  renderPatientBookings();
  window.addEventListener('storage', event => { if (event.key === 'shifaa_demo_bookings') renderPatientBookings(); });

  form.addEventListener('submit', event => {
    event.preventDefault();
    if (!form.reportValidity()) return;

    const data = Object.fromEntries(new FormData(form).entries());
    const currentUser = (() => {
      try { return JSON.parse(localStorage.getItem('shifaa_currentUser') || localStorage.getItem('currentUser') || '{}'); }
      catch { return {}; }
    })();
    const bookings = (() => {
      try { return JSON.parse(localStorage.getItem('shifaa_demo_bookings') || '[]'); }
      catch { return []; }
    })();
    const ownerId = String(currentUser.id || currentUser.email || currentUser.Email || currentUser.phone || currentUser.PhoneNumber || 'demo-patient');
    const patientSettings = (() => { try { return JSON.parse(localStorage.getItem('shifaa_patientSettings') || '{}'); } catch { return {}; } })();
    const patientName = data.PatientName || currentUser.name || currentUser.FullName || 'المريض';
    const chosenDoctorId = String(data.DoctorId || selectedDoctorId);
    const occupied = bookings.some(existing =>
      String(existing.DoctorId || existing.doctorId || '') === chosenDoctorId &&
      String(existing.AppointmentDate || '') === String(data.AppointmentDate || '') &&
      String(existing.AppointmentTime || '') === String(data.AppointmentTime || '') &&
      !['ملغى', 'مرفوض', 'منتهي', 'cancelled', 'rejected', 'expired'].includes(String(existing.status || '').toLowerCase())
    );
    if (occupied) {
      alert('الموعد ده تم حجزه بالفعل أو في انتظار موافقة الطبيب. اختاري موعدًا آخر.');
      return;
    }
    const item = {
      ...data,
      DoctorId: chosenDoctorId,
      DoctorName: doctor.name,
      DoctorSpecialty: doctor.specialty,
      PatientName: patientName,
      PatientPhone: data.PhoneNumber || currentUser.phone || currentUser.PhoneNumber || patientSettings.phone || '',
      patientId: ownerId,
      id: `SH-${Date.now()}`,
      createdAt: new Date().toISOString(),
      ConsultationAmount: doctor.fee,
      Currency: 'EGP',
      status: 'بانتظار موافقة الطبيب',
      doctorStatus: 'بانتظار المراجعة',
      paymentStatus: 'لم يتم الدفع',
      paymentProvider: 'Paymob',
      slotStatus: 'محجوز مؤقتًا'
    };
    bookings.push(item);
    localStorage.setItem('shifaa_demo_bookings', JSON.stringify(bookings));
    const activity = (() => { try { return JSON.parse(localStorage.getItem('shifaa_activityLog') || '[]'); } catch { return []; } })();
    activity.unshift({ id:`ACT-${Date.now()}`, type:'appointment-requested', patientId:ownerId.toLowerCase(), patientName, doctorId:item.DoctorId, doctorName:doctor.name, appointmentId:item.id, description:'طلب المريض حجز استشارة أونلاين', createdAt:item.createdAt });
    localStorage.setItem('shifaa_activityLog', JSON.stringify(activity));

    let box = document.getElementById('booking-confirmation');
    if (!box) {
      box = document.createElement('section');
      box.id = 'booking-confirmation';
      box.className = 'card booking-confirmation checkout-preview';
      form.appendChild(box);
    }

    const heading = document.createElement('h2');
    heading.textContent = 'تم إرسال طلب الحجز للطبيب';
    const intro = document.createElement('p');
    intro.textContent = `رقم الطلب ${item.id}. الموعد الآن في انتظار مراجعة الطبيب. ستظهر خطوة الدفع بعد موافقته على نفس الموعد.`;

    const details = document.createElement('dl');
    details.className = 'checkout-details';
    [
      ['الطبيب', doctor.name],
      ['المريض', patientName],
      ['التاريخ', data.AppointmentDate],
      ['الوقت', data.AppointmentTime],
      ['نوع الخدمة', 'استشارة أونلاين (فيديو)'],
      ['رسوم الاستشارة', `${doctor.fee.toLocaleString('ar-EG')} جنيه مصري`],
      ['بوابة الدفع المقترحة', 'Paymob']
    ].forEach(([label, value]) => {
      const row = document.createElement('div');
      const dt = document.createElement('dt');
      const dd = document.createElement('dd');
      dt.textContent = label;
      dd.textContent = value;
      row.append(dt, dd);
      details.appendChild(row);
    });

    const paymentTitle = document.createElement('h3');
    paymentTitle.textContent = 'الخطوة التالية';
    const methods = document.createElement('div');
    methods.className = 'checkout-methods';
    const wait = document.createElement('p');
    wait.className = 'checkout-notice';
    wait.textContent = 'لن يتم تحصيل أي مبلغ الآن. بعد موافقة الطبيب على الموعد، ستظهر لك خطوة الدفع التجريبية في قائمة حجوزاتك.';
    const continueButton = document.createElement('button');
    continueButton.type = 'button';
    continueButton.className = 'btn btn-secondary';
    continueButton.textContent = 'عرض حالة طلب الحجز';
    continueButton.addEventListener('click', () => {
      renderPatientBookings();
      document.getElementById('my-bookings')?.scrollIntoView({ behavior:'smooth', block:'center' });
    });

    const backLink = document.createElement('a');
    backLink.href = 'patient-dashboard.html';
    backLink.className = 'btn btn-secondary';
    backLink.textContent = 'العودة إلى مساحة المريض';

    box.replaceChildren(heading, intro, details, paymentTitle, wait, continueButton, backLink);
    box.scrollIntoView({ behavior:'smooth', block:'center' });
  });
});
